#!/usr/bin/env python3
"""
Post-task hook that archives completed beans to .beans/completed/

ENHANCED VERSION: Directly moves files without /yolo dependency

This hook:
1. Queries for beans with status "completed" or "scrapped"
2. Filters strictly - excludes beans with unchecked checklist items
3. Creates .beans/completed/ directory if needed
4. Moves fully complete bean files
5. Logs which beans were moved and which were skipped

Hook type: Stop (runs when Claude stops after completing work)
"""

import json
import subprocess
import sys
import re
import shutil
from pathlib import Path


def query_completed_beans():
    """Query beans with completed or scrapped status"""
    query = '''
    {
        beans(filter: { status: ["completed", "scrapped"] }) {
            id
            slug
            path
            body
        }
    }
    '''

    try:
        result = subprocess.run(
            ['beans', 'query', '--json', query],
            capture_output=True,
            text=True,
            timeout=10
        )

        if result.returncode != 0:
            print(f"Error querying beans: {result.stderr}", file=sys.stderr)
            return []

        data = json.loads(result.stdout)
        # beans query --json returns { "beans": [...] } directly
        return data.get('beans', [])

    except subprocess.TimeoutExpired:
        print(f"Bean query timed out", file=sys.stderr)
        return []
    except Exception as e:
        print(f"Failed to query beans: {e}", file=sys.stderr)
        return []


def has_unchecked_todos(body):
    """Check if bean body contains unchecked checklist items"""
    # Pattern: - [ ] (unchecked markdown checkbox)
    unchecked_pattern = r'^\s*-\s+\[\s+\]\s+'

    for line in body.split('\n'):
        if re.match(unchecked_pattern, line):
            return True

    return False


def filter_fully_complete_beans(beans):
    """Filter to only beans that are fully complete (no unchecked todos)"""
    fully_complete = []
    skipped = []

    for bean in beans:
        bean_id = bean.get('id', 'unknown')
        bean_path = bean.get('path', 'unknown')
        body = bean.get('body', '')

        if has_unchecked_todos(body):
            skipped.append({
                'id': bean_id,
                'path': bean_path,
                'reason': 'Contains unchecked checklist items'
            })
        else:
            fully_complete.append(bean)

    return fully_complete, skipped


def ensure_archive_directory():
    """Ensure .beans/completed/ directory exists"""
    archive_dir = Path('.beans/completed')

    try:
        archive_dir.mkdir(parents=True, exist_ok=True)
        return True
    except Exception as e:
        print(f"Failed to create archive directory: {e}", file=sys.stderr)
        return False


def move_bean_to_archive(bean):
    """Move a bean file to .beans/completed/"""
    bean_id = bean.get('id', 'unknown')
    bean_path = bean.get('path', '')

    if not bean_path:
        return False, "No path specified"

    source = Path('.beans') / bean_path
    destination = Path('.beans/completed') / bean_path

    try:
        # Check if source exists
        if not source.exists():
            return False, f"Source file not found: {source}"

        # Check if destination already exists
        if destination.exists():
            return False, f"Destination already exists: {destination}"

        # Move the file
        shutil.move(str(source), str(destination))
        return True, f"Moved successfully"

    except Exception as e:
        return False, f"Move failed: {e}"


def archive_beans(beans_to_move):
    """Archive fully complete beans by moving their files"""
    if not beans_to_move:
        return [], []

    # Ensure archive directory exists
    if not ensure_archive_directory():
        return [], []

    moved = []
    failed = []

    for bean in beans_to_move:
        bean_id = bean.get('id', 'unknown')
        bean_path = bean.get('path', 'unknown')

        success, message = move_bean_to_archive(bean)

        if success:
            moved.append({
                'id': bean_id,
                'path': bean_path,
                'status': 'moved'
            })
            print(f"✓ Archived {bean_id}: {bean_path}", file=sys.stderr)
        else:
            failed.append({
                'id': bean_id,
                'path': bean_path,
                'reason': message
            })
            print(f"✗ Failed to archive {bean_id}: {message}", file=sys.stderr)

    return moved, failed


def main():
    """Main hook execution"""
    try:
        # Query for completed/scrapped beans
        beans = query_completed_beans()

        if not beans:
            print("No completed/scrapped beans found", file=sys.stderr)
            sys.exit(0)

        # Filter to only fully complete beans (no unchecked todos)
        fully_complete, skipped = filter_fully_complete_beans(beans)

        # Log summary
        print(f"\n{'='*60}", file=sys.stderr)
        print(f"Bean Archiving Summary", file=sys.stderr)
        print(f"{'='*60}", file=sys.stderr)
        print(f"Total completed/scrapped beans: {len(beans)}", file=sys.stderr)
        print(f"Fully complete (no unchecked todos): {len(fully_complete)}", file=sys.stderr)
        print(f"Skipped (has unchecked todos): {len(skipped)}", file=sys.stderr)

        if skipped:
            print(f"\nSkipped beans:", file=sys.stderr)
            for bean in skipped:
                print(f"  ⏭️  {bean['id']}: {bean['reason']}", file=sys.stderr)

        # Archive fully complete beans
        if fully_complete:
            print(f"\nArchiving {len(fully_complete)} bean(s)...", file=sys.stderr)
            moved, failed = archive_beans(fully_complete)

            # Output structured results
            result = {
                "hookSpecificOutput": {
                    "hookEventName": "Stop",
                    "action": "archive_completed_beans",
                    "total_beans": len(beans),
                    "fully_complete": len(fully_complete),
                    "skipped": len(skipped),
                    "moved": len(moved),
                    "failed": len(failed),
                    "moved_beans": [m['id'] for m in moved],
                    "failed_beans": [f['id'] for f in failed],
                    "skipped_beans": [s['id'] for s in skipped]
                }
            }

            print(f"\n{'='*60}", file=sys.stderr)
            print(f"Archive Results", file=sys.stderr)
            print(f"{'='*60}", file=sys.stderr)
            print(f"✓ Successfully moved: {len(moved)}", file=sys.stderr)
            print(f"✗ Failed to move: {len(failed)}", file=sys.stderr)
            print(f"{'='*60}\n", file=sys.stderr)

            # Output JSON for Claude Code
            print(json.dumps(result))
        else:
            print(f"\nNo beans ready for archiving", file=sys.stderr)

        # Exit successfully (non-blocking hook)
        sys.exit(0)

    except Exception as e:
        print(f"Hook error: {e}", file=sys.stderr)
        # Exit successfully to avoid blocking workflow
        sys.exit(0)


if __name__ == "__main__":
    main()
