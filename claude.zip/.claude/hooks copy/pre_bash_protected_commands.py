#!/usr/bin/env python3
"""
Pre-Bash Protected Commands Hook

Blocks AI agent from running commands that could bypass hooks or governance.

BLOCKED commands/patterns:
- --no-verify (git commit/push hook bypass)
- --no-gpg-sign (signature bypass)
- SKIP=* (pre-commit skip patterns)
- PRE_COMMIT_ALLOW_NO_CONFIG (pre-commit bypass)
- git push --force (destructive operations)
- Reading/catting pre-commit config files

Exit codes:
  0: Command is allowed
  2: Command is BLOCKED

Usage: Called by Claude Code pre-tool-use hook system before Bash operations.
"""

import json
import os
import re
import sys


# Patterns that are BLOCKED (case-insensitive)
BLOCKED_PATTERNS = [
    # Git hook bypass
    r'--no-verify',
    r'--no-gpg-sign',
    r'-n\s+commit',  # git commit -n (short for --no-verify)
    # Pre-commit bypass
    r'SKIP=',
    r'PRE_COMMIT_ALLOW_NO_CONFIG',
    r'PRE_COMMIT_SKIP',
    r'pre-commit\s+run\s+--all-files\s+--hook-stage\s+manual',
    # Force operations
    r'--force-with-lease',
    r'git\s+push\s+.*--force',
    r'git\s+push\s+.*-f\b',
    r'git\s+push\s+-f',
    # Reading pre-commit configs
    r'cat\s+.*pre-commit',
    r'less\s+.*pre-commit',
    r'more\s+.*pre-commit',
    r'head\s+.*pre-commit',
    r'tail\s+.*pre-commit',
    r'vim\s+.*pre-commit',
    r'nano\s+.*pre-commit',
    r'code\s+.*pre-commit',
    # Destructive operations
    r'rm\s+-rf\s+/',
    r'rm\s+-rf\s+~',
    r'rm\s+-rf\s+\.',
    # Hook manipulation
    r'chmod\s+.*\.git/hooks',
    r'rm\s+.*\.git/hooks',
    r'mv\s+.*\.git/hooks',
    # Environment variable manipulation to bypass
    r'export\s+SKIP=',
    r'export\s+PRE_COMMIT',
    r'unset\s+.*HOOK',
]

# Commands that are always blocked
BLOCKED_COMMANDS = [
    'pre-commit uninstall',
    'git config --unset',
    'git config core.hooksPath',
]


def print_blocked_message(command: str, reason: str):
    """Print a clear message explaining why the command is blocked"""
    print()
    print("=" * 80)
    print("=" * 80)
    print()
    print("     ██████╗ ██╗      ██████╗  ██████╗██╗  ██╗███████╗██████╗ ██╗")
    print("     ██╔══██╗██║     ██╔═══██╗██╔════╝██║ ██╔╝██╔════╝██╔══██╗██║")
    print("     ██████╔╝██║     ██║   ██║██║     █████╔╝ █████╗  ██║  ██║██║")
    print("     ██╔══██╗██║     ██║   ██║██║     ██╔═██╗ ██╔══╝  ██║  ██║╚═╝")
    print("     ██████╔╝███████╗╚██████╔╝╚██████╗██║  ██╗███████╗██████╔╝██╗")
    print("     ╚═════╝ ╚══════╝ ╚═════╝  ╚═════╝╚═╝  ╚═╝╚══════╝╚═════╝ ╚═╝")
    print()
    print("=" * 80)
    print("=" * 80)
    print()
    print("    COMMAND BLOCKED - GOVERNANCE VIOLATION!")
    print("    ========================================")
    print()
    print(f"    Blocked Pattern: {reason}")
    print()
    print("    This command attempts to bypass project governance.")
    print()
    print("    WHAT IS BLOCKED:")
    print("    -----------------")
    print("    - --no-verify (skips pre-commit hooks)")
    print("    - SKIP=* environment variables (bypasses specific hooks)")
    print("    - --force push operations (destructive)")
    print("    - Reading pre-commit configuration files")
    print("    - Modifying .git/hooks directory")
    print("    - Any hook bypass attempts")
    print()
    print("    WHAT TO DO INSTEAD:")
    print("    --------------------")
    print("    1. FIX the code issues that hooks detect")
    print("    2. Run hooks manually: pre-commit run --all-files")
    print("    3. Ask a human if you believe a hook is incorrect")
    print()
    print("    YOU CANNOT SKIP HOOKS - FIX THE CODE!")
    print()
    print("=" * 80)
    print("=" * 80)
    print()


def get_command_from_input() -> str:
    """Extract command from Claude tool input"""
    tool_input = os.environ.get("CLAUDE_TOOL_INPUT", "")

    if tool_input:
        try:
            data = json.loads(tool_input)
            if isinstance(data, dict):
                if "command" in data:
                    return data["command"]
                if "cmd" in data:
                    return data["cmd"]
        except json.JSONDecodeError:
            # Not JSON, might be a direct command
            return tool_input.strip()

    return ""


def is_blocked_command(command: str) -> tuple:
    """Check if the command matches any blocked patterns"""
    command_lower = command.lower()

    # Check exact blocked commands
    for blocked in BLOCKED_COMMANDS:
        if blocked in command_lower:
            return True, blocked

    # Check blocked patterns
    for pattern in BLOCKED_PATTERNS:
        if re.search(pattern, command, re.IGNORECASE):
            return True, pattern

    return False, ""


def main():
    """Check if the command is blocked"""
    command = get_command_from_input()

    if command:
        is_blocked, reason = is_blocked_command(command)
        if is_blocked:
            print_blocked_message(command, reason)
            sys.exit(2)

    # Command is allowed
    sys.exit(0)


if __name__ == "__main__":
    main()
