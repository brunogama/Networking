#!/bin/bash
# post-commit-review.sh
# Hook script that triggers after successful git commits
# Returns context for Claude to invoke the code-reviewer subagent

# Read JSON input from stdin
INPUT=$(cat)

# Extract the command that was executed
COMMAND=$(echo "$INPUT" | jq -r '.tool_input.command // empty')

# Only trigger for successful git commit commands
# Check if the command contains "git commit" and completed successfully
if echo "$COMMAND" | grep -qE 'git commit'; then
  # Get the commit hash and message
  COMMIT_HASH=$(git rev-parse --short HEAD 2>/dev/null)
  COMMIT_MSG=$(git log -1 --pretty=format:"%s" 2>/dev/null)

  if [ -n "$COMMIT_HASH" ]; then
    # Return context that Claude will use to invoke the code-reviewer
    cat << EOF
{
  "hookSpecificOutput": {
    "hookEventName": "PostToolUse",
    "additionalContext": "A git commit was just completed (${COMMIT_HASH}: ${COMMIT_MSG}). Please use the code-reviewer subagent to review the changes in this commit."
  }
}
EOF
    exit 0
  fi
fi

# For non-commit commands, allow to proceed without action
exit 0
