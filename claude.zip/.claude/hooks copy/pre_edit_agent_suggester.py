#!/usr/bin/env python3
"""Pre-edit hook that suggests appropriate agents based on file type.

This hook reads the agent index and suggests the best agent for editing
the given file based on its extension and context patterns.

Exit codes:
    0 - Success (suggestion provided in stdout)
    1 - Error (could not determine suggestion)
"""

import os
import sys
from pathlib import Path

# File extension to type mapping
EXTENSION_MAP = {
    ".swift": "swift",
    ".md": "markdown",
    ".yaml": "yaml",
    ".yml": "yaml",
    ".py": "python",
    ".json": "json",
    ".ts": "typescript",
    ".tsx": "typescript",
    ".js": "javascript",
    ".jsx": "javascript",
}

# Test file patterns
TEST_PATTERNS = ["Tests.swift", "Spec.swift", ".test.ts", ".spec.ts", "_test.py"]

# Agent mappings (mirrors index.yaml for fast lookup)
FILE_TYPE_AGENTS = {
    "swift": {
        "primary": "swift-pro",
        "alternatives": ["ios-architect", "ios-ui-specialist", "apple-ml-swift-pro"],
        "description": "Swift source files",
    },
    "swift_test": {
        "primary": "tester",
        "alternatives": ["tdd-london-swarm", "swift-pro"],
        "description": "Swift test files",
    },
    "markdown": {
        "primary": "coder",
        "alternatives": ["swift-doc-specialist", "deep-researcher"],
        "description": "Documentation files",
    },
    "yaml": {
        "primary": "coder",
        "alternatives": ["cicd-engineer"],
        "description": "Configuration files",
    },
    "python": {
        "primary": "coder",
        "alternatives": ["tester"],
        "description": "Python scripts",
    },
    "json": {
        "primary": "coder",
        "alternatives": [],
        "description": "JSON configuration files",
    },
    "typescript": {
        "primary": "coder",
        "alternatives": ["tester", "reviewer"],
        "description": "TypeScript files",
    },
    "javascript": {
        "primary": "coder",
        "alternatives": ["tester", "reviewer"],
        "description": "JavaScript files",
    },
}


def is_test_file(filepath: str) -> bool:
    """Check if the file is a test file based on naming patterns."""
    return any(pattern in filepath for pattern in TEST_PATTERNS)


def detect_file_type(filepath: str) -> str:
    """Detect the file type from the file path."""
    path = Path(filepath)
    ext = path.suffix.lower()

    # Check for test files first
    if ext == ".swift" and is_test_file(filepath):
        return "swift_test"

    return EXTENSION_MAP.get(ext, "unknown")


def get_agent_suggestion(file_type: str) -> dict:
    """Get the agent suggestion for a file type."""
    return FILE_TYPE_AGENTS.get(file_type, {
        "primary": "coder",
        "alternatives": [],
        "description": "Unknown file type - using general coder",
    })


def format_suggestion(filepath: str, file_type: str, suggestion: dict) -> str:
    """Format the agent suggestion for output."""
    lines = [
        f"[Agent Suggestion for: {Path(filepath).name}]",
        f"File type: {suggestion['description']} ({file_type})",
        f"Recommended agent: {suggestion['primary']}",
    ]

    if suggestion["alternatives"]:
        alts = ", ".join(suggestion["alternatives"])
        lines.append(f"Alternatives: {alts}")

    return "\n".join(lines)


def main():
    """Main entry point for the pre-edit hook."""
    if len(sys.argv) < 2:
        print("Usage: pre_edit_agent_suggester.py <filepath>", file=sys.stderr)
        sys.exit(1)

    filepath = sys.argv[1]

    # Detect file type
    file_type = detect_file_type(filepath)

    # Get agent suggestion
    suggestion = get_agent_suggestion(file_type)

    # Output the suggestion
    print(format_suggestion(filepath, file_type, suggestion))

    sys.exit(0)


if __name__ == "__main__":
    main()
