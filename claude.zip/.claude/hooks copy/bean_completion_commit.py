#!/usr/bin/env python3
"""
Bean Completion Commit Hook

Triggers when a bean is marked as completed, automatically running the smart-commit
slash command to create an intelligent git commit with the best commit strategy.

This hook:
1. Detects when a bean status changes to "completed"
2. Reads the bean content to understand what was done
3. Invokes the smart-commit command with context about the completed work
4. Lets the smart-commit agent choose the best commit strategy

Hook Type: PostToolUse
Trigger: Bash commands that run `beans update` with --status completed
"""

import json
import sys
import subprocess
import re
from pathlib import Path


def extract_bean_id_from_command(command: str) -> str | None:
    """
    Extract bean ID from beans update command.

    Examples:
        beans update abc123 --status completed → abc123
        beans update beans-abc1 -s completed → beans-abc1
    """
    # Pattern: beans update <id> ... --status completed (or -s completed)
    pattern = r'beans\s+update\s+([\w-]+).*?(?:--status|-s)\s+completed'
    match = re.search(pattern, command)
    return match.group(1) if match else None


def is_bean_completion_command(command: str) -> bool:
    """Check if command is marking a bean as completed."""
    if 'beans' not in command or 'update' not in command:
        return False

    # Check for --status completed or -s completed
    return bool(re.search(r'(?:--status|-s)\s+completed', command))


def get_bean_content(bean_id: str) -> dict | None:
    """
    Fetch bean content using beans CLI.

    Returns dict with title, type, body, tags, etc.
    """
    try:
        result = subprocess.run(
            ['beans', 'show', bean_id, '--json'],
            capture_output=True,
            text=True,
            timeout=5
        )

        if result.returncode == 0:
            return json.loads(result.stdout)
        return None
    except Exception as e:
        print(f"Warning: Failed to fetch bean content: {e}", file=sys.stderr)
        return None


def trigger_smart_commit(bean_data: dict) -> None:
    """
    Trigger smart-commit command with bean context.

    Provides the smart-commit agent with:
    - Bean title and type
    - Work description from body
    - Tags for categorization
    - Let agent choose optimal commit strategy
    """
    bean_id = bean_data.get('id', 'unknown')
    bean_title = bean_data.get('title', 'Work completed')
    bean_type = bean_data.get('type', 'task')
    bean_body = bean_data.get('body', '')
    bean_tags = bean_data.get('tags', [])

    # Build context message for smart-commit agent
    context = f"""Bean {bean_id} completed: {bean_title}

Type: {bean_type}
Tags: {', '.join(bean_tags) if bean_tags else 'none'}

Work Description:
{bean_body[:500]}{'...' if len(bean_body) > 500 else ''}

---
INSTRUCTIONS: Analyze the completed work above and choose the BEST commit strategy:
- Conventional commit format (feat/fix/refactor/etc)
- Appropriate scope based on changes
- Comprehensive commit message capturing the work
- Include bean ID reference in footer: Closes #{bean_id}

Use git status and git diff to understand what files changed, then create
an intelligent commit that follows project conventions and best practices.
"""

    # Output instruction for Claude Code to invoke smart-commit
    print(f"\n{'='*60}", file=sys.stderr)
    print("🎯 Bean Completion Detected!", file=sys.stderr)
    print(f"{'='*60}", file=sys.stderr)
    print(f"📋 Bean: {bean_id} - {bean_title}", file=sys.stderr)
    print(f"🏷️  Type: {bean_type}", file=sys.stderr)
    print(f"\n💡 Triggering smart-commit to create optimal commit...", file=sys.stderr)
    print(f"{'='*60}\n", file=sys.stderr)

    # Return prompt for Claude to execute smart-commit
    # This will be picked up by Claude Code as a hook response
    print(json.dumps({
        "action": "invoke_skill",
        "skill": "smart-commit",
        "context": context,
        "message": f"Bean {bean_id} completed. Creating intelligent commit with optimal strategy..."
    }))


def main():
    """Main hook execution."""
    try:
        # Read PostToolUse hook data from stdin
        hook_data = json.load(sys.stdin)

        # Extract the Bash command that was executed
        tool_input = hook_data.get('tool_input', {})
        command = tool_input.get('command', '')

        # Check if this is a bean completion command
        if not is_bean_completion_command(command):
            # Not a bean completion - exit silently
            sys.exit(0)

        # Extract bean ID from command
        bean_id = extract_bean_id_from_command(command)
        if not bean_id:
            print("Warning: Could not extract bean ID from command", file=sys.stderr)
            sys.exit(0)

        # Fetch bean content
        bean_data = get_bean_content(bean_id)
        if not bean_data:
            print(f"Warning: Could not fetch bean {bean_id}", file=sys.stderr)
            sys.exit(0)

        # Trigger smart-commit
        trigger_smart_commit(bean_data)

        # Exit successfully
        sys.exit(0)

    except json.JSONDecodeError:
        print("Error: Invalid JSON input", file=sys.stderr)
        sys.exit(0)  # Non-blocking error
    except Exception as e:
        print(f"Error in bean completion hook: {e}", file=sys.stderr)
        sys.exit(0)  # Non-blocking error


if __name__ == '__main__':
    main()
