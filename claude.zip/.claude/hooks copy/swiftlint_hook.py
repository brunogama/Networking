#!/usr/bin/env -S uv run --script
# /// script
# requires-python = ">=3.11"
# ///

"""
SwiftLint Hook for Claude Code
Automatically lints and fixes Swift files after edit operations.
"""

import json
import sys
import subprocess
import os
from pathlib import Path


def is_swift_file(file_path: str) -> bool:
    """Check if the file is a Swift file."""
    return file_path.endswith('.swift')


def find_swiftlint_config() -> str | None:
    """Find the SwiftLint configuration file."""
    config_files = ['.swiftlint.yml', '.swiftlint.yaml', 'swiftlint.yml', 'swiftlint.yaml']

    for config_file in config_files:
        if Path(config_file).exists():
            return config_file

    return None


def run_swiftlint(file_path: str) -> tuple[bool, str]:
    """
    Run SwiftLint on the specified file.

    Returns:
        tuple: (success: bool, message: str)
    """
    try:
        # Check if SwiftLint is available
        result = subprocess.run(
            ['which', 'swiftlint'],
            capture_output=True,
            text=True,
            timeout=5
        )

        if result.returncode != 0:
            return False, "SwiftLint not found. Install with: brew install swiftlint"

        # Build SwiftLint command
        cmd = ['swiftlint', 'lint', '--fix', file_path]

        # Add config file if it exists
        config_file = find_swiftlint_config()
        if config_file:
            cmd.extend(['--config', config_file])

        # Run SwiftLint with auto-fix
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=30,
            cwd=os.getcwd()
        )

        # SwiftLint returns 0 for success, 2 for violations found but corrected
        if result.returncode in [0, 2]:
            violations_fixed = "violations found and fixed" if result.returncode == 2 else "no violations"
            return True, f"✅ SwiftLint applied to {Path(file_path).name} ({violations_fixed})"
        else:
            stderr_output = result.stderr.strip()
            stdout_output = result.stdout.strip()
            error_msg = stderr_output or stdout_output or "Unknown error"
            return False, f"❌ SwiftLint failed: {error_msg}"

    except subprocess.TimeoutExpired:
        return False, "❌ SwiftLint timed out"
    except Exception as e:
        return False, f"❌ SwiftLint error: {str(e)}"


def main():
    try:
        # Read input from stdin
        input_data = json.loads(sys.stdin.read())

        # Extract relevant information
        tool_name = input_data.get('tool_name', '')
        tool_input = input_data.get('tool_input', {})
        hook_event_name = input_data.get('hook_event_name', '')

        # Only process PostToolUse events for edit operations
        if hook_event_name != 'PostToolUse':
            sys.exit(0)

        # Only process Edit, MultiEdit, and Write operations
        if tool_name not in ['Edit', 'MultiEdit', 'Write']:
            sys.exit(0)

        # Extract file path based on tool type
        file_path = None
        if tool_name in ['Edit', 'Write']:
            file_path = tool_input.get('file_path')
        elif tool_name == 'MultiEdit':
            file_path = tool_input.get('file_path')

        if not file_path:
            sys.exit(0)

        # Only process Swift files
        if not is_swift_file(file_path):
            sys.exit(0)

        # Check if file exists
        if not Path(file_path).exists():
            print(f"⚠️  File not found: {file_path}", file=sys.stderr)
            sys.exit(0)

        # Run SwiftLint
        success, message = run_swiftlint(file_path)

        if success:
            print(message)  # Success message to stdout
            sys.exit(0)
        else:
            print(message, file=sys.stderr)
            sys.exit(1)  # Non-blocking error

    except json.JSONDecodeError as e:
        print(f"❌ Invalid JSON input: {e}", file=sys.stderr)
        sys.exit(1)
    except Exception as e:
        print(f"❌ SwiftLint hook error: {e}", file=sys.stderr)
        sys.exit(1)


if __name__ == '__main__':
    main()
