# SwiftSQLiteVec Claude Code Hooks

This directory contains Claude Code hooks that enforce project rules and automate quality checks.

## Active Hooks

### PreToolUse Hooks

#### 1. `pre-tool`
**Triggers**: Before any Bash tool execution
**Purpose**: Prevent `git commit --no-verify` usage
**Timeout**: Built-in (fast)
**Behavior**:
- Detects `git commit` commands with `--no-verify` or `--no-gpg-sign` flags
- Blocks the command and displays helpful error message
- Enforces project rule: "DO NOT use --no-verify to skip pre-commit hooks"
- Suggests proper alternatives (fixing issues or using `SKIP=hook-name`)

**Exit Codes**:
- `0` - Tool allowed to proceed
- `1` - Tool blocked (violation detected)

### PostToolUse Hooks

#### 1. `post_tool_use_swiftformat.py` (if configured)
**Triggers**: After `Edit`, `Write`, `MultiEdit`
**Purpose**: Auto-format Swift code with SwiftFormat
**Timeout**: 30s

#### 2. `post_tool_use_swiftlint.py` (if configured)
**Triggers**: After `Edit`, `Write`, `MultiEdit`
**Purpose**: Lint Swift code and enforce code standards
**Timeout**: 60s

### SessionStart Hooks

#### 1. `session_start.py` (if configured)
**Triggers**: Session start
**Purpose**: Load project context and restore state
**Timeout**: 15s

### SessionEnd Hooks

#### 1. `memory_cleanup.py` (if configured)
**Triggers**: Session end
**Purpose**: Consolidate project memories
**Timeout**: 10s

## Testing Hooks

### Test pre-tool hook

```bash
# Test with valid commit (should pass with exit 0)
echo '{"tool":"Bash","parameters":{"command":"git commit -m \"test\""}}' | .claude/hooks/pre-tool
echo "Exit code: $?"

# Test with --no-verify (should block with exit 1)
echo '{"tool":"Bash","parameters":{"command":"git commit --no-verify -m \"test\""}}' | .claude/hooks/pre-tool
echo "Exit code: $?"

# Test with --no-gpg-sign (should block with exit 1)
echo '{"tool":"Bash","parameters":{"command":"git commit --no-gpg-sign -m \"test\""}}' | .claude/hooks/pre-tool
echo "Exit code: $?"
```

## Bypassing Pre-commit Checks (When Necessary)

If you legitimately need to skip a specific pre-commit check:

```bash
# Skip a specific hook
SKIP=hook-id git commit -m "message"

# Skip multiple hooks
SKIP=hook1,hook2 git commit -m "message"
```

**Never** use `--no-verify` as it skips ALL checks and violates project rules.

## Project Rules Enforced

From `RULES.md`:
- **DO NOT** use `--no-verify` to skip pre-commit hooks
- **DO NOT** disable SwiftLint rules to pass commit hooks—fix the code issue
- Zero warnings, zero errors, zero failing tests policy is non-negotiable

---

**Last Updated**: 2026-01-09
