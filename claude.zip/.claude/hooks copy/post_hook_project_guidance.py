#!/usr/bin/env python3
"""
Post-Hook Project Guidance Pipeline

This composite hook executes multiple validation hooks in sequence.
All output is forwarded, and the first non-zero exit code stops execution.

Exit codes:
  0: Success (all hooks passed)
  1: General error
  2: Validation error (forwarded from child hooks)

Usage: Called by Claude Code post-hook system after tool execution.
"""

import subprocess
import sys
from pathlib import Path
from typing import List


class HookPipeline:
    """Manages execution of multiple hooks in sequence"""

    def __init__(self, project_root: Path):
        self.project_root = project_root
        self.hooks_dir = project_root / ".claude" / "hooks"

    def define_hooks(self) -> List[Path]:
        """
        Define the sequence of hooks to execute.

        Order matters: hooks run sequentially, stopping at first failure.

        Note: Swift validation hooks removed - this is not a Swift project.
        This is the BMad Method framework (documentation/methodology).
        """
        return [
            self.hooks_dir / "post_hook_srp_principles_validation.py",
            self.hooks_dir / "post_hook_solid_compliance.py",
            # Swift hooks removed - not applicable to documentation projects
            self.hooks_dir / "post_hook_swiftformat_validation.py",
            self.hooks_dir / "post_hook_swiftlint_validation.py",
        ]

    def execute_pipeline(self) -> int:
        """
        Execute all hooks in sequence.

        Returns:
            Exit code from first failing hook, or 0 if all succeed
        """
        hooks = self.define_hooks()

        if not hooks:
            print("⚠️  Warning: No hooks defined in pipeline")
            return 0

        print(f"🔄 Executing {len(hooks)} validation hook(s)...\n")

        for i, hook_path in enumerate(hooks, 1):
            if not hook_path.exists():
                print(f"⚠️  Warning: Hook {i}/{len(hooks)} not found: {hook_path.name}")
                print(f"   Skipping: {hook_path!s}")
                continue

            print(f"{'=' * 60}")
            print(f"Hook {i}/{len(hooks)}: {hook_path.name}")
            print(f"{'=' * 60}\n")

            exit_code = self._execute_hook(hook_path)

            if exit_code != 0:
                print(f"\n{'=' * 60}")
                print("❌ PIPELINE FAILURE")
                print(f"{'=' * 60}")
                print(f"Hook: {hook_path.name}")
                print(f"Exit Code: {exit_code}")
                print(f"Position: {i}/{len(hooks)}")
                print(f"\nStopping pipeline execution - remaining {len(hooks) - i} hook(s) skipped")
                print(f"{'=' * 60}")
                return exit_code

            print(f"\n✅ Hook {i}/{len(hooks)} completed successfully\n")

        print(f"{'=' * 60}")
        print(f"✅ All {len(hooks)} hook(s) completed successfully")
        print(f"{'=' * 60}")
        return 0

    def _execute_hook(self, hook_path: Path) -> int:
        """
        Execute a single hook and forward all output.

        Args:
            hook_path: Path to the hook script

        Returns:
            Exit code from the hook
        """
        try:
            result = subprocess.run(
                [sys.executable, str(hook_path)],
                cwd=str(self.project_root),
                capture_output=False,  # Forward output directly
                text=True,
                check=False  # Don't raise exception on non-zero exit
            )
            return result.returncode

        except FileNotFoundError as e:
            print(f"❌ Error: Hook script not found: {e}")
            return 1
        except PermissionError as e:
            print(f"❌ Error: Permission denied executing hook: {e}")
            print(f"   Try: chmod +x {hook_path}")
            return 1
        except OSError as e:
            print(f"❌ Error executing hook: {e}")
            return 1


def main():
    """Execute the hook pipeline"""
    # Get project root (2 levels up from .claude/hooks/)
    script_dir = Path(__file__).parent
    project_root = script_dir.parent.parent

    # Create and execute pipeline
    pipeline = HookPipeline(project_root)
    exit_code = pipeline.execute_pipeline()

    sys.exit(exit_code)


if __name__ == "__main__":
    main()
