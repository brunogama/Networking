#!/usr/bin/env python3
"""Memory cleanup hook - consolidates project memory."""

import json
import sys
from pathlib import Path
from datetime import datetime

def consolidate_memories(memory_file: Path) -> dict:
    """Consolidate realtime memories, removing noise and merging related entries."""

    with open(memory_file, 'r') as f:
        data = json.load(f)

    realtime = data.get('realtime_memories', [])

    # Filter SIGNAL (keep) vs NOISE (remove)
    signal_memories = []

    for memory in realtime:
        mem_type = memory.get('type', '')
        content = memory.get('content', '')

        # KEEP: preferences, decisions, corrections, tech choices, completed features, conventions
        if mem_type in ['completed_milestone', 'code_standard', 'infrastructure_fix',
                        'workflow_preference', 'tech_choice', 'decision', 'convention']:
            signal_memories.append(memory)

        # REMOVE: greetings, thanks, praise without context, exact duplicates, truncated messages
        elif mem_type in ['claude_response', 'message']:
            # Skip if it's just a greeting/acknowledgment or incomplete
            skip_phrases = [
                "perfect!", "i see the issue", "i notice", "let me",
                "you're absolutely right", "i'll help", "great!",
                "i can help you", "let me update"
            ]
            if any(phrase in content.lower() for phrase in skip_phrases):
                continue

            # Skip truncated messages
            if content.endswith('44') or '"session_id"' in content:
                continue

            # Skip incomplete responses (ends mid-sentence)
            if content.rstrip().endswith(('─', '…', 'I\'ll also set')):
                continue

            signal_memories.append(memory)

    # Remove exact duplicates
    seen_content = set()
    unique_memories = []
    for memory in signal_memories:
        content = memory.get('content', '')
        if content not in seen_content:
            seen_content.add(content)
            unique_memories.append(memory)

    # Update the data
    data['realtime_memories'] = unique_memories
    data['updated_at'] = datetime.now().isoformat()

    return data

def main():
    """Main entry point."""
    project_root = Path(__file__).parent.parent.parent
    memory_file = project_root / '.claude' / 'memories' / 'project_memory.json'

    if not memory_file.exists():
        print("✓ No memory file to clean", file=sys.stderr)
        return 0

    try:
        # Read and consolidate
        data = consolidate_memories(memory_file)

        # Write back silently
        with open(memory_file, 'w') as f:
            json.dump(data, f, indent=2)

        # Report quietly
        count = len(data.get('realtime_memories', []))
        print(f"✓ Memory consolidated to {count} entries", file=sys.stderr)
        return 0

    except Exception as e:
        print(f"⚠ Memory cleanup failed: {e}", file=sys.stderr)
        return 0  # Non-blocking

if __name__ == '__main__':
    sys.exit(main())
