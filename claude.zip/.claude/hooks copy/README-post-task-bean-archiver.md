# Post-Task Bean Archiver Hook

## Overview

Automatically archives completed beans to `.beans/completed/` directory after task completion, keeping the active beans workspace focused on actionable items.

## ✨ Enhanced Version (Active)

**Current implementation**: `post_task_bean_archiver_direct.py` - Directly moves files without external dependencies.

## How It Works

1. **Triggers**: Runs on `Stop` event (when Claude attempts to stop after completing work)
2. **Queries**: Finds all beans with status "completed" or "scrapped"
3. **Filters**: Strictly excludes beans with unchecked checklist items (`- [ ]`)
4. **Creates**: Ensures `.beans/completed/` directory exists
5. **Moves**: Relocates fully complete bean files to archive
6. **Reports**: Outputs detailed results with moved/skipped/failed counts

## Installation

The hook is already configured in `.claude/hooks.json`:

```json
{
  "hooks": {
    "Stop": [
      {
        "hooks": [
          {
            "type": "command",
            "command": "$CLAUDE_PROJECT_DIR/.claude/hooks/post_task_bean_archiver_direct.py",
            "timeout": 15
          }
        ]
      }
    ]
  }
}
```

## Filtering Logic

A bean is considered **fully complete** and eligible for archiving when:

1. Status is `"completed"` OR `"scrapped"`
2. Body contains **NO** unchecked checklist items (`- [ ]`)
3. All checklist items (if present) are checked (`- [x]`)

### Why Strict Filtering?

Moving beans with unchecked todos creates a false sense of completion and breaks the beans workflow promise that `completed = truly done`. This maintains data integrity.

## Usage

### Automatic (Default)

The hook runs automatically on every `Stop` event. No manual intervention required.

### Manual Testing

Test the hook directly:

```bash
echo '{}' | python3 .claude/hooks/post_task_bean_archiver_direct.py
```

**Example Output:**
```
============================================================
Bean Archiving Summary
============================================================
Total completed/scrapped beans: 3
Fully complete (no unchecked todos): 1
Skipped (has unchecked todos): 2

Skipped beans:
  ⏭️  LocalRagKit-8sr2: Contains unchecked checklist items
  ⏭️  LocalRagKit-93pt: Contains unchecked checklist items

Archiving 1 bean(s)...
✓ Archived LocalRagKit-76i9: LocalRagKit-76i9--agent-integration-retrieval-agent-report-format.md

============================================================
Archive Results
============================================================
✓ Successfully moved: 1
✗ Failed to move: 0
============================================================
```

### Interpreting Results

The hook outputs JSON with detailed statistics:

```json
{
  "hookSpecificOutput": {
    "hookEventName": "Stop",
    "action": "archive_completed_beans",
    "total_beans": 3,
    "fully_complete": 1,
    "skipped": 2,
    "moved": 1,
    "failed": 0,
    "moved_beans": ["LocalRagKit-76i9"],
    "failed_beans": [],
    "skipped_beans": ["LocalRagKit-8sr2", "LocalRagKit-93pt"]
  }
}
```

**Fields:**
- `total_beans`: Total completed/scrapped beans found
- `fully_complete`: Beans with no unchecked todos
- `skipped`: Beans with unchecked todos (not moved)
- `moved`: Successfully archived beans
- `failed`: Beans that failed to move (permissions, conflicts, etc.)
- `*_beans`: Arrays of bean IDs for each category

## File Operations

### What Gets Moved

**Source**: `.beans/<bean-file>.md`
**Destination**: `.beans/completed/<bean-file>.md`

The hook:
- ✅ Preserves the original filename
- ✅ Maintains file contents unchanged
- ✅ Creates `.beans/completed/` directory if needed
- ✅ Prevents overwriting existing archived beans
- ✅ Handles file system errors gracefully

## Debugging

Run Claude Code with debug flag to see hook execution:

```bash
claude --debug
```

Look for hook output in the logs showing:
- Which beans were found
- Which were filtered out (and why)
- The `/yolo` instruction generated

## Configuration

Edit `.claude/hooks/post_task_bean_archiver_direct.py` to customize:

```python
# Line 40: Adjust timeout for bean queries (default: 10 seconds)
timeout=10

# Line 62: Adjust regex pattern for unchecked todos
unchecked_pattern = r'^\s*-\s+\[\s+\]\s+'

# Line 101: Change archive directory
archive_dir = Path('.beans/completed')
```

## Security Considerations

- **Safe file operations**: Uses `shutil.move()` with conflict detection
- **Non-blocking**: Hook always exits with code 0 to avoid disrupting workflow
- **Timeout protection**: Bean queries timeout after 10 seconds
- **Error handling**: Gracefully handles missing beans CLI or query failures
- **Overwrite protection**: Refuses to overwrite existing archived beans
- **Permission handling**: Reports permission errors without crashing

## Troubleshooting

### "Failed to query beans" error

**Cause**: `beans` CLI not in PATH or not installed

**Fix**: Ensure beans is installed and accessible:
```bash
which beans
beans --version
```

### Hook not running

**Cause**: Hook might not be triggered on Stop event

**Fix**:
1. Verify hook is in `.claude/hooks.json` under `"Stop"` event
2. Ensure hook script is executable: `chmod +x .claude/hooks/post_task_bean_archiver_direct.py`
3. Test manually: `echo '{}' | python3 .claude/hooks/post_task_bean_archiver_direct.py`

### "Destination already exists" error

**Cause**: Bean file already exists in `.beans/completed/`

**Fix**:
1. Check if the bean was previously archived
2. Delete or rename the existing archived version
3. Re-run the hook

### Beans not being filtered correctly

**Cause**: Regex pattern not matching unchecked todos

**Fix**: Check bean body format. Pattern matches:
- `- [ ]` (space inside brackets)
- `  - [ ]` (with indentation)

Does NOT match:
- `- []` (no space)
- `- [x]` (checked)

## Examples

### Bean 1: Fully Complete (Will Archive)

```markdown
## Checklist
- [x] Implement feature
- [x] Write tests
- [x] Update docs
```

**Result**: ✅ Eligible for archiving

### Bean 2: Has Unchecked Items (Will Skip)

```markdown
## Checklist
- [x] Implement feature
- [ ] Write tests  ← Unchecked!
- [x] Update docs
```

**Result**: ⏭️ Skipped with reason: "Contains unchecked checklist items"

### Bean 3: No Checklist (Will Archive)

```markdown
Simple bean with no checklist.
Everything is complete.
```

**Result**: ✅ Eligible for archiving

## Future Enhancements

Potential improvements:

1. ✅ **Direct file moving**: ~~Implement actual `mv` commands~~ **DONE** (enhanced version)
2. **Git integration**: Automatically commit archived beans
3. **Notification**: Desktop alert when beans are archived
4. **Archive manifest**: Create index of archived beans with timestamps
5. **Undo capability**: Quick restore of recently archived beans
6. **Batch mode**: Archive multiple completed beans in one transaction

## See Also

- [Beans CLI Documentation](../../.beans/README.md)
- [Claude Code Hooks Guide](.claude/hooks/README.md)
- `/yolo` skill documentation
