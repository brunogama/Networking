#!/bin/bash
#
# Report Formatter Library
# Provides formatted output utilities for quality checks
#
# Usage: source this file from post-operation-quality hook

# Format a warning message with file location
format_warning() {
  local file_path="$1"
  local line_number="$2"
  local message="$3"
  local rel_path="${file_path#$PROJECT_ROOT/}"

  if [ -n "$line_number" ]; then
    echo "$rel_path:$line_number: $message"
  else
    echo "$rel_path: $message"
  fi
}

# Format a critical violation message
format_critical() {
  local file_path="$1"
  local line_number="$2"
  local message="$3"
  local rel_path="${file_path#$PROJECT_ROOT/}"

  if [ -n "$line_number" ]; then
    echo "$rel_path:$line_number: $message"
  else
    echo "$rel_path: $message"
  fi
}

# Print a section header
print_section_header() {
  local title="$1"
  echo ""
  echo -e "${BOLD}$title${NC}"
  echo -e "${BLUE}────────────────────────────────────────${NC}"
}

# Print a progress indicator
print_progress() {
  local current="$1"
  local total="$2"
  local item="$3"
  printf "\r  [%d/%d] %s" "$current" "$total" "$item"
}

# Clear progress line
clear_progress() {
  printf "\r                                                              \r"
}

# Format duration in human-readable format
format_duration() {
  local seconds="$1"
  if [ "$seconds" -lt 60 ]; then
    echo "${seconds}s"
  else
    local minutes=$((seconds / 60))
    local remaining=$((seconds % 60))
    echo "${minutes}m ${remaining}s"
  fi
}

# Print summary statistics
print_summary_stats() {
  local files_checked="$1"
  local warnings="$2"
  local violations="$3"
  local auto_fixes="$4"

  echo ""
  echo -e "${BOLD}Statistics:${NC}"
  echo "  Files checked: $files_checked"
  echo "  Auto-fixes applied: $auto_fixes"
  echo "  Warnings: $warnings"
  echo "  Critical violations: $violations"
}

# Format file path for display (truncate if too long)
format_path() {
  local path="$1"
  local max_length="${2:-60}"

  if [ ${#path} -gt "$max_length" ]; then
    echo "...${path: -$((max_length-3))}"
  else
    echo "$path"
  fi
}

# Print a table row
print_table_row() {
  local col1="$1"
  local col2="$2"
  local col3="$3"
  printf "  %-30s %-20s %s\n" "$col1" "$col2" "$col3"
}

# Print check result (pass/fail)
print_check_result() {
  local check_name="$1"
  local passed="$2"
  local details="$3"

  if [ "$passed" = "true" ]; then
    echo -e "  ${GREEN}✓${NC} $check_name"
  else
    echo -e "  ${RED}✗${NC} $check_name: $details"
  fi
}

# Print a diff-style output for violations
print_diff_line() {
  local line_type="$1"  # + or -
  local content="$2"

  if [ "$line_type" = "+" ]; then
    echo -e "  ${GREEN}+ $content${NC}"
  elif [ "$line_type" = "-" ]; then
    echo -e "  ${RED}- $content${NC}"
  else
    echo "    $content"
  fi
}

# JSON escape helper for structured output
json_escape() {
  local text="$1"
  echo "$text" | sed 's/\\/\\\\/g; s/"/\\"/g; s/\t/\\t/g; s/\n/\\n/g'
}

# Output in JSON format for machine parsing
output_json_report() {
  local warnings_json=""
  local violations_json=""
  local fixes_json=""

  # Build warnings array
  for w in "${WARNINGS[@]}"; do
    [ -n "$warnings_json" ] && warnings_json+=","
    warnings_json+="\"$(json_escape "$w")\""
  done

  # Build violations array
  for v in "${CRITICAL_VIOLATIONS[@]}"; do
    [ -n "$violations_json" ] && violations_json+=","
    violations_json+="\"$(json_escape "$v")\""
  done

  # Build fixes array
  for f in "${AUTO_FIXES[@]}"; do
    [ -n "$fixes_json" ] && fixes_json+=","
    fixes_json+="\"$(json_escape "$f")\""
  done

  cat <<EOF
{
  "warnings": [$warnings_json],
  "violations": [$violations_json],
  "auto_fixes": [$fixes_json],
  "exit_code": $EXIT_CODE
}
EOF
}
