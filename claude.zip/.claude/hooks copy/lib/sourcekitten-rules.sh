#!/bin/bash
#
# SourceKitten-based Rule Validation Library
# Provides AST-level checks for RULES.md compliance
#
# Usage: source this file from post-operation-quality hook

# Module layer mapping based on Package.swift architecture
# Layer 0: Core (no dependencies)
# Layer 1: Math/Parsing (depends on Core)
# Layer 2: Indexing/Quantization (depends on Layer 1)
# Layer 3: SQLite (depends on Layer 2, GRDB)
# Layer 4: SQLite integrations (depends on Layer 3)
# Layer 5: Facades (depends on all)

# Get module layer from module name
get_module_layer() {
  local module="$1"
  case "$module" in
    "SwiftSQLiteVecCore") echo 0 ;;
    "SwiftSQLiteVecVectorMath") echo 1 ;;
    "SwiftSQLiteVecParsing") echo 1 ;;
    "SwiftSQLiteVecQuantization") echo 2 ;;
    "SwiftSQLiteVecIndexing") echo 2 ;;
    "SwiftSQLiteVecGraphCore") echo 2 ;;
    "SwiftSQLiteVecLearningCore") echo 2 ;;
    "SwiftSQLiteVecIngestionCore") echo 2 ;;
    "SwiftSQLiteVecIngestionText") echo 3 ;;
    "SwiftSQLiteVecIngestionMarkdown") echo 3 ;;
    "SwiftSQLiteVecIngestionHTML") echo 3 ;;
    "SwiftSQLiteVecIngestionPDF") echo 3 ;;
    "SwiftSQLiteVecSQLite") echo 3 ;;
    "SwiftSQLiteVecCypher") echo 3 ;;
    "SwiftSQLiteVecIndexingSQLite") echo 4 ;;
    "SwiftSQLiteVecGraphSQLite") echo 4 ;;
    "SwiftSQLiteVecLearningSQLite") echo 4 ;;
    "SwiftSQLiteVecSyncCloudKit") echo 4 ;;
    "SwiftSQLiteVecIngestion") echo 4 ;;
    "SwiftSQLiteVec") echo 5 ;;
    "Tests") echo 99 ;; # Tests can import anything
    *) echo 5 ;;
  esac
}

# Get module name from file path
get_module_from_path() {
  local file_path="$1"
  if [[ "$file_path" == *"/Sources/"* ]]; then
    echo "$file_path" | sed 's|.*/Sources/\([^/]*\)/.*|\1|'
  elif [[ "$file_path" == *"/Tests/"* ]]; then
    echo "Tests"
  else
    echo "Unknown"
  fi
}

# Check layer dependencies - lower layers cannot import higher layers
check_layer_dependencies() {
  local file_path="$1"
  local sk_structure="$2"
  local module=$(get_module_from_path "$file_path")
  local module_layer=$(get_module_layer "$module")

  # Extract imports from file
  local imports=$(grep -E "^import\s+SwiftSQLiteVec" "$file_path" 2>/dev/null | sed 's/import //')

  for import in $imports; do
    local import_layer=$(get_module_layer "$import")
    if [ "$import_layer" -gt "$module_layer" ]; then
      CRITICAL_VIOLATIONS+=("Layer violation: $module (L$module_layer) imports $import (L$import_layer)")
    fi
  done
}

# Check file length (RULES.md: max 400 lines, warning at 200)
check_file_length() {
  local file_path="$1"
  local line_count=$(wc -l < "$file_path" | tr -d ' ')
  local rel_path="${file_path#$PROJECT_ROOT/}"

  if [ "$line_count" -gt 400 ]; then
    CRITICAL_VIOLATIONS+=("$rel_path: $line_count lines (max 400) - split into smaller files")
  elif [ "$line_count" -gt 200 ]; then
    WARNINGS+=("$rel_path: $line_count lines - consider splitting")
  fi
}

# Check one type per file (from RULES.md SRP)
check_one_type_per_file() {
  local file_path="$1"
  local sk_structure="$2"
  local rel_path="${file_path#$PROJECT_ROOT/}"

  # Count top-level type declarations
  local type_count=0
  if [ -n "$sk_structure" ]; then
    # Use SourceKitten structure
    type_count=$(echo "$sk_structure" | grep -c '"key.kind" : "source.lang.swift.decl\.\(class\|struct\|enum\|actor\|protocol\)"' || echo "0")
  else
    # Fallback to pattern matching
    type_count=$(grep -cE "^(public |private |internal |fileprivate |open )?(class|struct|enum|actor|protocol) " "$file_path" 2>/dev/null || echo "0")
  fi

  if [ "$type_count" -gt 2 ]; then
    WARNINGS+=("$rel_path: $type_count top-level types - prefer one type per file")
  fi
}

# Check cyclomatic complexity via nesting depth
check_cyclomatic_complexity() {
  local file_path="$1"
  local sk_structure="$2"
  local rel_path="${file_path#$PROJECT_ROOT/}"

  # Count nested control structures (rough heuristic)
  local max_depth=$(grep -E "(if |for |while |switch |guard )" "$file_path" 2>/dev/null | wc -l | tr -d ' ')

  if [ "$max_depth" -gt 50 ]; then
    WARNINGS+=("$rel_path: High control flow complexity ($max_depth) - consider extracting methods")
  fi
}

# Check production safety - no fatalError/preconditionFailure in production code
check_production_safety() {
  local file_path="$1"
  local rel_path="${file_path#$PROJECT_ROOT/}"

  # Skip test files
  if [[ "$file_path" == *"/Tests/"* ]]; then
    return
  fi

  local fatal_count=$(grep -cE "\b(fatalError|preconditionFailure)\s*\(" "$file_path" 2>/dev/null || echo "0")
  if [ "$fatal_count" -gt 0 ]; then
    CRITICAL_VIOLATIONS+=("$rel_path: $fatal_count fatalError/preconditionFailure calls - use Result/Optional instead")
  fi
}

# Check for primitive obsession - raw String/Int IDs
check_primitive_obsession() {
  local file_path="$1"
  local sk_structure="$2"
  local rel_path="${file_path#$PROJECT_ROOT/}"

  # Skip test files and type definition files
  if [[ "$file_path" == *"/Tests/"* ]] || [[ "$file_path" == *"ID.swift"* ]]; then
    return
  fi

  # Look for obvious patterns like "var id: String" or "let userId: Int"
  local primitive_ids=$(grep -cE "(var|let)\s+\w*[Ii]d\s*:\s*(String|Int)" "$file_path" 2>/dev/null || echo "0")
  if [ "$primitive_ids" -gt 2 ]; then
    WARNINGS+=("$rel_path: $primitive_ids primitive ID types - consider type-safe wrappers")
  fi
}

# Check for getter methods that should be computed properties
check_getter_methods() {
  local file_path="$1"
  local rel_path="${file_path#$PROJECT_ROOT/}"

  local getters=$(grep -cE "func\s+get[A-Z]\w*\s*\(\s*\)" "$file_path" 2>/dev/null || echo "0")
  if [ "$getters" -gt 0 ]; then
    WARNINGS+=("$rel_path: $getters getter methods - use computed properties instead")
  fi
}

# Check for antipattern utility/helper/manager/handler suffixes
check_utility_suffixes() {
  local file_path="$1"
  local rel_path="${file_path#$PROJECT_ROOT/}"

  # Check type names for antipattern suffixes
  local bad_suffixes=$(grep -cE "(class|struct|enum|actor)\s+\w+(Utility|Helper|Manager|Handler|Processor)[^a-zA-Z]" "$file_path" 2>/dev/null || echo "0")
  if [ "$bad_suffixes" -gt 0 ]; then
    WARNINGS+=("$rel_path: Type names with Utility/Helper/Manager suffix - use descriptive names")
  fi
}

# Check Sendable compliance for types crossing isolation
check_sendable_compliance() {
  local file_path="$1"
  local sk_structure="$2"
  local rel_path="${file_path#$PROJECT_ROOT/}"

  # Skip test files
  if [[ "$file_path" == *"/Tests/"* ]]; then
    return
  fi

  # Check for actor types that should have Sendable associated types
  local actor_count=$(grep -cE "^(public |private |internal |)actor\s+" "$file_path" 2>/dev/null || echo "0")
  if [ "$actor_count" -gt 0 ]; then
    local sendable_count=$(grep -cE "@Sendable|: Sendable" "$file_path" 2>/dev/null || echo "0")
    if [ "$sendable_count" -eq 0 ]; then
      WARNINGS+=("$rel_path: Actor types but no @Sendable - verify isolation boundaries")
    fi
  fi
}

# Check actor usage for shared mutable state
check_actor_usage() {
  local file_path="$1"
  local sk_structure="$2"
  local rel_path="${file_path#$PROJECT_ROOT/}"

  # Skip test files
  if [[ "$file_path" == *"/Tests/"* ]]; then
    return
  fi

  # Look for classes with shared mutable state that might need to be actors
  local class_with_var=$(grep -cE "class\s+\w+.*\{" "$file_path" 2>/dev/null || echo "0")
  if [ "$class_with_var" -gt 0 ]; then
    # Check if class has internal synchronization
    local has_sync=$(grep -cE "(NSLock|DispatchQueue|actor\s|@MainActor)" "$file_path" 2>/dev/null || echo "0")
    local has_vars=$(grep -cE "^\s+(var|private var)\s+" "$file_path" 2>/dev/null || echo "0")
    if [ "$has_vars" -gt 3 ] && [ "$has_sync" -eq 0 ]; then
      WARNINGS+=("$rel_path: Class with mutable state - consider actor for thread safety")
    fi
  fi
}

# Check for type-safe identifiers
check_type_safe_identifiers() {
  local file_path="$1"
  local rel_path="${file_path#$PROJECT_ROOT/}"

  # This is informational - covered by primitive obsession check
  :
}
