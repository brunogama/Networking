#!/usr/bin/env python3
"""
Claude Code CQRS Hook Runner - Enhanced Version

This script integrates Claude Code hooks with the CQRS middleware system.
Uses uv for dependency management and proper Python environment isolation.
"""

import subprocess
import sys
import os
import shutil

def main():
    """Run the CQRS hook processor with uv or fallback to python."""
    try:
        # Change to project directory
        project_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        os.chdir(project_dir)

        # Try uv first, fallback to python module
        stdin_data = sys.stdin.read()

        if shutil.which("uv"):
            # Use uv run for proper dependency management
            result = subprocess.run([
                "uv", "run", "claude-hooks", "run"
            ], input=stdin_data, text=True, capture_output=True)
        else:
            # Fallback to python module execution
            result = subprocess.run([
                sys.executable, "-m", "claude_hooks_cqrs.cli", "run"
            ], input=stdin_data, text=True, capture_output=True)

        # Forward output and exit code
        if result.stdout:
            print(result.stdout, end='')
        if result.stderr:
            print(result.stderr, end='', file=sys.stderr)

        sys.exit(result.returncode)

    except FileNotFoundError as e:
        print(f"CQRS Hook Error: Command not found - {e}", file=sys.stderr)
        print("Please ensure claude-hooks-cqrs is properly installed", file=sys.stderr)
        sys.exit(1)
    except subprocess.CalledProcessError as e:
        print(f"CQRS Hook Error: Process failed with code {e.returncode}", file=sys.stderr)
        sys.exit(e.returncode)
    except Exception as e:
        print(f"CQRS Hook Error: {e}", file=sys.stderr)
        sys.exit(1)

if __name__ == "__main__":
    main()
