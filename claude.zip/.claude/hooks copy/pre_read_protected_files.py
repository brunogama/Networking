#!/usr/bin/env python3
"""
Pre-Read Protected Files Hook

Blocks AI agent from READING certain protected configuration files.
This prevents the agent from learning how to bypass hooks and governance.

FORBIDDEN files (cannot even be read):
- .pre-commit-config.yaml - Pre-commit hook configuration
- Any pre-commit related configuration files

Exit codes:
  0: File is allowed to be read
  2: File is FORBIDDEN - read blocked

Usage: Called by Claude Code pre-tool-use hook system before Read operations.
"""

import json
import os
import sys
from pathlib import Path

# Files that are FORBIDDEN from being READ by the agent
FORBIDDEN_READ_FILES = [
    ".pre-commit-config.yaml",
    ".pre-commit-config.yml",
    "pre-commit-config.yaml",
    "pre-commit-config.yml",
    ".pre-commit-hooks.yaml",
    ".pre-commit-hooks.yml",
    "pre-commit-hooks.yaml",
    "pre-commit-hooks.yml",
]

# Patterns in file paths that indicate forbidden files
FORBIDDEN_PATTERNS = [
    "pre-commit",
    "precommit",
]


def print_blocked_message(file_path: str):
    """Print a clear message explaining why the read is blocked"""
    print()
    print("=" * 80)
    print("=" * 80)
    print()
    print("    ███████╗ ██████╗ ██████╗ ██████╗ ██╗██████╗ ██████╗ ███████╗███╗   ██╗")
    print("    ██╔════╝██╔═══██╗██╔══██╗██╔══██╗██║██╔══██╗██╔══██╗██╔════╝████╗  ██║")
    print("    █████╗  ██║   ██║██████╔╝██████╔╝██║██║  ██║██║  ██║█████╗  ██╔██╗ ██║")
    print("    ██╔══╝  ██║   ██║██╔══██╗██╔══██╗██║██║  ██║██║  ██║██╔══╝  ██║╚██╗██║")
    print("    ██║     ╚██████╔╝██║  ██║██████╔╝██║██████╔╝██████╔╝███████╗██║ ╚████║")
    print("    ╚═╝      ╚═════╝ ╚═╝  ╚═╝╚═════╝ ╚═╝╚═════╝ ╚═════╝ ╚══════╝╚═╝  ╚═══╝")
    print()
    print("=" * 80)
    print("=" * 80)
    print()
    print("    ACCESS DENIED - READ BLOCKED!")
    print("    ==============================")
    print()
    print(f"    File: {file_path}")
    print()
    print("    This file is FORBIDDEN from being read by AI agents.")
    print()
    print("    WHY IS THIS BLOCKED?")
    print("    ---------------------")
    print("    - Pre-commit hooks enforce code quality governance")
    print("    - Reading these files could enable bypass strategies")
    print("    - Hook configurations are human-managed only")
    print()
    print("    THE AGENT CANNOT:")
    print("    ------------------")
    print("    - Read pre-commit configuration files")
    print("    - Learn hook bypass patterns")
    print("    - Modify or disable hooks")
    print("    - Use --no-verify or similar flags")
    print()
    print("    GOVERNANCE IS NON-NEGOTIABLE!")
    print()
    print("=" * 80)
    print("=" * 80)
    print()


def is_forbidden_file(file_path: str) -> bool:
    """Check if the file is forbidden from being read"""
    path = Path(file_path)
    filename = path.name.lower()
    path_str = str(path).lower()

    # Check exact filename matches
    for forbidden in FORBIDDEN_READ_FILES:
        if filename == forbidden.lower():
            return True

    # Check if path contains forbidden patterns
    for pattern in FORBIDDEN_PATTERNS:
        if pattern in path_str:
            # Check if it's a config file
            if filename.endswith(('.yaml', '.yml', '.json', '.toml')):
                return True

    return False


def get_file_path_from_input() -> str:
    """Extract file path from Claude tool input"""
    # Try to get file path from environment variable
    tool_input = os.environ.get("CLAUDE_TOOL_INPUT", "")

    # Try to parse tool input as JSON
    if tool_input:
        try:
            data = json.loads(tool_input)
            if isinstance(data, dict):
                if "file_path" in data:
                    return data["file_path"]
                if "path" in data:
                    return data["path"]
                if "filePath" in data:
                    return data["filePath"]
        except json.JSONDecodeError:
            # Not JSON, might be a direct path
            if tool_input.strip():
                return tool_input.strip()

    return ""


def main():
    """Check if the target file is forbidden from reading"""
    file_path = get_file_path_from_input()

    if file_path and is_forbidden_file(file_path):
        print_blocked_message(file_path)
        sys.exit(2)

    # File is allowed to be read
    sys.exit(0)


if __name__ == "__main__":
    main()
