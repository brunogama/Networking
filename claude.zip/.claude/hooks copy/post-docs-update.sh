#!/usr/bin/env bash
# post-docs-update.sh - Cleanup and optional staging after docc-api-sync-agent completes
#
# This hook runs after the docc-api-sync-agent finishes generating documentation.
# It stages new documentation files and provides a summary.

set -euo pipefail

PROJECT_DIR="${CLAUDE_PROJECT_DIR:-$(cd "$(dirname "$0")/../.." && pwd)}"
DOCC_DIR="$PROJECT_DIR/Documentation.docc"

# Read hook input
INPUT=$(cat)

log() {
    echo "[post-docs-update] $1" >&2
}

# Find recently modified documentation files (within last 5 minutes)
find_recent_docs() {
    find "$DOCC_DIR" -name "*.md" -mmin -5 2>/dev/null || true
}

# Check if there are new/modified docs
check_docs_changes() {
    local changes
    changes=$(git -C "$PROJECT_DIR" status --porcelain "$DOCC_DIR" 2>/dev/null || echo "")
    echo "$changes"
}

main() {
    local changes
    changes=$(check_docs_changes)

    if [ -z "$changes" ]; then
        log "No documentation changes detected"
        echo '{"systemMessage": "Documentation sync complete. No new files generated."}'
        exit 0
    fi

    # Count changes by type
    local new_files modified_files
    new_files=$(echo "$changes" | grep -c "^??" || echo "0")
    modified_files=$(echo "$changes" | grep -c "^ M" || echo "0")

    log "Found $new_files new and $modified_files modified documentation files"

    # List the changed files
    local file_list
    file_list=$(echo "$changes" | awk '{print $2}' | tr '\n' ', ' | sed 's/,$//')

    # Output summary for Claude
    cat <<EOF
{
    "systemMessage": "Documentation updated: $new_files new file(s), $modified_files modified file(s)",
    "additionalContext": "Documentation files ready for review:\\n$file_list\\n\\nRun 'git add Documentation.docc/' to stage these changes."
}
EOF
}

main
