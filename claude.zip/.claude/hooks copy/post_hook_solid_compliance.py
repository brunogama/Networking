#!/usr/bin/env python3
"""
Post-Hook SOLID Compliance Validation

This hook wraps the check-solid-compliance.py script and forwards all its output.
When SOLID violations are detected, it exits with code 2 to signal a validation error.

Exit codes:
  0: Success (no SOLID violations)
  2: Validation error (SOLID violations found)

Usage: Called by Claude Code post-hook system after tool execution.
"""

import subprocess
import sys
from pathlib import Path


def main():
    """Execute SOLID compliance check and forward all output"""
    # Get project root (2 levels up from .claude/hooks/)
    script_dir = Path(__file__).parent
    project_root = script_dir.parent.parent
    solid_checker_path = project_root / "scripts" / "check-solid-compliance.py"

    # Verify SOLID checker exists
    if not solid_checker_path.exists():
        print(f"⚠️  Warning: SOLID checker not found at {solid_checker_path}")
        print("   Skipping SOLID validation")
        sys.exit(0)

    # Execute SOLID checker and forward all output
    try:
        result = subprocess.run(
            [sys.executable, str(solid_checker_path)],
            cwd=str(project_root),
            capture_output=False,  # Forward output directly to stdout/stderr
            text=True,
            check=False  # Don't raise exception on non-zero exit
        )

        # Map exit codes: 0 -> 0 (success), non-zero -> 2 (validation error)
        if result.returncode == 0:
            sys.exit(0)
        else:
            # SOLID violations found
            sys.exit(2)

    except (subprocess.CalledProcessError, FileNotFoundError, PermissionError, OSError) as e:
        print(f"❌ Error executing SOLID checker: {e}")
        sys.exit(2)


if __name__ == "__main__":
    main()
