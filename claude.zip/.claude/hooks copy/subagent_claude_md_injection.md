# Subagent CLAUDE.md Injection Hook

**Automatically inject root CLAUDE.md context into all spawned subagents**

## What It Does

This hook ensures that every subagent spawned via the Task tool receives the project's CLAUDE.md configuration, rules, and conventions. Without this injection, subagents operate without knowledge of project-wide standards, leading to inconsistent code and violated rules.

## How It Works

**Trigger:** SessionStart event for subagent sessions

**Process:**
1. Detects subagent session (vs main session)
2. Locates root CLAUDE.md and project-level CLAUDE.md files
3. Smartly selects high-priority content (rules, conventions, standards)
4. Injects via 3 methods for reliability:
   - System prompt injection (JSON output)
   - Context file creation (`.claude/subagent-context.md`)
   - Environment variable (`CLAUDE_MD_CONTEXT`)

**Performance:**
- First run: 100-200ms (read and process files)
- Cached runs: <50ms (mtime-based cache validation)

## Installation

### 1. Hook Script

Already created at: `.claude/hooks/subagent_claude_md_injection.py`

Executable permissions set: `chmod +x`

### 2. Register in settings.json

Add to `.claude/settings.json`:

```json
{
  "hooks": {
    "SessionStart": [
      {
        "matcher": ".*",
        "hooks": [
          {
            "type": "command",
            "command": "cat | python3 .claude/hooks/subagent_claude_md_injection.py",
            "timeout": 5000,
            "description": "Inject root CLAUDE.md context into subagent sessions"
          }
        ]
      }
    ]
  }
}
```

**Note:** The hook internally detects if it's a subagent session and exits early for main sessions.

## Testing

### Manual Test

Test the hook with sample input:

```bash
# Test as main session (should skip)
echo '{"session_type":"main"}' | python3 .claude/hooks/subagent_claude_md_injection.py

# Expected output:
# ℹ️  Main session detected - skipping CLAUDE.md injection
```

```bash
# Test as subagent (should inject)
echo '{"session_type":"subagent"}' | python3 .claude/hooks/subagent_claude_md_injection.py

# Expected output:
# ✅ CLAUDE.md Injection Complete
# 📁 Source files: 3
# 📊 Content size: 15243 chars
# ✨ Methods used: system_prompt, context_file, env_var
# ⏱️  Execution time: 152.3ms
```

### Force Injection for Testing

To test injection without subagent detection:

```bash
FORCE_SUBAGENT_INJECTION=1 echo '{}' | python3 .claude/hooks/subagent_claude_md_injection.py
```

### Verify Context File Created

```bash
cat .claude/subagent-context.md
```

Should show processed CLAUDE.md content with header and smart-selected sections.

### Check Cache Performance

```bash
# First run (no cache)
time echo '{"session_type":"subagent"}' | python3 .claude/hooks/subagent_claude_md_injection.py

# Second run (cached)
time echo '{"session_type":"subagent"}' | python3 .claude/hooks/subagent_claude_md_injection.py

# Second run should be ~50% faster
```

## Smart Content Selection

The hook intelligently selects content to include:

### Priority Sections (Included)

- ✅ Universal rules (MUST, SHOULD, MUST NOT)
- ✅ Tech stack and dependencies
- ✅ Code style and conventions
- ✅ Security standards
- ✅ Git workflow
- ✅ Architecture patterns

### Low Priority (Excluded)

- ❌ Specific file paths (subagent has file access)
- ❌ Detailed API references (use tools to look up)
- ❌ Long examples (unless critical patterns)
- ❌ Getting started guides
- ❌ Installation instructions

### Example Output

```markdown
# Root CLAUDE.md Context for Subagent

This content is automatically injected from the project's CLAUDE.md files
to ensure all subagents follow project conventions and best practices.

Source files:
- CLAUDE.md
- Project/LocalRagKit/CLAUDE.md
- Project/LocalRagKit/.claude/CLAUDE.md

---

## Universal Rules

### MUST
- Follow RULES.md engineering standards
- All tests pass before commit
- Zero warnings policy
- One public/internal type per file (SRP)
- Files under 200 lines

### MUST NOT
- NEVER use fatalError(), try!, as! in production
- NEVER commit secrets or API keys
- NEVER skip pre-commit hooks
- NEVER add features not requested

## Tech Stack

- Swift 6.2
- macOS 14+ only
- Zero cloud dependencies
...
```

## Caching Mechanism

### Cache Structure

```json
{
  "content": "# Root CLAUDE.md Context...",
  "source_files": [
    "CLAUDE.md",
    "Project/LocalRagKit/CLAUDE.md"
  ],
  "mtimes": {
    "CLAUDE.md": 1735555200.5,
    "Project/LocalRagKit/CLAUDE.md": 1735555300.8
  }
}
```

Stored at: `.claude/.claude_md_cache.json`

### Cache Invalidation

Cache is invalidated when:
- Any source CLAUDE.md file's mtime changes (>1 second difference)
- Source file is deleted
- New CLAUDE.md file is added (detected on next scan)

### Manual Cache Clear

```bash
rm .claude/.claude_md_cache.json
```

## Injection Methods

### Method 1: System Prompt Injection

Outputs JSON payload that the hook framework or Claude Code can capture:

```json
{
  "type": "system_prompt_injection",
  "content": "# Root CLAUDE.md Context...",
  "priority": "high",
  "source": "CLAUDE.md"
}
```

This allows Claude Code to inject content directly into the subagent's system prompt.

### Method 2: Context File

Creates `.claude/subagent-context.md` with processed content. Subagents can read this file if needed:

```python
# Subagent can reference context
with open('.claude/subagent-context.md') as f:
    context = f.read()
```

### Method 3: Environment Variable

Sets `CLAUDE_MD_CONTEXT` env var with content (truncated for env var limits):

```bash
echo $CLAUDE_MD_CONTEXT
# Outputs first 500 chars of content
```

## Troubleshooting

### Hook Not Firing

**Check registration:**
```bash
cat .claude/settings.json | python3 -m json.tool | grep -A 10 "SessionStart"
```

Should show the hook configuration.

**Check permissions:**
```bash
ls -l .claude/hooks/subagent_claude_md_injection.py
# Should show: -rwxr-xr-x
```

### No CLAUDE.md Found

**Check files exist:**
```bash
find . -name "CLAUDE.md" -type f | head -5
```

Should show at least root CLAUDE.md.

**If missing:**
Create root CLAUDE.md with project rules and conventions.

### Injection Failed

**Check logs:**
The hook outputs detailed logs to stderr. Look for:
- ❌ Method failures
- ⚠️ Warnings about file access
- ℹ️ Cache hits/misses

**Test manually:**
```bash
python3 .claude/hooks/subagent_claude_md_injection.py < test_input.json 2>&1 | tee injection_test.log
```

### Cache Issues

**Stale cache:**
```bash
rm .claude/.claude_md_cache.json
```

**Cache too large:**
The hook truncates content >40k chars automatically. Check:
```bash
cat .claude/.claude_md_cache.json | jq '.content | length'
```

### Performance Degradation

**Slow injection (>200ms):**
- Check cache is working (should be <50ms on cache hits)
- Reduce CLAUDE.md file sizes
- Remove low-priority sections from CLAUDE.md

**Check execution time:**
```bash
time FORCE_SUBAGENT_INJECTION=1 python3 .claude/hooks/subagent_claude_md_injection.py < test_input.json
```

## Configuration

### Adjust Truncation Limit

Edit `.claude/hooks/subagent_claude_md_injection.py`:

```python
# Default: 40k chars (~10k tokens)
max_chars = 40000

# Increase for larger context:
max_chars = 80000  # ~20k tokens
```

### Change Priority Keywords

Edit `extract_priority_sections()` function:

```python
priority_keywords = [
    'rule', 'must', 'should', 'convention',
    'standard', 'workflow', 'architecture',
    # Add more:
    'pattern', 'principle', 'guideline'
]
```

### Disable Caching

Set cache to None:

```python
def load_cache() -> Optional[Dict]:
    return None  # Always fresh read
```

## Best Practices

1. **Keep CLAUDE.md focused** - Only include rules subagents need
2. **Use clear headers** - Helps smart selection algorithm
3. **Mark critical rules** - Use MUST, NEVER, ALWAYS keywords
4. **Review injected content** - Check `.claude/subagent-context.md` periodically
5. **Monitor performance** - Cache should keep injection <50ms
6. **Clear cache on major changes** - `rm .claude/.claude_md_cache.json`

## Related

- **Hook framework:** `.claude/hooks/README.md`
- **SessionStart hook:** `.claude/hooks/session_start.py`
- **CLAUDE.md specification:** Root CLAUDE.md files

---

**Created:** December 2024
**Hook Type:** SessionStart
**Trigger:** Subagent session initialization
**Performance:** <200ms first run, <50ms cached
