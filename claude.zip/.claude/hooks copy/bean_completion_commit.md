# Bean Completion Commit Hook

**Automatic smart-commit trigger when beans are marked as completed**

## What It Does

This hook automatically invokes the `smart-commit` slash command whenever you complete a bean issue, allowing the smart-commit agent to choose the optimal commit strategy based on the work that was done.

## How It Works

1. **Detects bean completion** - Monitors `beans update` commands with `--status completed`
2. **Fetches bean context** - Retrieves the bean's title, type, body, and tags
3. **Triggers smart-commit** - Invokes the smart-commit command with full context
4. **Agent chooses strategy** - Smart-commit agent analyzes changes and creates optimal commit

## Workflow Example

```bash
# You're working on a feature bean
beans create "Add vector search caching" -t feature -s in-progress

# ... do the work, write code, run tests ...

# Mark bean as completed - this triggers the hook!
beans update beans-abc1 --status completed
```

**What happens automatically:**

```
🎯 Bean Completion Detected!
================================================
📋 Bean: beans-abc1 - Add vector search caching
🏷️  Type: feature

💡 Triggering smart-commit to create optimal commit...
================================================

Smart-commit agent:
→ Runs git status to see what changed
→ Runs git diff to understand the changes
→ Analyzes the bean description for context
→ Chooses commit type (feat/fix/refactor/etc)
→ Crafts comprehensive commit message
→ Creates commit with: Closes #beans-abc1
```

## Configuration

The hook is configured in `.claude/settings.json`:

```json
{
  "hooks": {
    "PostToolUse": [
      {
        "matcher": "Bash",
        "hooks": [
          {
            "type": "command",
            "command": "cat | python3 .claude/hooks/bean_completion_commit.py",
            "timeout": 10,
            "description": "Trigger smart-commit when bean is marked as completed"
          }
        ]
      }
    ]
  }
}
```

## Requirements

- **beans CLI** - Issue tracker (`brew install beans` or from source)
- **smart-commit skill** - The slash command that creates intelligent commits
- **Python 3** - For hook execution
- **Git repository** - Must be in a git repo for commits

## Smart-Commit Integration

The hook provides the smart-commit agent with:

- **Bean ID and title** - What work was completed
- **Bean type** - Feature, bug, task, etc.
- **Work description** - From the bean body
- **Tags** - For categorization

The smart-commit agent uses this to:

1. **Analyze git changes** (`git status`, `git diff`)
2. **Choose commit type** (feat, fix, refactor, docs, test, chore)
3. **Determine scope** (based on files changed)
4. **Write comprehensive message** (what, why, how)
5. **Add footer** with `Closes #beans-abc1` reference

## Commit Message Format

The smart-commit agent typically creates commits like:

```
feat(vector-search): add LRU caching layer with TTL support

Implements caching for vector search results to reduce duplicate
embedding computations. Cache uses LRU eviction policy with
configurable TTL (default 5 minutes).

- VectorSearchCache actor for thread-safe access
- Automatic eviction on TTL expiration
- Metrics tracking (hits, misses, evictions)
- Comprehensive test coverage

Closes #beans-abc1
```

## Customization

### Adjust Smart-Commit Behavior

The hook passes context to smart-commit but lets the agent make all decisions. To customize commit behavior, modify the smart-commit skill instead of this hook.

### Change Hook Trigger

To trigger on different bean statuses, edit the `is_bean_completion_command()` function:

```python
def is_bean_completion_command(command: str) -> bool:
    # Currently triggers on: --status completed
    # Could also trigger on: --status in-review, etc.
    return bool(re.search(r'(?:--status|-s)\s+completed', command))
```

### Disable Hook

To temporarily disable, comment out the hook in `.claude/settings.json`:

```json
{
  "hooks": {
    "PostToolUse": [
      {
        "matcher": "Bash",
        "hooks": [
          // {
          //   "type": "command",
          //   "command": "cat | python3 .claude/hooks/bean_completion_commit.py",
          //   "timeout": 10,
          //   "description": "Trigger smart-commit when bean is marked as completed"
          // }
        ]
      }
    ]
  }
}
```

## Troubleshooting

### Hook not firing

**Check:** Is the hook registered in `.claude/settings.json`?
```bash
cat .claude/settings.json | jq '.hooks.PostToolUse[] | select(.matcher == "Bash")'
```

**Check:** Is the script executable?
```bash
ls -l .claude/hooks/bean_completion_commit.py
# Should show: -rwxr-xr-x (executable)
```

**Fix:**
```bash
chmod +x .claude/hooks/bean_completion_commit.py
```

### Hook firing but smart-commit not found

**Check:** Does the smart-commit skill exist?
```bash
ls -la ~/.claude/skills/smart-commit/SKILL.md
# or
ls -la .claude/skills/smart-commit/SKILL.md
```

**Fix:** Create the smart-commit skill or use a different commit command in the hook.

### Bean content not fetched

**Check:** Is beans CLI available?
```bash
which beans
beans show <bean-id> --json
```

**Fix:** Install beans CLI or check bean ID format.

## Testing

Test the hook manually:

```bash
# 1. Create a test bean
beans create "Test hook" -t task -d "Testing bean completion hook" -s in-progress

# 2. Make some changes
echo "test" > test.txt
git add test.txt

# 3. Complete the bean (should trigger hook)
beans update <bean-id> --status completed

# 4. Check that smart-commit was invoked
# Look for: "🎯 Bean Completion Detected!" in the output
```

## Performance

- **Hook execution time:** <100ms (bean fetch + JSON parsing)
- **Total workflow time:** Depends on smart-commit agent (typically 2-5 seconds)
- **Non-blocking:** Errors in hook don't block bean updates
- **Timeout:** 10 seconds (configurable in settings.json)

## Best Practices

1. **Write descriptive bean bodies** - The smart-commit agent uses this for context
2. **Complete beans after git add** - Ensure changes are staged before marking complete
3. **Review commits** - Smart-commit is intelligent but always review before push
4. **Use bean tags** - Tags help categorize commits (e.g., "performance", "security")
5. **Reference bean ID in manual commits** - Use `Closes #beans-abc1` footer

## Related

- **Bean tracker documentation:** `beans --help`
- **Smart-commit skill:** `.claude/skills/smart-commit/SKILL.md` (or user skills)
- **Hook system:** `.claude/hooks/README.md`
- **Conventional commits:** https://www.conventionalcommits.org/

---

**Created:** December 2024
**Hook Type:** PostToolUse (Bash commands)
**Trigger:** `beans update <id> --status completed`
