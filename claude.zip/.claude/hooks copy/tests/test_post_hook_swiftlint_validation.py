#!/usr/bin/env python3
"""
Tests for post_hook_swiftlint_validation.py

Verifies that the SwiftLint post-hook executes correctly, forwards output,
and propagates exit codes as expected.
"""

import os
import subprocess
import sys
from pathlib import Path


class TestSwiftLintPostHook:
    """Test suite for the SwiftLint post-hook"""

    def __init__(self):
        self.test_dir = Path(__file__).parent
        self.hooks_dir = self.test_dir.parent
        self.project_root = self.hooks_dir.parent.parent
        self.post_hook_script = self.hooks_dir / "post_hook_swiftlint_validation.py"
        self.test_results = []
        self.passed = 0
        self.failed = 0

    def _record_result(self, name: str, passed: bool, message: str = ""):
        """Record test result"""
        status = "PASS" if passed else "FAIL"
        self.test_results.append((name, status, message))
        if passed:
            self.passed += 1
            print(f"  [PASS] {name}")
        else:
            self.failed += 1
            print(f"  [FAIL] {name}")
            if message:
                print(f"         {message}")

    def run_all_tests(self):
        """Execute all test cases"""
        print("=" * 70)
        print("POST-HOOK SWIFTLINT VALIDATION TESTS")
        print("=" * 70)
        print()

        self.test_post_hook_exists()
        self.test_post_hook_is_executable()
        self.test_post_hook_has_proper_shebang()
        self.test_post_hook_execution_no_crash()
        self.test_exit_code_propagation()
        self.test_swiftlint_not_found_handling()
        self.test_timeout_handling()
        self.test_output_forwarding()

        self.print_summary()
        return 0 if self.failed == 0 else 1

    def test_post_hook_exists(self):
        """Test that the post-hook script exists"""
        name = "post_hook_exists"
        try:
            exists = self.post_hook_script.exists()
            self._record_result(name, exists, f"Script not found: {self.post_hook_script}")
        except Exception as e:
            self._record_result(name, False, str(e))

    def test_post_hook_is_executable(self):
        """Test that the post-hook script is executable"""
        name = "post_hook_is_executable"
        try:
            if not self.post_hook_script.exists():
                self._record_result(name, False, "Script does not exist")
                return

            is_executable = os.access(self.post_hook_script, os.X_OK)
            self._record_result(
                name,
                is_executable,
                "Script is not executable. Run: chmod +x " + str(self.post_hook_script)
            )
        except Exception as e:
            self._record_result(name, False, str(e))

    def test_post_hook_has_proper_shebang(self):
        """Test that the post-hook has proper Python shebang"""
        name = "post_hook_has_proper_shebang"
        try:
            with open(self.post_hook_script, "r") as f:
                first_line = f.readline().strip()

            has_shebang = first_line.startswith("#!/usr/bin/env python3") or \
                          first_line.startswith("#!/usr/bin/python3")
            self._record_result(
                name,
                has_shebang,
                f"Invalid shebang: {first_line}"
            )
        except Exception as e:
            self._record_result(name, False, str(e))

    def test_post_hook_execution_no_crash(self):
        """Test that the post-hook executes without crashing"""
        name = "post_hook_execution_no_crash"
        try:
            result = subprocess.run(
                [sys.executable, str(self.post_hook_script)],
                cwd=str(self.project_root),
                capture_output=True,
                text=True,
                timeout=30
            )

            # Exit code 0 = success, 2 = validation error, both are valid
            # Only crash (segfault, etc) would be unexpected
            valid_exit = result.returncode in [0, 1, 2]
            self._record_result(
                name,
                valid_exit,
                f"Unexpected exit code: {result.returncode}"
            )
        except subprocess.TimeoutExpired:
            self._record_result(name, False, "Script timed out after 30 seconds")
        except Exception as e:
            self._record_result(name, False, str(e))

    def test_exit_code_propagation(self):
        """Test that exit codes are properly propagated"""
        name = "exit_code_propagation"
        try:
            result = subprocess.run(
                [sys.executable, str(self.post_hook_script)],
                cwd=str(self.project_root),
                capture_output=True,
                text=True,
                timeout=30
            )

            # Valid exit codes: 0 (success), 1 (error), 2 (validation error)
            valid_codes = [0, 1, 2]
            is_valid = result.returncode in valid_codes
            self._record_result(
                name,
                is_valid,
                f"Invalid exit code: {result.returncode}. Expected one of {valid_codes}"
            )
        except subprocess.TimeoutExpired:
            self._record_result(name, False, "Script timed out")
        except Exception as e:
            self._record_result(name, False, str(e))

    def test_swiftlint_not_found_handling(self):
        """Test graceful handling when SwiftLint is not installed"""
        name = "swiftlint_not_found_handling"
        try:
            # Temporarily modify PATH to hide swiftlint
            modified_env = os.environ.copy()
            modified_env["PATH"] = "/nonexistent"

            result = subprocess.run(
                [sys.executable, str(self.post_hook_script)],
                cwd=str(self.project_root),
                capture_output=True,
                text=True,
                timeout=30,
                env=modified_env
            )

            # Should exit gracefully with 0 (skip) when SwiftLint not found
            graceful_exit = result.returncode == 0
            has_warning = "not found" in result.stdout.lower() or \
                          "not installed" in result.stdout.lower() or \
                          "warning" in result.stdout.lower()

            self._record_result(
                name,
                graceful_exit,
                f"Expected exit 0 when SwiftLint not found, got {result.returncode}"
            )
        except subprocess.TimeoutExpired:
            self._record_result(name, False, "Script timed out")
        except Exception as e:
            self._record_result(name, False, str(e))

    def test_timeout_handling(self):
        """Test that script handles timeouts properly"""
        name = "timeout_handling"
        try:
            # Script should complete within reasonable time
            result = subprocess.run(
                [sys.executable, str(self.post_hook_script)],
                cwd=str(self.project_root),
                capture_output=True,
                text=True,
                timeout=60  # Generous timeout
            )

            # If we get here, no timeout occurred
            self._record_result(name, True)
        except subprocess.TimeoutExpired:
            self._record_result(name, False, "Script timed out after 60 seconds")
        except Exception as e:
            self._record_result(name, False, str(e))

    def test_output_forwarding(self):
        """Test that output is properly forwarded"""
        name = "output_forwarding"
        try:
            result = subprocess.run(
                [sys.executable, str(self.post_hook_script)],
                cwd=str(self.project_root),
                capture_output=True,
                text=True,
                timeout=30
            )

            # Should have some output (either success or error message)
            has_output = len(result.stdout) > 0 or len(result.stderr) > 0
            self._record_result(
                name,
                has_output,
                "No output produced by script"
            )
        except subprocess.TimeoutExpired:
            self._record_result(name, False, "Script timed out")
        except Exception as e:
            self._record_result(name, False, str(e))

    def print_summary(self):
        """Print test summary"""
        print()
        print("=" * 70)
        print("TEST SUMMARY")
        print("=" * 70)
        print(f"Total:  {self.passed + self.failed}")
        print(f"Passed: {self.passed}")
        print(f"Failed: {self.failed}")
        print()

        if self.failed > 0:
            print("FAILED TESTS:")
            for name, status, message in self.test_results:
                if status == "FAIL":
                    print(f"  - {name}: {message}")
            print()


def main():
    """Run all tests"""
    tester = TestSwiftLintPostHook()
    exit_code = tester.run_all_tests()
    sys.exit(exit_code)


if __name__ == "__main__":
    main()
