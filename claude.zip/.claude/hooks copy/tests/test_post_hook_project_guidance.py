#!/usr/bin/env python3
"""
Tests for post_hook_project_guidance.py

Verifies that the project guidance pipeline post-hook executes correctly,
runs all child hooks in sequence, and propagates exit codes as expected.
"""

import os
import subprocess
import sys
from pathlib import Path


class TestProjectGuidancePostHook:
    """Test suite for the project guidance pipeline post-hook"""

    def __init__(self):
        self.test_dir = Path(__file__).parent
        self.hooks_dir = self.test_dir.parent
        self.project_root = self.hooks_dir.parent.parent
        self.post_hook_script = self.hooks_dir / "post_hook_project_guidance.py"
        self.test_results = []
        self.passed = 0
        self.failed = 0

    def _record_result(self, name: str, passed: bool, message: str = ""):
        """Record test result"""
        status = "PASS" if passed else "FAIL"
        self.test_results.append((name, status, message))
        if passed:
            self.passed += 1
            print(f"  [PASS] {name}")
        else:
            self.failed += 1
            print(f"  [FAIL] {name}")
            if message:
                print(f"         {message}")

    def run_all_tests(self):
        """Execute all test cases"""
        print("=" * 70)
        print("POST-HOOK PROJECT GUIDANCE PIPELINE TESTS")
        print("=" * 70)
        print()

        self.test_post_hook_exists()
        self.test_post_hook_is_executable()
        self.test_post_hook_has_proper_shebang()
        self.test_post_hook_execution_no_crash()
        self.test_exit_code_propagation()
        self.test_pipeline_class_exists()
        self.test_hooks_defined()
        self.test_timeout_handling()
        self.test_output_forwarding()
        self.test_child_hooks_exist()

        self.print_summary()
        return 0 if self.failed == 0 else 1

    def test_post_hook_exists(self):
        """Test that the post-hook script exists"""
        name = "post_hook_exists"
        try:
            exists = self.post_hook_script.exists()
            self._record_result(name, exists, f"Script not found: {self.post_hook_script}")
        except Exception as e:
            self._record_result(name, False, str(e))

    def test_post_hook_is_executable(self):
        """Test that the post-hook script is executable"""
        name = "post_hook_is_executable"
        try:
            if not self.post_hook_script.exists():
                self._record_result(name, False, "Script does not exist")
                return

            is_executable = os.access(self.post_hook_script, os.X_OK)
            self._record_result(
                name,
                is_executable,
                "Script is not executable. Run: chmod +x " + str(self.post_hook_script)
            )
        except Exception as e:
            self._record_result(name, False, str(e))

    def test_post_hook_has_proper_shebang(self):
        """Test that the post-hook has proper Python shebang"""
        name = "post_hook_has_proper_shebang"
        try:
            with open(self.post_hook_script, "r") as f:
                first_line = f.readline().strip()

            has_shebang = first_line.startswith("#!/usr/bin/env python3") or \
                          first_line.startswith("#!/usr/bin/python3")
            self._record_result(
                name,
                has_shebang,
                f"Invalid shebang: {first_line}"
            )
        except Exception as e:
            self._record_result(name, False, str(e))

    def test_post_hook_execution_no_crash(self):
        """Test that the post-hook executes without crashing"""
        name = "post_hook_execution_no_crash"
        try:
            result = subprocess.run(
                [sys.executable, str(self.post_hook_script)],
                cwd=str(self.project_root),
                capture_output=True,
                text=True,
                timeout=120  # Pipeline may take longer
            )

            # Exit code 0 = success, 1 = error, 2 = validation error, all valid
            valid_exit = result.returncode in [0, 1, 2]
            self._record_result(
                name,
                valid_exit,
                f"Unexpected exit code: {result.returncode}"
            )
        except subprocess.TimeoutExpired:
            self._record_result(name, False, "Script timed out after 120 seconds")
        except Exception as e:
            self._record_result(name, False, str(e))

    def test_exit_code_propagation(self):
        """Test that exit codes are properly propagated"""
        name = "exit_code_propagation"
        try:
            result = subprocess.run(
                [sys.executable, str(self.post_hook_script)],
                cwd=str(self.project_root),
                capture_output=True,
                text=True,
                timeout=120
            )

            # Valid exit codes: 0 (success), 1 (error), 2 (validation error)
            valid_codes = [0, 1, 2]
            is_valid = result.returncode in valid_codes
            self._record_result(
                name,
                is_valid,
                f"Invalid exit code: {result.returncode}. Expected one of {valid_codes}"
            )
        except subprocess.TimeoutExpired:
            self._record_result(name, False, "Script timed out")
        except Exception as e:
            self._record_result(name, False, str(e))

    def test_pipeline_class_exists(self):
        """Test that HookPipeline class is defined in the script"""
        name = "pipeline_class_exists"
        try:
            with open(self.post_hook_script, "r") as f:
                content = f.read()

            has_class = "class HookPipeline" in content
            self._record_result(
                name,
                has_class,
                "HookPipeline class not found in script"
            )
        except Exception as e:
            self._record_result(name, False, str(e))

    def test_hooks_defined(self):
        """Test that define_hooks method exists and returns hooks"""
        name = "hooks_defined"
        try:
            with open(self.post_hook_script, "r") as f:
                content = f.read()

            has_method = "def define_hooks" in content
            has_return = "return [" in content or "return[\n" in content
            self._record_result(
                name,
                has_method and has_return,
                "define_hooks method not properly implemented"
            )
        except Exception as e:
            self._record_result(name, False, str(e))

    def test_timeout_handling(self):
        """Test that script handles timeouts properly"""
        name = "timeout_handling"
        try:
            # Script should complete within reasonable time
            result = subprocess.run(
                [sys.executable, str(self.post_hook_script)],
                cwd=str(self.project_root),
                capture_output=True,
                text=True,
                timeout=180  # Very generous timeout for pipeline
            )

            # If we get here, no timeout occurred
            self._record_result(name, True)
        except subprocess.TimeoutExpired:
            self._record_result(name, False, "Script timed out after 180 seconds")
        except Exception as e:
            self._record_result(name, False, str(e))

    def test_output_forwarding(self):
        """Test that output is properly forwarded"""
        name = "output_forwarding"
        try:
            result = subprocess.run(
                [sys.executable, str(self.post_hook_script)],
                cwd=str(self.project_root),
                capture_output=True,
                text=True,
                timeout=120
            )

            # Should have some output (pipeline status messages)
            has_output = len(result.stdout) > 0 or len(result.stderr) > 0
            self._record_result(
                name,
                has_output,
                "No output produced by script"
            )
        except subprocess.TimeoutExpired:
            self._record_result(name, False, "Script timed out")
        except Exception as e:
            self._record_result(name, False, str(e))

    def test_child_hooks_exist(self):
        """Test that child hooks referenced in pipeline exist"""
        name = "child_hooks_exist"
        try:
            # List of expected child hooks
            child_hooks = [
                "post_hook_srp_principles_validation.py",
                "post_hook_solid_compliance.py",
                "post_hook_swiftformat_validation.py",
                "post_hook_swiftlint_validation.py",
            ]

            missing = []
            for hook in child_hooks:
                hook_path = self.hooks_dir / hook
                if not hook_path.exists():
                    missing.append(hook)

            all_exist = len(missing) == 0
            self._record_result(
                name,
                all_exist,
                f"Missing child hooks: {', '.join(missing)}" if missing else ""
            )
        except Exception as e:
            self._record_result(name, False, str(e))

    def print_summary(self):
        """Print test summary"""
        print()
        print("=" * 70)
        print("TEST SUMMARY")
        print("=" * 70)
        print(f"Total:  {self.passed + self.failed}")
        print(f"Passed: {self.passed}")
        print(f"Failed: {self.failed}")
        print()

        if self.failed > 0:
            print("FAILED TESTS:")
            for name, status, message in self.test_results:
                if status == "FAIL":
                    print(f"  - {name}: {message}")
            print()


def main():
    """Run all tests"""
    tester = TestProjectGuidancePostHook()
    exit_code = tester.run_all_tests()
    sys.exit(exit_code)


if __name__ == "__main__":
    main()
