#!/usr/bin/env python3
"""
Test Runner for Post-Hook Tests

Executes all post-hook test suites and generates a combined report.
"""

import subprocess
import sys
from pathlib import Path


def run_all_tests():
    """Run all test files and collect results"""
    test_dir = Path(__file__).parent
    # Include both pre-hook and post-hook tests
    test_files = sorted(test_dir.glob("test_*.py"))

    print("=" * 80)
    print("POST-HOOK TEST SUITE RUNNER")
    print("=" * 80)
    print()
    print(f"Found {len(test_files)} test file(s)")
    print()

    total_passed = 0
    total_failed = 0
    results = []

    for i, test_file in enumerate(test_files, 1):
        print("-" * 80)
        print(f"[{i}/{len(test_files)}] Running: {test_file.name}")
        print("-" * 80)
        print()

        try:
            result = subprocess.run(
                [sys.executable, str(test_file)],
                capture_output=False,
                text=True,
                timeout=180
            )

            status = "PASS" if result.returncode == 0 else "FAIL"
            results.append((test_file.name, status, result.returncode))

            if result.returncode == 0:
                total_passed += 1
            else:
                total_failed += 1

        except subprocess.TimeoutExpired:
            results.append((test_file.name, "TIMEOUT", -1))
            total_failed += 1
            print(f"TIMEOUT: {test_file.name} timed out after 180 seconds")
        except Exception as e:
            results.append((test_file.name, "ERROR", -1))
            total_failed += 1
            print(f"ERROR: {test_file.name} - {e}")

        print()

    # Final summary
    print("=" * 80)
    print("FINAL TEST SUITE SUMMARY")
    print("=" * 80)
    print()
    print(f"Test Files: {len(test_files)}")
    print(f"Passed:     {total_passed}")
    print(f"Failed:     {total_failed}")
    print()

    if total_failed > 0:
        print("FAILED TEST FILES:")
        for name, status, code in results:
            if status != "PASS":
                print(f"  - {name} ({status}, exit code: {code})")
        print()

    print("=" * 80)

    return 0 if total_failed == 0 else 1


def main():
    """Entry point"""
    exit_code = run_all_tests()
    sys.exit(exit_code)


if __name__ == "__main__":
    main()
