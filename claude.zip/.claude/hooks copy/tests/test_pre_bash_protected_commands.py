#!/usr/bin/env python3
"""
Tests for pre_bash_protected_commands.py

Verifies that the pre-bash hook correctly blocks dangerous/bypass commands.
"""

import os
import subprocess
import sys
from pathlib import Path


class TestPreBashProtectedCommands:
    """Test suite for the pre-bash protected commands hook"""

    def __init__(self):
        self.test_dir = Path(__file__).parent
        self.hooks_dir = self.test_dir.parent
        self.project_root = self.hooks_dir.parent.parent
        self.hook_script = self.hooks_dir / "pre_bash_protected_commands.py"
        self.test_results = []
        self.passed = 0
        self.failed = 0

    def _record_result(self, name: str, passed: bool, message: str = ""):
        """Record test result"""
        status = "PASS" if passed else "FAIL"
        self.test_results.append((name, status, message))
        if passed:
            self.passed += 1
            print(f"  [PASS] {name}")
        else:
            self.failed += 1
            print(f"  [FAIL] {name}")
            if message:
                print(f"         {message}")

    def run_all_tests(self):
        """Execute all test cases"""
        print("=" * 70)
        print("PRE-BASH PROTECTED COMMANDS HOOK TESTS")
        print("=" * 70)
        print()

        self.test_hook_exists()
        self.test_hook_is_executable()
        self.test_blocks_no_verify()
        self.test_blocks_skip_env()
        self.test_blocks_force_push()
        self.test_allows_normal_commands()
        self.test_blocks_cat_pre_commit()

        self.print_summary()
        return 0 if self.failed == 0 else 1

    def test_hook_exists(self):
        """Test that the hook script exists"""
        name = "hook_exists"
        exists = self.hook_script.exists()
        self._record_result(name, exists, f"Script not found: {self.hook_script}")

    def test_hook_is_executable(self):
        """Test that the hook script is executable"""
        name = "hook_is_executable"
        if not self.hook_script.exists():
            self._record_result(name, False, "Script does not exist")
            return
        is_executable = os.access(self.hook_script, os.X_OK)
        self._record_result(name, is_executable)

    def test_blocks_no_verify(self):
        """Test that --no-verify is blocked"""
        name = "blocks_no_verify"
        env = os.environ.copy()
        env["CLAUDE_TOOL_INPUT"] = '{"command": "git commit --no-verify -m \\"test\\""}'

        result = subprocess.run(
            [sys.executable, str(self.hook_script)],
            env=env,
            capture_output=True,
            text=True,
            timeout=10
        )

        self._record_result(
            name,
            result.returncode == 2,
            f"Expected exit 2, got {result.returncode}"
        )

    def test_blocks_skip_env(self):
        """Test that SKIP= environment variable is blocked"""
        name = "blocks_skip_env"
        env = os.environ.copy()
        env["CLAUDE_TOOL_INPUT"] = '{"command": "SKIP=swiftlint git commit -m \\"test\\""}'

        result = subprocess.run(
            [sys.executable, str(self.hook_script)],
            env=env,
            capture_output=True,
            text=True,
            timeout=10
        )

        self._record_result(
            name,
            result.returncode == 2,
            f"Expected exit 2, got {result.returncode}"
        )

    def test_blocks_force_push(self):
        """Test that git push --force is blocked"""
        name = "blocks_force_push"
        env = os.environ.copy()
        env["CLAUDE_TOOL_INPUT"] = '{"command": "git push --force origin main"}'

        result = subprocess.run(
            [sys.executable, str(self.hook_script)],
            env=env,
            capture_output=True,
            text=True,
            timeout=10
        )

        self._record_result(
            name,
            result.returncode == 2,
            f"Expected exit 2, got {result.returncode}"
        )

    def test_allows_normal_commands(self):
        """Test that normal commands are allowed"""
        name = "allows_normal_commands"
        env = os.environ.copy()
        env["CLAUDE_TOOL_INPUT"] = '{"command": "swift build"}'

        result = subprocess.run(
            [sys.executable, str(self.hook_script)],
            env=env,
            capture_output=True,
            text=True,
            timeout=10
        )

        self._record_result(
            name,
            result.returncode == 0,
            f"Expected exit 0, got {result.returncode}"
        )

    def test_blocks_cat_pre_commit(self):
        """Test that cat .pre-commit-config.yaml is blocked"""
        name = "blocks_cat_pre_commit"
        env = os.environ.copy()
        env["CLAUDE_TOOL_INPUT"] = '{"command": "cat .pre-commit-config.yaml"}'

        result = subprocess.run(
            [sys.executable, str(self.hook_script)],
            env=env,
            capture_output=True,
            text=True,
            timeout=10
        )

        self._record_result(
            name,
            result.returncode == 2,
            f"Expected exit 2, got {result.returncode}"
        )

    def print_summary(self):
        """Print test summary"""
        print()
        print("=" * 70)
        print("TEST SUMMARY")
        print("=" * 70)
        print(f"Total:  {self.passed + self.failed}")
        print(f"Passed: {self.passed}")
        print(f"Failed: {self.failed}")
        print()


def main():
    tester = TestPreBashProtectedCommands()
    exit_code = tester.run_all_tests()
    sys.exit(exit_code)


if __name__ == "__main__":
    main()
