#!/usr/bin/env python3
"""
Tests for pre_read_protected_files.py

Verifies that the pre-read hook correctly blocks reading forbidden files.
"""

import os
import subprocess
import sys
from pathlib import Path


class TestPreReadProtectedFiles:
    """Test suite for the pre-read protected files hook"""

    def __init__(self):
        self.test_dir = Path(__file__).parent
        self.hooks_dir = self.test_dir.parent
        self.project_root = self.hooks_dir.parent.parent
        self.hook_script = self.hooks_dir / "pre_read_protected_files.py"
        self.test_results = []
        self.passed = 0
        self.failed = 0

    def _record_result(self, name: str, passed: bool, message: str = ""):
        """Record test result"""
        status = "PASS" if passed else "FAIL"
        self.test_results.append((name, status, message))
        if passed:
            self.passed += 1
            print(f"  [PASS] {name}")
        else:
            self.failed += 1
            print(f"  [FAIL] {name}")
            if message:
                print(f"         {message}")

    def run_all_tests(self):
        """Execute all test cases"""
        print("=" * 70)
        print("PRE-READ PROTECTED FILES HOOK TESTS")
        print("=" * 70)
        print()

        self.test_hook_exists()
        self.test_hook_is_executable()
        self.test_blocks_pre_commit_config()
        self.test_allows_normal_files()
        self.test_blocks_pre_commit_variations()

        self.print_summary()
        return 0 if self.failed == 0 else 1

    def test_hook_exists(self):
        """Test that the hook script exists"""
        name = "hook_exists"
        exists = self.hook_script.exists()
        self._record_result(name, exists, f"Script not found: {self.hook_script}")

    def test_hook_is_executable(self):
        """Test that the hook script is executable"""
        name = "hook_is_executable"
        if not self.hook_script.exists():
            self._record_result(name, False, "Script does not exist")
            return
        is_executable = os.access(self.hook_script, os.X_OK)
        self._record_result(name, is_executable)

    def test_blocks_pre_commit_config(self):
        """Test that .pre-commit-config.yaml is blocked"""
        name = "blocks_pre_commit_config"
        env = os.environ.copy()
        env["CLAUDE_TOOL_INPUT"] = '{"file_path": ".pre-commit-config.yaml"}'

        result = subprocess.run(
            [sys.executable, str(self.hook_script)],
            env=env,
            capture_output=True,
            text=True,
            timeout=10
        )

        # Should exit with 2 (blocked)
        self._record_result(
            name,
            result.returncode == 2,
            f"Expected exit 2, got {result.returncode}"
        )

    def test_allows_normal_files(self):
        """Test that normal files are allowed"""
        name = "allows_normal_files"
        env = os.environ.copy()
        env["CLAUDE_TOOL_INPUT"] = '{"file_path": "Sources/Networking/NetworkClient.swift"}'

        result = subprocess.run(
            [sys.executable, str(self.hook_script)],
            env=env,
            capture_output=True,
            text=True,
            timeout=10
        )

        # Should exit with 0 (allowed)
        self._record_result(
            name,
            result.returncode == 0,
            f"Expected exit 0, got {result.returncode}"
        )

    def test_blocks_pre_commit_variations(self):
        """Test that all pre-commit file variations are blocked"""
        name = "blocks_pre_commit_variations"
        variations = [
            ".pre-commit-config.yml",
            "pre-commit-config.yaml",
            ".pre-commit-hooks.yaml",
        ]

        all_blocked = True
        for variation in variations:
            env = os.environ.copy()
            env["CLAUDE_TOOL_INPUT"] = f'{{"file_path": "{variation}"}}'

            result = subprocess.run(
                [sys.executable, str(self.hook_script)],
                env=env,
                capture_output=True,
                text=True,
                timeout=10
            )

            if result.returncode != 2:
                all_blocked = False
                break

        self._record_result(name, all_blocked)

    def print_summary(self):
        """Print test summary"""
        print()
        print("=" * 70)
        print("TEST SUMMARY")
        print("=" * 70)
        print(f"Total:  {self.passed + self.failed}")
        print(f"Passed: {self.passed}")
        print(f"Failed: {self.failed}")
        print()


def main():
    tester = TestPreReadProtectedFiles()
    exit_code = tester.run_all_tests()
    sys.exit(exit_code)


if __name__ == "__main__":
    main()
