#!/usr/bin/env python3
"""Pre-edit hook that loads relevant context based on file being edited.

This hook examines the file path and loads contextual information:
- Related test files for implementation files
- Implementation files for test files
- Directory-specific CLAUDE.md instructions
- Recent changes to the file (git log)

Exit codes:
    0 - Success (context provided in stdout)
    1 - Error (could not load context)
"""

import os
import subprocess
import sys
from pathlib import Path

# Maximum lines of git history to show
MAX_GIT_LOG_LINES = 5

# Maximum characters for context output
MAX_CONTEXT_LENGTH = 2000


def find_related_test_file(filepath: str) -> str | None:
    """Find the test file related to an implementation file."""
    path = Path(filepath)

    if path.suffix != ".swift":
        return None

    # Skip if already a test file
    if "Tests" in path.name or "Spec" in path.name:
        return None

    # Look for corresponding test file
    base_name = path.stem
    test_patterns = [
        f"{base_name}Tests.swift",
        f"{base_name}Spec.swift",
    ]

    # Search in Tests directory
    project_root = path
    while project_root.parent != project_root:
        tests_dir = project_root / "Tests"
        if tests_dir.exists():
            for pattern in test_patterns:
                matches = list(tests_dir.rglob(pattern))
                if matches:
                    return str(matches[0])
        project_root = project_root.parent

    return None


def find_implementation_file(filepath: str) -> str | None:
    """Find the implementation file for a test file."""
    path = Path(filepath)

    if "Tests" not in path.name and "Spec" not in path.name:
        return None

    # Extract base name
    base_name = path.stem.replace("Tests", "").replace("Spec", "")

    # Search in Sources directory
    project_root = path
    while project_root.parent != project_root:
        sources_dir = project_root / "Sources"
        if sources_dir.exists():
            matches = list(sources_dir.rglob(f"{base_name}.swift"))
            if matches:
                return str(matches[0])
        project_root = project_root.parent

    return None


def find_local_claude_md(filepath: str) -> str | None:
    """Find the nearest CLAUDE.md file for directory-specific instructions."""
    path = Path(filepath).parent

    while path != path.parent:
        claude_md = path / ".claude" / "CLAUDE.md"
        if claude_md.exists():
            return str(claude_md)

        claude_md = path / "CLAUDE.md"
        if claude_md.exists():
            return str(claude_md)

        path = path.parent

    return None


def get_recent_git_changes(filepath: str) -> str:
    """Get recent git changes for the file."""
    try:
        result = subprocess.run(
            ["git", "log", "--oneline", f"-{MAX_GIT_LOG_LINES}", "--", filepath],
            capture_output=True,
            text=True,
            timeout=5,
            cwd=Path(filepath).parent,
        )
        if result.returncode == 0 and result.stdout.strip():
            return result.stdout.strip()
    except (subprocess.TimeoutExpired, subprocess.SubprocessError, FileNotFoundError):
        pass

    return ""


def format_context(filepath: str, related_test: str | None,
                   implementation: str | None, claude_md: str | None,
                   git_history: str) -> str:
    """Format the context for output."""
    lines = [f"[Context for: {Path(filepath).name}]"]

    if related_test:
        lines.append(f"Related test: {Path(related_test).name}")

    if implementation:
        lines.append(f"Implementation: {Path(implementation).name}")

    if claude_md:
        lines.append(f"Local instructions: {claude_md}")

    if git_history:
        lines.append("Recent changes:")
        for line in git_history.split("\n")[:MAX_GIT_LOG_LINES]:
            lines.append(f"  {line}")

    return "\n".join(lines)[:MAX_CONTEXT_LENGTH]


def main():
    """Main entry point for the pre-edit context loader hook."""
    if len(sys.argv) < 2:
        print("Usage: pre_edit_context_loader.py <filepath>", file=sys.stderr)
        sys.exit(1)

    filepath = sys.argv[1]

    # Gather context
    related_test = find_related_test_file(filepath)
    implementation = find_implementation_file(filepath)
    claude_md = find_local_claude_md(filepath)
    git_history = get_recent_git_changes(filepath)

    # Output context
    context = format_context(filepath, related_test, implementation,
                             claude_md, git_history)
    print(context)

    sys.exit(0)


if __name__ == "__main__":
    main()
