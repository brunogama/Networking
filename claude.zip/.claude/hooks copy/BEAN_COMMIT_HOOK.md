# Bean Completion → Smart Commit Hook

**Automatic intelligent commits when you complete bean issues**

## Quick Start

When you mark a bean as completed, this hook automatically triggers the smart-commit command to create an intelligent git commit with the optimal strategy.

```bash
# Work on your task
beans create "Add caching layer" -t feature -s in-progress

# ... write code, run tests ...

# Complete the bean - hook triggers automatically!
beans update beans-abc1 --status completed
```

**Result:** Smart-commit agent analyzes your changes and creates a proper conventional commit with bean reference.

## What Was Installed

1. **Hook Script:** `.claude/hooks/bean_completion_commit.py`
   - Detects `beans update --status completed` commands
   - Fetches bean content and context
   - Triggers smart-commit with full context

2. **Hook Registration:** `.claude/settings.json`
   - Added to PostToolUse hooks for Bash commands
   - Triggers after any `beans update` command
   - 10-second timeout, non-blocking errors

3. **Permissions:** Added `Bash(beans:*)` to allow list

## How It Works

### Trigger Detection

The hook monitors all Bash commands for this pattern:

```bash
beans update <bean-id> --status completed
# or
beans update <bean-id> -s completed
```

### Context Gathering

When triggered, the hook:

1. Extracts the bean ID from the command
2. Runs `beans show <id> --json` to fetch:
   - Bean title and type
   - Work description (body)
   - Tags
3. Builds context message for smart-commit agent

### Smart-Commit Invocation

The hook outputs a structured response that Claude Code interprets as:

```json
{
  "action": "invoke_skill",
  "skill": "smart-commit",
  "context": "Bean abc1 completed: Add caching layer\n\n[full context]...",
  "message": "Bean abc1 completed. Creating intelligent commit..."
}
```

This tells Claude Code to invoke the smart-commit skill with the bean context.

## Smart-Commit Agent Workflow

When invoked by the hook, the smart-commit agent:

1. **Analyzes Changes**
   ```bash
   git status    # What files changed
   git diff      # What changed in those files
   ```

2. **Chooses Commit Strategy**
   - Type: `feat|fix|refactor|docs|test|chore|perf`
   - Scope: Based on files/modules affected
   - Message: Comprehensive what/why/how

3. **Creates Commit**
   ```
   feat(cache): add LRU caching layer with TTL support

   Implements caching for vector search results...

   Closes #beans-abc1
   ```

## Example Workflow

```bash
# Step 1: Create bean for your work
$ beans create "Optimize vector search performance" -t feature -s in-progress
Created: beans-xzy9

# Step 2: Do the work
$ # ... implement caching, run tests ...

# Step 3: Stage changes
$ git add .

# Step 4: Complete the bean (triggers hook!)
$ beans update beans-xzy9 --status completed

🎯 Bean Completion Detected!
================================================
📋 Bean: beans-xzy9 - Optimize vector search performance
🏷️  Type: feature

💡 Triggering smart-commit to create optimal commit...
================================================

Smart-commit agent analyzing changes...
Created commit: feat(vector-search): add caching layer
```

## Configuration

### Hook Settings

Located in `.claude/settings.json`:

```json
{
  "hooks": {
    "PostToolUse": [
      {
        "matcher": "Bash",
        "hooks": [
          {
            "type": "command",
            "command": "cat | python3 .claude/hooks/bean_completion_commit.py",
            "timeout": 10,
            "description": "Trigger smart-commit when bean is marked as completed"
          }
        ]
      }
    ]
  }
}
```

### Customization Options

**Change timeout:**

```json
{
  "timeout": 30  // Increase if smart-commit needs more time
}
```

**Trigger on different statuses:**

Edit `.claude/hooks/bean_completion_commit.py`:

```python
def is_bean_completion_command(command: str) -> bool:
    # Current: triggers on "completed"
    return bool(re.search(r'(?:--status|-s)\s+completed', command))

    # Alternative: trigger on "in-review" or "completed"
    # return bool(re.search(r'(?:--status|-s)\s+(in-review|completed)', command))
```

## Requirements

- **Beans CLI:** `brew install beans` or build from source
- **Smart-commit skill:** Must exist (user or project level)
- **Python 3:** For hook execution
- **Git repository:** Changes must be staged before completion

## Verification

### Test the Hook

```bash
# 1. Create test bean
beans create "Test hook integration" -t task -s in-progress

# 2. Make a change
echo "test" > test.txt
git add test.txt

# 3. Complete bean (watch for hook output)
beans update <bean-id> --status completed

# Expected output:
# 🎯 Bean Completion Detected!
# 📋 Bean: <id> - Test hook integration
# 🏷️  Type: task
# 💡 Triggering smart-commit...
```

### Check Hook Is Registered

```bash
cat .claude/settings.json | python3 -m json.tool | grep -A 5 bean_completion
```

Should show the hook configuration.

### Verify Script Is Executable

```bash
ls -l .claude/hooks/bean_completion_commit.py
# Should show: -rwxr-xr-x
```

## Troubleshooting

### Hook Not Firing

**Symptom:** Bean completes but no commit is created.

**Checks:**

1. Hook registered?
   ```bash
   grep -r "bean_completion_commit" .claude/settings.json
   ```

2. Script executable?
   ```bash
   chmod +x .claude/hooks/bean_completion_commit.py
   ```

3. Hook executes?
   ```bash
   # Test manually
   echo '{"tool_input":{"command":"beans update test --status completed"}}' | \
     python3 .claude/hooks/bean_completion_commit.py
   ```

### Smart-Commit Not Found

**Symptom:** Hook fires but complains about missing smart-commit skill.

**Fix:** Check if smart-commit skill exists:

```bash
# User-level skills
ls ~/.claude/skills/smart-commit/SKILL.md

# Project-level skills
ls .claude/skills/smart-commit/SKILL.md
```

If missing, create the smart-commit skill or modify the hook to use a different commit command.

### Bean Not Found

**Symptom:** Hook fires but says "Could not fetch bean".

**Checks:**

1. Bean ID correct?
   ```bash
   beans list
   beans show <bean-id>
   ```

2. Beans CLI working?
   ```bash
   which beans
   beans --version
   ```

### Permission Denied

**Symptom:** Hook execution fails with permission error.

**Fix:**

```bash
chmod +x .claude/hooks/bean_completion_commit.py
```

Also check that `Bash(beans:*)` is in the allow list in `.claude/settings.json`.

## Best Practices

### Bean Descriptions

Write clear bean bodies - smart-commit uses them for context:

```bash
beans create "Add caching" -t feature -d "
## Goal
Reduce duplicate embedding computations

## Approach
LRU cache with TTL expiration

## Acceptance Criteria
- [ ] Cache hit rate >80%
- [ ] TTL configurable
- [ ] Thread-safe access
"
```

### Git Workflow

1. **Work in small batches** - One bean = one focused change
2. **Stage before completing** - Run `git add` before `beans update --status completed`
3. **Review commits** - Smart-commit is smart but always review
4. **Bean references** - The hook automatically adds `Closes #beans-abc1`

### Bean Statuses

Use the status progression:

1. `draft` → Planning, not ready to work
2. `todo` → Ready to be worked on
3. `in-progress` → Currently working (use this!)
4. `completed` → Done (triggers commit hook)
5. `scrapped` → Won't do

## Performance

- **Hook overhead:** <100ms (bean fetch + parsing)
- **Total time:** 2-5 seconds (smart-commit agent analysis)
- **Non-blocking:** Errors don't prevent bean updates
- **Timeout:** 10 seconds (configurable)

## Advanced Usage

### Multiple Beans Per Commit

If you complete multiple beans that should go in one commit:

```bash
# Don't mark as completed yet - work on all beans
beans update beans-abc1 -s in-progress
beans update beans-def2 -s in-progress

# ... work on both ...

# Stage everything
git add .

# Complete first bean (triggers commit with all changes)
beans update beans-abc1 --status completed

# Update commit message to reference both
git commit --amend -m "
feat(search): add caching and optimize queries

Closes #beans-abc1
Closes #beans-def2
"
```

### Disable Hook Temporarily

Comment out in `.claude/settings.json`:

```json
{
  "hooks": {
    "PostToolUse": [
      {
        "matcher": "Bash",
        "hooks": [
          // Commented out to disable
          // {
          //   "type": "command",
          //   "command": "cat | python3 .claude/hooks/bean_completion_commit.py",
          //   ...
          // }
        ]
      }
    ]
  }
}
```

### Custom Commit Messages

To override smart-commit's automatic message, create the commit manually before completing:

```bash
git add .
git commit -m "Your custom message"
beans update <id> --status completed
# Hook fires but commit already exists - no-op
```

## Related Documentation

- **Beans CLI:** Run `beans --help` or visit <https://github.com/joeychilson/beans>
- **Smart-commit skill:** `.claude/skills/smart-commit/SKILL.md`
- **Hook system:** `.claude/hooks/README.md`
- **Conventional Commits:** <https://www.conventionalcommits.org/>

---

**Created:** December 2024
**Hook Type:** PostToolUse → Bash
**Trigger:** `beans update <id> --status completed`
**Dependencies:** beans CLI, smart-commit skill, Python 3
