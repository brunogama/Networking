#!/usr/bin/env python3
"""
Post-Hook SRP Principles Validation

This hook wraps the check-srp-compliance.py script and forwards all its output.
When SRP violations are detected, it exits with code 2 to signal a validation error.

Exit codes:
  0: Success (no SRP violations)
  2: Validation error (SRP violations found)

Usage: Called by Claude Code post-hook system after tool execution.
"""

import subprocess
import sys
from pathlib import Path


def main():
    """Execute SRP compliance check and forward all output"""
    # Get project root (2 levels up from .claude/hooks/)
    script_dir = Path(__file__).parent
    project_root = script_dir.parent.parent
    srp_checker_path = project_root / "Tooling" / "scripts" / "check-srp-compliance.py"

    # Verify SRP checker exists
    if not srp_checker_path.exists():
        print(f"⚠️  Warning: SRP checker not found at {srp_checker_path}")
        print("   Skipping SRP validation")
        sys.exit(0)

    # Execute SRP checker and forward all output
    try:
        result = subprocess.run(
            [sys.executable, str(srp_checker_path)],
            cwd=str(project_root),
            capture_output=False,  # Forward output directly to stdout/stderr
            text=True,
            check=False,  # Don't raise exception on non-zero exit
        )

        # Map exit codes: 0 -> 0 (success), non-zero -> 2 (validation error)
        if result.returncode == 0:
            sys.exit(0)
        else:
            print(
                "SRP violations found - types that are internal or public must be extracted to their own file in order to be compliant with the Single Responsibility Principle"
            )
            sys.exit(2)

    except (subprocess.CalledProcessError, FileNotFoundError, PermissionError, OSError) as e:
        print(f"❌ Error executing SRP checker: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()
