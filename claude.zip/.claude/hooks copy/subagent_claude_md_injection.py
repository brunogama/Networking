#!/usr/bin/env python3
"""
Subagent CLAUDE.md Injection Hook

Automatically injects root CLAUDE.md content into subagent sessions to ensure
all spawned subagents have access to project-wide configuration, rules, and conventions.

Hook Type: SessionStart (subagent only)
Trigger: When Task tool spawns a subagent
Methods: System prompt injection, context file creation, environment variable
"""

import json
import os
import re
import sys
from pathlib import Path
from typing import Optional, Dict, List, Tuple
import hashlib

# Global cache for CLAUDE.md content
_claude_md_cache: Optional[Dict[str, any]] = None
_cache_file = Path(".claude/.claude_md_cache.json")


def is_subagent_session(hook_data: dict) -> bool:
    """
    Detect if this is a subagent session (not main session).

    Subagents are spawned via Task tool and have different session characteristics.
    """
    # Check for subagent indicators in hook data
    session_type = hook_data.get('session_type')
    if session_type == 'subagent':
        return True

    # Check environment variables
    if os.getenv('CLAUDE_SUBAGENT') == '1':
        return True

    # Check for parent session ID (subagents have parent sessions)
    if hook_data.get('parent_session_id'):
        return True

    # For now, assume this is NOT a subagent to avoid false positives
    # The hook will be invoked manually for testing
    return False


def find_repository_root() -> Optional[Path]:
    """Find the repository root by looking for .git directory."""
    current = Path.cwd()
    while current != current.parent:
        if (current / '.git').exists():
            return current
        current = current.parent
    return None


def find_claude_md_files(repo_root: Path) -> List[Path]:
    """
    Find all relevant CLAUDE.md files in priority order.

    Returns files in order of specificity:
    1. Root /CLAUDE.md
    2. Project CLAUDE.md
    3. .claude/CLAUDE.md (project-level)
    """
    claude_md_files = []

    # Root CLAUDE.md (highest priority for global rules)
    root_claude = repo_root / "CLAUDE.md"
    if root_claude.exists():
        claude_md_files.append(root_claude)

    # Project-level CLAUDE.md
    project_claude = repo_root / "Project" / "LocalRagKit" / "CLAUDE.md"
    if project_claude.exists():
        claude_md_files.append(project_claude)

    # .claude/CLAUDE.md (detailed project rules)
    dotclaude_md = repo_root / "Project" / "LocalRagKit" / ".claude" / "CLAUDE.md"
    if dotclaude_md.exists():
        claude_md_files.append(dotclaude_md)

    return claude_md_files


def strip_yaml_frontmatter(content: str) -> str:
    """Remove YAML frontmatter from markdown content."""
    # Pattern: --- at start, content, --- to close
    pattern = r'^---\s*\n.*?\n---\s*\n'
    return re.sub(pattern, '', content, flags=re.DOTALL)


def extract_priority_sections(content: str) -> str:
    """
    Extract high-priority sections from CLAUDE.md for subagent context.

    Priority sections (include):
    - Universal rules (MUST, SHOULD, MUST NOT)
    - Tech stack and dependencies
    - Code style and conventions
    - Security standards
    - Git workflow

    Skip sections (low priority for subagents):
    - Specific file paths (subagent has file access)
    - Detailed API references (use tools to look up)
    - Long examples (unless illustrating critical patterns)

    Tools
    - For code-base navigation execute repomix MCP
    - For up to date reference api docs Ref MCP
    - For searching content across the internet use Firecrawler MCP
    - If working on beans tasks execute !`beans prime`
    """
    lines = content.split('\n')
    priority_lines = []
    in_priority_section = False
    skip_keywords = ['example', 'quickstart', 'getting started', 'installation']
    priority_keywords = ['rule', 'must', 'should', 'convention', 'standard', 'workflow', 'architecture', 'stack', 'dependency']

    for i, line in enumerate(lines):
        line_lower = line.lower()

        # Check if entering a priority section
        if line.startswith('#'):
            # Header line - check if priority
            if any(kw in line_lower for kw in priority_keywords):
                in_priority_section = True
            elif any(kw in line_lower for kw in skip_keywords):
                in_priority_section = False
            # Keep all headers for structure
            priority_lines.append(line)
        elif in_priority_section:
            priority_lines.append(line)
        elif any(kw in line_lower for kw in ['must', 'never', 'always', 'critical', 'important']):
            # Include critical statements even outside priority sections
            priority_lines.append(line)

    return '\n'.join(priority_lines)


def smart_select_content(claude_md_files: List[Path]) -> str:
    """
    Intelligently select and merge content from multiple CLAUDE.md files.

    Strategy:
    - Root CLAUDE.md: Extract global rules and conventions
    - Project CLAUDE.md: Extract project-specific patterns
    - Merge without duplication (dedupe by section headers)
    """
    merged_content = []
    seen_sections = set()

    for claude_md_path in claude_md_files:
        try:
            with open(claude_md_path, 'r', encoding='utf-8') as f:
                content = f.read()

            # Strip YAML frontmatter
            content = strip_yaml_frontmatter(content)

            # Extract priority sections
            priority_content = extract_priority_sections(content)

            # Split into sections by headers
            sections = re.split(r'(^#{1,3} .+$)', priority_content, flags=re.MULTILINE)

            for i in range(0, len(sections), 2):
                if i + 1 < len(sections):
                    header = sections[i].strip()
                    body = sections[i + 1].strip()

                    # Dedupe by header
                    if header and header not in seen_sections:
                        seen_sections.add(header)
                        merged_content.append(f"{header}\n{body}")

        except Exception as e:
            print(f"Warning: Failed to read {claude_md_path}: {e}", file=sys.stderr)

    result = '\n\n'.join(merged_content)

    # Truncate if too large (>10k tokens ≈ 40k chars)
    max_chars = 40000
    if len(result) > max_chars:
        result = result[:max_chars] + "\n\n[... content truncated for brevity ...]"

    return result


def process_claude_md_content(repo_root: Path) -> Tuple[str, List[Path]]:
    """
    Process CLAUDE.md files and return formatted content for injection.

    Returns:
        (formatted_content, source_files)
    """
    claude_md_files = find_claude_md_files(repo_root)

    if not claude_md_files:
        return "", []

    # Smart selection and merging
    content = smart_select_content(claude_md_files)

    # Add header
    header = f"""# Root CLAUDE.md Context for Subagent

This content is automatically injected from the project's CLAUDE.md files
to ensure all subagents follow project conventions and best practices.

Source files:
{chr(10).join(f"- {str(f.relative_to(repo_root))}" for f in claude_md_files)}

---

"""

    formatted_content = header + content
    return formatted_content, claude_md_files


def load_cache() -> Optional[Dict]:
    """Load cached CLAUDE.md content from disk."""
    global _claude_md_cache

    if _claude_md_cache is not None:
        return _claude_md_cache

    try:
        if _cache_file.exists():
            with open(_cache_file, 'r') as f:
                _claude_md_cache = json.load(f)
                return _claude_md_cache
    except Exception:
        pass

    return None


def save_cache(content: str, source_files: List[Path], mtimes: Dict[str, float]):
    """Save processed CLAUDE.md content to cache."""
    global _claude_md_cache

    cache_data = {
        'content': content,
        'source_files': [str(f) for f in source_files],
        'mtimes': mtimes
    }

    try:
        _cache_file.parent.mkdir(parents=True, exist_ok=True)
        with open(_cache_file, 'w') as f:
            json.dump(cache_data, f, indent=2)
        _claude_md_cache = cache_data
    except Exception as e:
        print(f"Warning: Failed to save cache: {e}", file=sys.stderr)


def get_cached_or_fresh_content(repo_root: Path) -> Tuple[str, List[Path]]:
    """
    Get CLAUDE.md content from cache or fresh read.

    Cache is invalidated if any source file's mtime has changed.
    """
    # Try to load cache
    cache = load_cache()

    if cache:
        # Check if cache is still valid
        cached_mtimes = cache.get('mtimes', {})
        all_valid = True

        for file_path_str in cache.get('source_files', []):
            file_path = Path(file_path_str)
            if file_path.exists():
                current_mtime = file_path.stat().st_mtime
                cached_mtime = cached_mtimes.get(file_path_str, 0)
                if abs(current_mtime - cached_mtime) > 1:  # 1 second tolerance
                    all_valid = False
                    break
            else:
                all_valid = False
                break

        if all_valid:
            # Cache hit!
            return cache['content'], [Path(f) for f in cache['source_files']]

    # Cache miss or invalid - fresh read
    content, source_files = process_claude_md_content(repo_root)

    # Build mtime dict
    mtimes = {}
    for f in source_files:
        mtimes[str(f)] = f.stat().st_mtime

    # Save to cache
    save_cache(content, source_files, mtimes)

    return content, source_files


def inject_via_context_file(content: str, repo_root: Path) -> bool:
    """
    Method 2: Write content to .claude/subagent-context.md file.

    Returns True if successful.
    """
    try:
        context_file = repo_root / ".claude" / "subagent-context.md"
        context_file.parent.mkdir(parents=True, exist_ok=True)

        with open(context_file, 'w', encoding='utf-8') as f:
            f.write(content)

        return True
    except Exception as e:
        print(f"Warning: Failed to write context file: {e}", file=sys.stderr)
        return False


def inject_via_env_var(content: str) -> bool:
    """
    Method 3: Set CLAUDE_MD_CONTEXT environment variable.

    Returns True if successful.
    """
    try:
        # Store content in env var
        os.environ['CLAUDE_MD_CONTEXT'] = content

        # Also output as JSON for hook framework to capture
        print(json.dumps({
            'env': {
                'CLAUDE_MD_CONTEXT': content[:500] + '...' if len(content) > 500 else content
            }
        }), file=sys.stderr)

        return True
    except Exception as e:
        print(f"Warning: Failed to set env var: {e}", file=sys.stderr)
        return False


def inject_via_system_prompt(content: str) -> bool:
    """
    Method 1: Output content for system prompt injection.

    The hook framework may capture this and inject into system prompt.
    Returns True if output successful.
    """
    try:
        # Output special marker that hook framework can detect
        print(f"\n{'='*60}", file=sys.stderr)
        print("📋 SUBAGENT CONTEXT INJECTION", file=sys.stderr)
        print(f"{'='*60}\n", file=sys.stderr)

        # Output formatted content for potential system prompt injection
        # The hook framework or Claude Code may use this
        injection_payload = {
            'type': 'system_prompt_injection',
            'content': content,
            'priority': 'high',
            'source': 'CLAUDE.md'
        }

        print(json.dumps(injection_payload))
        return True
    except Exception as e:
        print(f"Warning: Failed system prompt injection: {e}", file=sys.stderr)
        return False


def main():
    """Main hook execution."""
    import time
    start_time = time.time()

    try:
        # Read hook data from stdin
        hook_data = json.load(sys.stdin)

        # For manual testing, allow override via env var FIRST
        force_injection = os.getenv('FORCE_SUBAGENT_INJECTION') == '1'

        # Check if this is a subagent session
        is_subagent = force_injection or is_subagent_session(hook_data)

        if not is_subagent:
            # Not a subagent - exit silently
            print("ℹ️  Main session detected - skipping CLAUDE.md injection", file=sys.stderr)
            sys.exit(0)

        # Find repository root
        repo_root = find_repository_root()
        if not repo_root:
            print("Warning: Could not find repository root (.git directory)", file=sys.stderr)
            sys.exit(0)

        # Get CLAUDE.md content (cached or fresh)
        content, source_files = get_cached_or_fresh_content(repo_root)

        if not content:
            print("Warning: No CLAUDE.md files found", file=sys.stderr)
            sys.exit(0)

        # Inject via all three methods
        methods_used = []

        if inject_via_system_prompt(content):
            methods_used.append("system_prompt")

        if inject_via_context_file(content, repo_root):
            methods_used.append("context_file")

        if inject_via_env_var(content):
            methods_used.append("env_var")

        # Report results
        elapsed = (time.time() - start_time) * 1000  # ms

        print(f"\n{'='*60}", file=sys.stderr)
        print("✅ CLAUDE.md Injection Complete", file=sys.stderr)
        print(f"{'='*60}", file=sys.stderr)
        print(f"📁 Source files: {len(source_files)}", file=sys.stderr)
        print(f"📊 Content size: {len(content)} chars", file=sys.stderr)
        print(f"✨ Methods used: {', '.join(methods_used)}", file=sys.stderr)
        print(f"⏱️  Execution time: {elapsed:.1f}ms", file=sys.stderr)
        print(f"{'='*60}\n", file=sys.stderr)

        # Exit successfully
        sys.exit(0)

    except json.JSONDecodeError:
        print("Error: Invalid JSON input from hook framework", file=sys.stderr)
        sys.exit(0)  # Non-blocking error
    except Exception as e:
        print(f"Error in CLAUDE.md injection hook: {e}", file=sys.stderr)
        import traceback
        traceback.print_exc(file=sys.stderr)
        sys.exit(0)  # Non-blocking error


if __name__ == '__main__':
    main()
