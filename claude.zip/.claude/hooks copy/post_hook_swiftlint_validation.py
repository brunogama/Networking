#!/usr/bin/env python3
"""
Post-Hook SwiftLint Validation

This hook runs SwiftLint to validate code quality.
When linting violations are detected, it exits with code 2 to signal a validation error.

Exit codes:
  0: Success (no linting violations)
  2: Validation error (linting violations found)

Usage: Called by Claude Code post-hook system after tool execution.
"""

import subprocess
import sys
from pathlib import Path


def main():
    """Execute SwiftLint validation"""
    # Get project root (2 levels up from .claude/hooks/)
    script_dir = Path(__file__).parent
    project_root = script_dir.parent.parent

    # SwiftLint config path
    swiftlint_config = project_root / "Config" / "PreCommitHooks" / "swiftlint.yml"

    # Verify SwiftLint is installed
    try:
        version_check = subprocess.run(
            ["swiftlint", "version"],
            capture_output=True,
            text=True,
            check=False,
            timeout=5
        )

        if version_check.returncode != 0:
            print("⚠️  Warning: SwiftLint not installed")
            print("   Install with: brew install swiftlint")
            print("   Skipping SwiftLint validation")
            sys.exit(0)

    except (FileNotFoundError, subprocess.TimeoutExpired):
        print("⚠️  Warning: SwiftLint not found")
        print("   Install with: brew install swiftlint")
        print("   Skipping SwiftLint validation")
        sys.exit(0)
    except (subprocess.SubprocessError, OSError) as e:
        print(f"⚠️  Warning: Error checking SwiftLint: {e}")
        print("   Skipping SwiftLint validation")
        sys.exit(0)

    # Run SwiftLint
    print("🔍 Checking Swift code quality...")

    try:
        # Build command
        cmd = ["swiftlint", "lint", "--strict"]

        if swiftlint_config.exists():
            cmd.extend(["--config", str(swiftlint_config)])

        result = subprocess.run(
            cmd,
            cwd=str(project_root),
            capture_output=False,  # Forward output directly to stdout/stderr
            text=True,
            check=False,  # Don't raise exception on non-zero exit
            timeout=300  # 5 minutes timeout
        )

        # SwiftLint exits with non-zero if violations are found
        if result.returncode == 0:
            print("✅ Swift code quality checks passed")
            sys.exit(0)
        else:
            # Linting violations found - GIANT FIX MESSAGE
            print("\n")
            print("=" * 80)
            print("=" * 80)
            print("                                                                                ")
            print("    ███████╗██╗██╗  ██╗    ████████╗██╗  ██╗███████╗    ██╗     ██╗███╗   ██╗████████╗")
            print("    ██╔════╝██║╚██╗██╔╝    ╚══██╔══╝██║  ██║██╔════╝    ██║     ██║████╗  ██║╚══██╔══╝")
            print("    █████╗  ██║ ╚███╔╝        ██║   ███████║█████╗      ██║     ██║██╔██╗ ██║   ██║   ")
            print("    ██╔══╝  ██║ ██╔██╗        ██║   ██╔══██║██╔══╝      ██║     ██║██║╚██╗██║   ██║   ")
            print("    ██║     ██║██╔╝ ██╗       ██║   ██║  ██║███████╗    ███████╗██║██║ ╚████║   ██║   ")
            print("    ╚═╝     ╚═╝╚═╝  ╚═╝       ╚═╝   ╚═╝  ╚═╝╚══════╝    ╚══════╝╚═╝╚═╝  ╚═══╝   ╚═╝   ")
            print("                                                                                ")
            print("    ██╗    ██╗ █████╗ ██████╗ ███╗   ██╗██╗███╗   ██╗ ██████╗ ███████╗██╗")
            print("    ██║    ██║██╔══██╗██╔══██╗████╗  ██║██║████╗  ██║██╔════╝ ██╔════╝██║")
            print("    ██║ █╗ ██║███████║██████╔╝██╔██╗ ██║██║██╔██╗ ██║██║  ███╗███████╗██║")
            print("    ██║███╗██║██╔══██║██╔══██╗██║╚██╗██║██║██║╚██╗██║██║   ██║╚════██║╚═╝")
            print("    ╚███╔███╔╝██║  ██║██║  ██║██║ ╚████║██║██║ ╚████║╚██████╔╝███████║██╗")
            print("     ╚══╝╚══╝ ╚═╝  ╚═╝╚═╝  ╚═╝╚═╝  ╚═══╝╚═╝╚═╝  ╚═══╝ ╚═════╝ ╚══════╝╚═╝")
            print("                                                                                ")
            print("=" * 80)
            print("=" * 80)
            print()
            print("    WARNINGS ARE ERRORS IN THIS PROJECT!")
            print("    ------------------------------------")
            print()
            print("    This is a PRODUCTION-GRADE AAA Swift library.")
            print("    ALL Swift lint warnings MUST be fixed before commit.")
            print()
            print("    ZERO WARNINGS POLICY - NON-NEGOTIABLE")
            print()
            print("    Quick Fix Commands:")
            print("    -------------------")
            print("    1. Auto-fix: swiftlint lint --fix --config .swiftlint.yml Sources/ Tests/")
            print("    2. Verify:   swiftlint lint --strict --config .swiftlint.yml Sources/ Tests/")
            print()
            print("    Build Command (with warnings-as-errors):")
            print("    -----------------------------------------")
            print("    swift build -Xswiftc -warnings-as-errors")
            print()
            print("    DO NOT:")
            print("    - Use --no-verify to skip hooks")
            print("    - Disable SwiftLint rules without inline justification")
            print("    - Change linter flags to pass commit hooks")
            print()
            print("    FIX THE CODE, NOT THE RULES!")
            print()
            print("=" * 80)
            print("=" * 80)
            print()
            sys.exit(2)

    except subprocess.TimeoutExpired:
        print("❌ Error: SwiftLint timed out after 5 minutes")
        sys.exit(1)
    except (subprocess.CalledProcessError, FileNotFoundError, PermissionError, OSError) as e:
        print(f"❌ Error executing SwiftLint: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()
