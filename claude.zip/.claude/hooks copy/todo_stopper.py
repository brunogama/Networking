#!/usr/bin/env python3
"""Todo stopper hook - prevents TodoWrite tool usage in favor of beans."""

import json
import sys

def main():
    """Block TodoWrite and suggest beans instead."""

    # Read stdin for tool information
    try:
        tool_data = json.loads(sys.stdin.read())
        tool_name = tool_data.get('tool', '')

        if tool_name == 'TodoWrite':
            print(json.dumps({
                "decision": "block",
                "message": "🚫 STOP: Use beans instead of TodoWrite\n\n"
                          "Run: beans create \"Task title\" -t task -d \"Description\" -s in-progress\n\n"
                          "Beans provide better:\n"
                          "• Version control (committed with code)\n"
                          "• GraphQL querying\n"
                          "• Relationship tracking\n"
                          "• Persistent history"
            }))
            return 0

    except Exception:
        pass

    # Allow all other tools
    print(json.dumps({"decision": "allow"}))
    return 0

if __name__ == '__main__':
    sys.exit(main())
