#!/usr/bin/env python3
"""
Pre-Edit Protected Files Hook

Blocks AI agent from editing protected configuration files.
These files are governance-critical and must only be modified by humans.

Protected files:
- .swiftlint.yml - SwiftLint configuration (warnings-as-errors policy)
- .swiftlint.yaml - Alternative SwiftLint config name
- .swift-format - Swift-format configuration
- .claude/settings.json - Claude Code settings (governance)
- .claude/settings.local.json - Local Claude settings (governance)
- .pre-commit-config.yaml - Pre-commit hook configuration
- Any JSON/YAML file in .claude/ directory containing 'settings' or 'config'

Exit codes:
  0: File is allowed to be edited
  2: File is PROTECTED - edit blocked

Usage: Called by Claude Code pre-tool-use hook system before Write/Edit/MultiEdit.
"""

import json
import os
import sys
from pathlib import Path

# Files that are PROTECTED from AI editing
PROTECTED_FILES = [
    # SwiftLint configuration
    ".swiftlint.yml",
    ".swiftlint.yaml",
    "swiftlint.yml",
    "swiftlint.yaml",
    # Swift-format configuration
    ".swift-format",
    "swift-format",
    # Claude Code settings (ALL settings files)
    "settings.json",
    "settings.local.json",
    # Pre-commit configuration - ALL VARIATIONS
    ".pre-commit-config.yaml",
    ".pre-commit-config.yml",
    "pre-commit-config.yaml",
    "pre-commit-config.yml",
    ".pre-commit-hooks.yaml",
    ".pre-commit-hooks.yml",
    "pre-commit-hooks.yaml",
    "pre-commit-hooks.yml",
]

# Files that are FORBIDDEN from even being READ by the agent
# This prevents the agent from learning how to bypass hooks
FORBIDDEN_READ_FILES = [
    ".pre-commit-config.yaml",
    ".pre-commit-config.yml",
    "pre-commit-config.yaml",
    "pre-commit-config.yml",
    ".pre-commit-hooks.yaml",
    ".pre-commit-hooks.yml",
    "pre-commit-hooks.yaml",
    "pre-commit-hooks.yml",
]

# Patterns that indicate protected config directories
PROTECTED_PATTERNS = [
    "swiftlint",
    "swift-format",
]

# Directory patterns - files in these paths are protected
PROTECTED_DIRECTORIES = [
    ".claude/settings",
    ".claude/config",
]


def print_blocked_message(file_path: str):
    """Print a clear message explaining why the edit is blocked"""
    print()
    print("=" * 80)
    print("=" * 80)
    print()
    print("    ██████╗ ██╗      ██████╗  ██████╗██╗  ██╗███████╗██████╗ ██╗")
    print("    ██╔══██╗██║     ██╔═══██╗██╔════╝██║ ██╔╝██╔════╝██╔══██╗██║")
    print("    ██████╔╝██║     ██║   ██║██║     █████╔╝ █████╗  ██║  ██║██║")
    print("    ██╔══██╗██║     ██║   ██║██║     ██╔═██╗ ██╔══╝  ██║  ██║╚═╝")
    print("    ██████╔╝███████╗╚██████╔╝╚██████╗██║  ██╗███████╗██████╔╝██╗")
    print("    ╚═════╝ ╚══════╝ ╚═════╝  ╚═════╝╚═╝  ╚═╝╚══════╝╚═════╝ ╚═╝")
    print()
    print("=" * 80)
    print("=" * 80)
    print()
    print("    PROTECTED FILE - EDIT BLOCKED!")
    print("    ================================")
    print()
    print(f"    File: {file_path}")
    print()
    print("    This file is PROTECTED from AI agent modifications.")
    print("    Linter configuration files enforce code quality standards")
    print("    and must only be modified by human developers.")
    print()
    print("    WHY IS THIS BLOCKED?")
    print("    ---------------------")
    print("    - SwiftLint rules enforce WARNINGS-AS-ERRORS policy")
    print("    - Changing rules to bypass linting violates project governance")
    print("    - Code quality standards are NON-NEGOTIABLE")
    print()
    print("    WHAT TO DO INSTEAD:")
    print("    --------------------")
    print("    1. FIX THE CODE that violates the lint rules")
    print("    2. Use inline disable with justification comment:")
    print("       // swiftlint:disable:next rule_name")
    print("       // Justification: [explain why this is acceptable]")
    print("    3. Ask a human to review if rule change is truly needed")
    print()
    print("    FIX THE CODE, NOT THE RULES!")
    print()
    print("=" * 80)
    print("=" * 80)
    print()


def is_protected_file(file_path: str) -> bool:
    """Check if the file is in the protected list"""
    path = Path(file_path)
    filename = path.name.lower()
    path_str = str(path).lower()

    # Check exact filename matches
    for protected in PROTECTED_FILES:
        if filename == protected.lower():
            return True

    # Check if file is in .claude directory and is a settings file
    if ".claude" in path_str and filename.endswith(('.json', '.yaml', '.yml')):
        # Protect all JSON/YAML config files in .claude directory
        if "settings" in filename or "config" in filename:
            return True

    # Check if filename contains protected patterns
    for pattern in PROTECTED_PATTERNS:
        if pattern in filename.lower():
            # Additional check: must be a config file
            if filename.endswith(('.yml', '.yaml', '.json', '.config', '')):
                return True

    # Check protected directory patterns
    for dir_pattern in PROTECTED_DIRECTORIES:
        if dir_pattern in path_str:
            return True

    return False


def get_file_paths_from_input() -> list:
    """Extract file paths from Claude tool input"""
    file_paths = []

    # Try to get file path from environment variable
    tool_input = os.environ.get("CLAUDE_TOOL_INPUT", "")
    file_paths_env = os.environ.get("CLAUDE_FILE_PATHS", "")

    # Parse from CLAUDE_FILE_PATHS (space-separated)
    if file_paths_env:
        file_paths.extend(file_paths_env.split())

    # Try to parse tool input as JSON
    if tool_input:
        try:
            data = json.loads(tool_input)
            # Handle different tool input formats
            if isinstance(data, dict):
                if "file_path" in data:
                    file_paths.append(data["file_path"])
                if "path" in data:
                    file_paths.append(data["path"])
                if "filePath" in data:
                    file_paths.append(data["filePath"])
        except json.JSONDecodeError:
            # Not JSON, might be a direct path
            if tool_input.strip():
                file_paths.append(tool_input.strip())

    return file_paths


def main():
    """Check if any target files are protected"""
    file_paths = get_file_paths_from_input()

    for file_path in file_paths:
        if is_protected_file(file_path):
            print_blocked_message(file_path)
            sys.exit(2)

    # All files are allowed
    sys.exit(0)


if __name__ == "__main__":
    main()
