#!/usr/bin/env python3
"""
Post-Hook SwiftFormat Validation

This hook runs SwiftFormat to validate code formatting.
When formatting violations are detected, it exits with code 2 to signal a validation error.

Exit codes:
  0: Success (no formatting violations)
  2: Validation error (formatting violations found)

Usage: Called by Claude Code post-hook system after tool execution.
"""

import subprocess
import sys
from pathlib import Path


def main():
    """Execute SwiftFormat validation"""
    # Get project root (2 levels up from .claude/hooks/)
    script_dir = Path(__file__).parent
    project_root = script_dir.parent.parent

    # SwiftFormat config path
    swiftformat_config = project_root / "Config" / "PreCommitHooks" / "swiftformat.config"

    # Verify SwiftFormat is installed
    try:
        version_check = subprocess.run(
            ["swiftformat", "--version"],
            capture_output=True,
            text=True,
            check=False,
            timeout=5
        )

        if version_check.returncode != 0:
            print("⚠️  Warning: SwiftFormat not installed")
            print("   Install with: brew install swiftformat")
            print("   Skipping SwiftFormat validation")
            sys.exit(0)

    except (FileNotFoundError, subprocess.TimeoutExpired):
        print("⚠️  Warning: SwiftFormat not found")
        print("   Install with: brew install swiftformat")
        print("   Skipping SwiftFormat validation")
        sys.exit(0)
    except (subprocess.SubprocessError, OSError) as e:
        print(f"⚠️  Warning: Error checking SwiftFormat: {e}")
        print("   Skipping SwiftFormat validation")
        sys.exit(0)

    # Run SwiftFormat lint (dry-run to check for violations)
    print("🔍 Checking Swift code formatting...")

    try:
        # Use --lint mode to check without modifying files
        cmd = ["swiftformat", "--lint", "."]

        if swiftformat_config.exists():
            cmd.extend(["--config", str(swiftformat_config)])

        result = subprocess.run(
            cmd,
            cwd=str(project_root),
            capture_output=False,  # Forward output directly to stdout/stderr
            text=True,
            check=False,  # Don't raise exception on non-zero exit
            timeout=300  # 5 minutes timeout
        )

        # SwiftFormat exits with 1 if formatting changes are needed
        if result.returncode == 0:
            print("✅ Swift code formatting is correct")
            sys.exit(0)
        else:
            # Formatting violations found
            print("\n❌ SwiftFormat validation failed")
            print("   Run 'swiftformat .' to fix formatting issues")
            sys.exit(2)

    except subprocess.TimeoutExpired:
        print("❌ Error: SwiftFormat timed out after 5 minutes")
        sys.exit(2)
    except (subprocess.CalledProcessError, FileNotFoundError, PermissionError, OSError) as e:
        print(f"❌ Error executing SwiftFormat: {e}")
        sys.exit(2)


if __name__ == "__main__":
    main()
