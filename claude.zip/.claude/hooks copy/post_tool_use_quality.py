#!/usr/bin/env -S uv run --script
# /// script
# requires-python = ">=3.11"
# ///

"""
Swift-Format Hook for Claude Code
Automatically formats Swift files after edit operations using swift-format.
"""

import json
import subprocess
import sys
from pathlib import Path


def is_swift_file(file_path: str) -> bool:
    """Check if the file is a Swift file."""
    return file_path.endswith(".swift")


def run_swift_format(file_path: str) -> tuple[bool, str]:
    """
    Run swift-format on the specified file.

    Returns:
        tuple: (success: bool, message: str)
    """
    try:
        # Get project root (find .swift-format config)
        current_path = Path(file_path).resolve().parent
        project_root = None

        while current_path != current_path.parent:
            if (current_path / ".swift-format").exists():
                project_root = current_path
                break
            current_path = current_path.parent

        if not project_root:
            return False, "⚠️ Could not find project root with .swift-format"

        config_path = project_root / ".swift-format"

        # Check if swift-format is available
        result = subprocess.run(["which", "swift-format"], capture_output=True, text=True, timeout=5)

        if result.returncode != 0:
            return False, "swift-format not found. Install with: brew install swift-format"

        # Run swift-format with project config (in-place edit)
        result = subprocess.run(
            ["swift-format", "-i", "--configuration", str(config_path), file_path],
            capture_output=True,
            text=True,
            timeout=30,
            cwd=str(project_root),
        )

        if result.returncode == 0:
            return True, f"✅ swift-format applied to {Path(file_path).name}"
        else:
            return False, f"❌ swift-format failed: {result.stderr.strip()}"

    except subprocess.TimeoutExpired:
        return False, "❌ swift-format timed out"
    except Exception as e:
        return False, f"❌ swift-format error: {str(e)}"


def main():
    try:
        # Read input from stdin
        input_data = json.loads(sys.stdin.read())

        # Extract relevant information
        tool_name = input_data.get("tool_name", "")
        tool_input = input_data.get("tool_input", {})
        hook_event_name = input_data.get("hook_event_name", "")

        # Only process PostToolUse events for edit operations
        if hook_event_name != "PostToolUse":
            sys.exit(0)

        # Only process Edit, MultiEdit, and Write operations
        if tool_name not in ["Edit", "MultiEdit", "Write"]:
            sys.exit(0)

        # Extract file path based on tool type
        file_path = None
        if tool_name in ["Edit", "Write"]:
            file_path = tool_input.get("file_path")
        elif tool_name == "MultiEdit":
            file_path = tool_input.get("file_path")

        if not file_path:
            sys.exit(0)

        # Only process Swift files
        if not is_swift_file(file_path):
            sys.exit(0)

        # Check if file exists
        if not Path(file_path).exists():
            print(f"⚠️  File not found: {file_path}", file=sys.stderr)
            sys.exit(0)

        # Run swift-format
        success, message = run_swift_format(file_path)

        if success:
            print(message)  # Success message to stdout
            sys.exit(0)
        else:
            print(message, file=sys.stderr)
            sys.exit(2)  # Non-blocking error

    except json.JSONDecodeError as e:
        print(f"❌ Invalid JSON input: {e}", file=sys.stderr)
        sys.exit(1)
    except Exception as e:
        print(f"❌ swift-format hook error: {e}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
