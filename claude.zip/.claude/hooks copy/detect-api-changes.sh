#!/usr/bin/env bash
# detect-api-changes.sh - Detects new public APIs using symbol graphs
# Triggers docc-api-sync-agent when new symbols are found
#
# Usage:
#   Manual: ./.claude/hooks/detect-api-changes.sh
#   Hook: Triggered by PostToolUse on git commit

set -euo pipefail

# Configuration
PROJECT_DIR="${CLAUDE_PROJECT_DIR:-$(cd "$(dirname "$0")/../.." && pwd)}"
SYMBOL_DIR="$PROJECT_DIR/.build/symbol-graphs"
CACHE_DIR="$PROJECT_DIR/.cache"
BASELINE_FILE="$CACHE_DIR/api-baseline.json"
TARGETS=("Networking" "NetworkingMacros")

# Ensure cache directory exists
mkdir -p "$CACHE_DIR"

# Determine mode: manual (CLI) or hook (stdin JSON)
MANUAL_MODE="${MANUAL_MODE:-false}"

# Check for explicit manual flag or if no stdin available
if [ "${1:-}" = "--manual" ] || [ "${1:-}" = "-m" ]; then
    MANUAL_MODE=true
    shift
fi

# Read hook input from stdin (if available and not manual)
INPUT=""
if [ "$MANUAL_MODE" = false ]; then
    # Try to read stdin with timeout
    if read -t 1 -r first_line 2>/dev/null; then
        INPUT="$first_line$(cat)"
    fi

    # If we got JSON input, check if it's a git commit
    if [ -n "$INPUT" ]; then
        COMMAND=$(echo "$INPUT" | jq -r '.tool_input.command // empty' 2>/dev/null || echo "")
        if ! echo "$COMMAND" | grep -qE 'git commit'; then
            exit 0
        fi
    else
        # No stdin input - treat as manual mode
        MANUAL_MODE=true
    fi
fi

log() {
    if [ "$MANUAL_MODE" = true ]; then
        echo "[detect-api-changes] $1" >&2
    fi
}

log "Starting API change detection..."

# Generate symbol graphs for each target
generate_symbol_graphs() {
    log "Generating symbol graphs..."
    mkdir -p "$SYMBOL_DIR"

    for target in "${TARGETS[@]}"; do
        log "Building target: $target"
        if swift build --target "$target" \
            -Xswiftc -emit-symbol-graph \
            -Xswiftc -emit-symbol-graph-dir -Xswiftc "$SYMBOL_DIR" 2>/dev/null; then
            log "Symbol graph generated for $target"
        else
            log "Warning: Failed to generate symbol graph for $target"
        fi
    done
}

# Extract public symbols from symbol graph JSON files
# Filters out:
# - Synthesized protocol conformances (::SYNTHESIZED::)
# - Internal Swift runtime symbols
# - Extension symbols from other modules (@)
extract_public_symbols() {
    local symbols_file="$1"
    if [ -f "$symbols_file" ]; then
        jq -c '[
            .symbols[]? |
            select(.accessLevel == "public" or .accessLevel == "open") |
            select(.identifier.precise | contains("SYNTHESIZED") | not) |
            select(.identifier.precise | test("^s:[0-9]+Networking") or test("^s:[0-9]+MacroTemplateKit")) |
            {
                name: .names.title,
                kind: .kind.identifier,
                precise: .identifier.precise,
                docComment: (.docComment.lines[0]?.text // ""),
                file: (.location.uri // "" | sub("file://"; ""))
            }
        ]' "$symbols_file" 2>/dev/null || echo "[]"
    else
        echo "[]"
    fi
}

# Collect all public symbols from all targets
collect_all_symbols() {
    local all_symbols="[]"

    for target in "${TARGETS[@]}"; do
        local symbols_file="$SYMBOL_DIR/${target}.symbols.json"
        if [ -f "$symbols_file" ]; then
            log "Processing symbol graph: $symbols_file"
            local target_symbols
            target_symbols=$(extract_public_symbols "$symbols_file")
            local count
            count=$(echo "$target_symbols" | jq 'length' 2>/dev/null || echo "0")
            log "Found $count public symbols in $target"

            if [ "$count" -gt 0 ]; then
                all_symbols=$(echo "$all_symbols" "$target_symbols" | jq -s 'add' 2>/dev/null || echo "$all_symbols")
            fi
        fi
    done

    echo "$all_symbols"
}

# Compare current symbols with baseline
find_new_symbols() {
    local current_symbols="$1"

    if [ ! -f "$BASELINE_FILE" ]; then
        log "No baseline found, all symbols are new"
        echo "$current_symbols"
        return
    fi

    local baseline_precises
    baseline_precises=$(jq -r '.[].precise' "$BASELINE_FILE" 2>/dev/null | sort -u)

    local current_precises
    current_precises=$(echo "$current_symbols" | jq -r '.[].precise' 2>/dev/null | sort -u)

    # Find symbols in current but not in baseline
    local new_precises
    new_precises=$(comm -23 <(echo "$current_precises") <(echo "$baseline_precises"))

    if [ -z "$new_precises" ]; then
        echo "[]"
        return
    fi

    # Filter current symbols to only include new ones
    echo "$current_symbols" | jq --argjson precises "$(echo "$new_precises" | jq -R . | jq -s .)" '
        [.[] | select(.precise as $p | $precises | index($p))]
    '
}

# Format symbols for agent context
format_symbols_for_agent() {
    local symbols="$1"
    echo "$symbols" | jq -r '
        .[] |
        "- \(.kind): \(.name) (\(.precise | split("/") | last))"
    ' 2>/dev/null
}

# Main execution
main() {
    generate_symbol_graphs

    log "Extracting public symbols..."
    local current_symbols
    current_symbols=$(collect_all_symbols)

    local symbol_count
    symbol_count=$(echo "$current_symbols" | jq 'length' 2>/dev/null || echo "0")
    log "Found $symbol_count public symbols total"

    log "Comparing with baseline..."
    local new_symbols
    new_symbols=$(find_new_symbols "$current_symbols")

    local new_count
    new_count=$(echo "$new_symbols" | jq 'length' 2>/dev/null || echo "0")

    if [ "$new_count" -gt 0 ]; then
        log "Detected $new_count new public API(s)!"

        local formatted
        formatted=$(format_symbols_for_agent "$new_symbols")

        if [ "$MANUAL_MODE" = true ]; then
            echo ""
            echo "New Public APIs Detected:"
            echo "$formatted"
            echo ""
            echo "Run the docc-api-sync-agent to generate documentation."
        else
            # Output JSON for Claude Code hook system
            cat <<EOF
{
    "additionalContext": "NEW_PUBLIC_APIS_DETECTED:\\n\\nThe following new public APIs were added and need DocC documentation:\\n${formatted//
/\\n}\\n\\nPlease spawn the docc-api-sync-agent to generate Documentation.docc content for these symbols.",
    "systemMessage": "Detected $new_count new public API(s). Documentation generation recommended."
}
EOF
        fi
    else
        log "No new public APIs detected"
        if [ "$MANUAL_MODE" = false ]; then
            echo '{"systemMessage": "No new public APIs detected"}'
        fi
    fi

    # Update baseline
    log "Updating baseline..."
    echo "$current_symbols" > "$BASELINE_FILE"
    log "Baseline updated at $BASELINE_FILE"
}

main
