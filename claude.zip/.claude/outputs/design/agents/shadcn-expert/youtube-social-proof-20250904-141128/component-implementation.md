# YouTube Social Proof Widget - Comprehensive shadcn/ui Component Implementation Plan

## Executive Summary

This implementation guide provides a complete shadcn/ui component selection and styling strategy for the YouTube Social Proof Widget application, focusing on trust-building aesthetics, conversion optimization, and professional credibility. The design system avoids generic AI patterns (purple-blue gradients, violet schemes) in favor of a trust-focused blue palette that conveys reliability and social proof credibility.

## 1. Component Selection Matrix

### Landing Page Components

#### Hero Section
- **Card**: Main container for hero content with subtle shadow
  - `className="w-full max-w-4xl mx-auto bg-white border-slate-200 shadow-lg"`
- **Button (Primary)**: Generate widget CTA
  - `variant="default"` with custom `className="bg-blue-600 hover:bg-blue-700 text-white"`
- **Input**: YouTube URL input field
  - `className="flex-1 bg-white border-slate-300 focus:border-blue-500 focus:ring-blue-500"`
- **Badge**: Feature highlights
  - `variant="secondary"` with `className="bg-green-100 text-green-800"`

#### Features Showcase
- **Card**: Feature preview containers (4-grid)
  - `className="bg-white border-slate-200 hover:shadow-md transition-shadow"`
- **Avatar**: Feature icons
  - `className="bg-blue-100 text-blue-600"`
- **Separator**: Between feature sections
  - `className="bg-slate-200"`

#### Recent Widgets Section
- **ScrollArea**: Horizontal widget list on mobile
- **Card**: Individual widget previews
  - `className="bg-white border-slate-200 hover:border-blue-300"`
- **Badge**: Sentiment indicators
  - Success: `className="bg-green-100 text-green-800"`
  - Warning: `className="bg-amber-100 text-amber-800"`

### Widget Creation Interface

#### URL Input & Processing
- **Form**: URL validation and submission
- **Input**: YouTube URL field with validation
  - `className="bg-white border-slate-300 focus:border-blue-500"`
- **Button**: Submit and loading states
  - `className="bg-blue-600 hover:bg-blue-700 text-white disabled:opacity-50"`
- **Progress**: API processing indicator
  - `className="bg-slate-200 [&>div]:bg-blue-600"`
- **AlertCircle**: Error state icons
- **CheckCircle**: Success state icons

#### Processing Screen
- **Card**: Progress container
  - `className="w-full max-w-2xl mx-auto bg-white border-slate-200"`
- **Progress**: Multi-step progress bar
  - `className="h-2 bg-slate-200 [&>div]:bg-blue-600"`
- **Badge**: Status indicators
  - Processing: `className="bg-blue-100 text-blue-800"`
  - Complete: `className="bg-green-100 text-green-800"`
  - Error: `className="bg-red-100 text-red-800"`

### Widget Preview & Customization

#### Preview Container
- **Card**: Widget display area
  - `className="bg-white border-slate-200 shadow-md rounded-lg overflow-hidden"`
- **AspectRatio**: Maintain widget proportions
  - `ratio={4/3}` for consistent widget sizing
- **Skeleton**: Loading placeholders
  - `className="bg-slate-200 animate-pulse"`

#### Customization Panel
- **Tabs**: Organized settings sections
  - `className="w-full"`
  - TabsList: `className="grid grid-cols-4 bg-slate-100"`
  - TabsTrigger: `className="data-[state=active]:bg-white data-[state=active]:text-blue-600"`
- **Label**: Form field labels
  - `className="text-sm font-medium text-slate-700"`
- **RadioGroup**: Size and theme selection
  - `className="flex gap-4"`
- **Switch**: Toggle options
  - `className="data-[state=checked]:bg-blue-600"`
- **Slider**: Customization ranges
  - `className="[&>span:first-child]:bg-slate-200 [&>span:last-child]:bg-blue-600"`

#### Settings Panels
- **Accordion**: Collapsible settings sections
  - `className="w-full"`
  - AccordionTrigger: `className="hover:text-blue-600"`
- **Checkbox**: Display element toggles
  - `className="data-[state=checked]:bg-blue-600 data-[state=checked]:border-blue-600"`
- **Select**: Dropdown configurations
  - `className="bg-white border-slate-300"`

### Code Export Interface

#### Export Options
- **RadioGroup**: Format selection (iframe, JS, React)
  - `className="grid grid-cols-1 gap-4 sm:grid-cols-3"`
- **Card**: Code preview container
  - `className="bg-slate-50 border-slate-200"`
- **ScrollArea**: Code overflow handling
- **Button**: Copy actions
  - Primary: `className="bg-blue-600 hover:bg-blue-700 text-white"`
  - Secondary: `className="bg-slate-100 hover:bg-slate-200 text-slate-700 border-slate-300"`

#### Integration Guide
- **Alert**: Platform-specific instructions
  - `className="bg-blue-50 border-blue-200 text-blue-800"`
- **Code**: Inline code snippets
  - `className="bg-slate-100 text-slate-800 px-1 py-0.5 rounded"`

### Error & Success States

#### Error Handling
- **Alert**: Error notifications
  - `variant="destructive"` with `className="bg-red-50 border-red-200 text-red-800"`
- **AlertDialog**: Critical error modals
  - `className="bg-white border-slate-200"`
- **Button**: Retry actions
  - `variant="outline"` with `className="border-red-300 text-red-700 hover:bg-red-50"`

#### Success States
- **Alert**: Success notifications
  - `className="bg-green-50 border-green-200 text-green-800"`
- **Toast**: Immediate feedback
  - `className="bg-green-600 text-white"`

## 2. Trust-Focused Design System Implementation

### Color Palette Configuration

#### CSS Variables (Trust Blue Scheme)
```css
:root {
  /* Primary Trust Colors */
  --primary-50: #eff6ff;
  --primary-100: #dbeafe;
  --primary-200: #bfdbfe;
  --primary-300: #93c5fd;
  --primary-400: #60a5fa;
  --primary-500: #3b82f6;  /* Main trust blue */
  --primary-600: #2563eb;  /* Primary button color */
  --primary-700: #1d4ed8;  /* Hover states */
  --primary-800: #1e40af;  /* Active states */
  --primary-900: #1e3a8a;  /* Darkest blue */
  
  /* Success Colors (Social Proof Positive) */
  --success-50: #ecfdf5;
  --success-100: #d1fae5;
  --success-200: #a7f3d0;
  --success-500: #10b981;
  --success-600: #059669;  /* Positive indicators */
  
  /* Warning Colors (Limited Data) */
  --warning-50: #fffbeb;
  --warning-100: #fef3c7;
  --warning-500: #f59e0b;
  --warning-600: #d97706;
  
  /* Error Colors */
  --error-50: #fef2f2;
  --error-100: #fee2e2;
  --error-500: #ef4444;
  --error-600: #dc2626;
  
  /* Neutral Grays */
  --slate-50: #f8fafc;
  --slate-100: #f1f5f9;
  --slate-200: #e2e8f0;
  --slate-300: #cbd5e1;
  --slate-400: #94a3b8;
  --slate-500: #64748b;
  --slate-600: #475569;
  --slate-700: #334155;
  --slate-800: #1e293b;
  --slate-900: #0f172a;
}

/* Dark Mode */
[data-theme="dark"] {
  --bg-primary: var(--slate-900);
  --bg-secondary: var(--slate-800);
  --text-primary: var(--slate-50);
  --text-secondary: var(--slate-300);
}
```

#### Tailwind Configuration
```javascript
// tailwind.config.js
module.exports = {
  theme: {
    extend: {
      colors: {
        // Trust Blue Primary
        primary: {
          50: 'rgb(239, 246, 255)',
          500: 'rgb(59, 130, 246)',
          600: 'rgb(37, 99, 235)',  // Main CTA color
          700: 'rgb(29, 78, 216)',  // Hover states
        },
        
        // Social Proof Success
        'social-success': {
          50: 'rgb(236, 253, 245)',
          600: 'rgb(5, 150, 105)',
        },
        
        // Trust indicators
        trust: {
          background: 'rgb(248, 250, 252)',  // Slate 50
          foreground: 'rgb(51, 65, 85)',     // Slate 700
          muted: 'rgb(148, 163, 184)',       // Slate 400
        }
      }
    }
  }
}
```

### Typography System

```css
/* Typography Hierarchy */
.hero-heading {
  @apply text-4xl md:text-5xl font-bold text-slate-900 leading-tight;
}

.section-heading {
  @apply text-2xl md:text-3xl font-semibold text-slate-800 leading-tight;
}

.body-text {
  @apply text-base text-slate-600 leading-relaxed;
}

.subtitle-text {
  @apply text-lg text-slate-500 leading-relaxed;
}

.metadata-text {
  @apply text-sm text-slate-400 font-medium;
}

.code-text {
  @apply font-mono text-sm bg-slate-100 text-slate-800 px-2 py-1 rounded;
}
```

## 3. Beautiful Composition Strategy

### Visual Hierarchy Implementation

#### Primary Actions (High Conversion Focus)
- **Generate Widget Button**: 
  ```tsx
  <Button className="bg-blue-600 hover:bg-blue-700 text-white font-semibold px-8 py-3 text-lg shadow-md hover:shadow-lg transform hover:-translate-y-0.5 transition-all duration-200">
    Generate Widget
  </Button>
  ```

#### Secondary Actions (Supporting Interactions)
- **Copy Code Button**:
  ```tsx
  <Button variant="outline" className="border-blue-300 text-blue-700 hover:bg-blue-50 hover:border-blue-400">
    Copy Code
  </Button>
  ```

#### Tertiary Actions (Navigation & Utilities)
- **Back Button**:
  ```tsx
  <Button variant="ghost" className="text-slate-600 hover:text-slate-800 hover:bg-slate-100">
    ← Back to Home
  </Button>
  ```

### Component Harmony Patterns

#### Card Elevation System
```css
/* Subtle depth for trust */
.card-base {
  @apply bg-white border border-slate-200 rounded-lg;
}

.card-hover {
  @apply hover:shadow-md hover:border-blue-200 transition-all duration-200;
}

.card-active {
  @apply shadow-lg border-blue-300 ring-1 ring-blue-100;
}

.card-widget-preview {
  @apply bg-white border border-slate-200 rounded-lg shadow-md overflow-hidden;
}
```

#### Spacing Rhythm (8px Grid)
```css
/* Consistent spacing for visual harmony */
.space-section {
  @apply py-16 px-4;  /* 64px vertical, 16px horizontal */
}

.space-component {
  @apply gap-6;      /* 24px between related components */
}

.space-element {
  @apply gap-4;      /* 16px between form elements */
}

.space-tight {
  @apply gap-2;      /* 8px for compact layouts */
}
```

### Animation Guidelines

#### Micro-interactions
```css
/* Smooth, professional animations */
.button-hover {
  @apply transform hover:-translate-y-0.5 hover:shadow-lg transition-all duration-200 ease-out;
}

.card-hover {
  @apply hover:shadow-md hover:border-blue-200 transition-all duration-200 ease-out;
}

.input-focus {
  @apply focus:border-blue-500 focus:ring-2 focus:ring-blue-200 focus:ring-opacity-50 transition-all duration-150;
}
```

#### Loading States
```tsx
// Skeleton components for smooth loading
<div className="animate-pulse">
  <div className="bg-slate-200 h-4 rounded mb-2"></div>
  <div className="bg-slate-200 h-4 rounded w-3/4"></div>
</div>
```

## 4. Accessibility Patterns & WCAG Compliance

### Focus Management

#### Tab Navigation Order
1. URL input field (autofocus on page load)
2. Generate widget button
3. Customization tabs (Size → Theme → Content → Advanced)
4. Widget preview (keyboard accessible via tab)
5. Copy code button
6. Additional actions (Download, View)

#### Keyboard Support
```tsx
// Custom keyboard handlers for widget preview
<div
  role="region"
  aria-label="Widget preview"
  tabIndex={0}
  onKeyDown={(e) => {
    if (e.key === 'Enter' || e.key === ' ') {
      // Activate widget interaction
    }
  }}
  className="focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 rounded-lg"
>
  {widgetContent}
</div>
```

### Screen Reader Support

#### ARIA Labels & Roles
```tsx
// Form sections
<fieldset>
  <legend className="sr-only">Widget customization options</legend>
  <Label htmlFor="widget-size">Widget Size</Label>
  <RadioGroup 
    value={size} 
    onValueChange={setSize}
    aria-describedby="size-help"
  >
    <RadioGroupItem value="small" id="size-small" />
    <Label htmlFor="size-small">Small (300px)</Label>
  </RadioGroup>
  <p id="size-help" className="text-sm text-slate-500">
    Choose the widget size that fits your layout
  </p>
</fieldset>
```

#### Status Announcements
```tsx
// Live regions for dynamic content
<div 
  role="status" 
  aria-live="polite"
  className="sr-only"
>
  {isProcessing ? "Analyzing video content..." : "Widget generated successfully"}
</div>
```

### Color Contrast Validation

#### WCAG AA Compliance (4.5:1 minimum)
- **Primary text on white**: `text-slate-900` (15.1:1 ratio) ✅
- **Secondary text on white**: `text-slate-600` (7.8:1 ratio) ✅
- **Blue button text**: `text-white on bg-blue-600` (5.9:1 ratio) ✅
- **Success indicators**: `text-green-800 on bg-green-50` (6.4:1 ratio) ✅
- **Error states**: `text-red-800 on bg-red-50` (6.2:1 ratio) ✅

#### High Contrast Mode Support
```css
@media (prefers-contrast: high) {
  .button-primary {
    @apply border-2 border-current;
  }
  
  .card-border {
    @apply border-2 border-slate-400;
  }
}
```

## 5. Implementation Guidelines

### Component Installation Commands

```bash
# Core layout and structure
npx shadcn@latest add card button input label
npx shadcn@latest add tabs radio-group switch checkbox
npx shadcn@latest add progress skeleton alert

# Advanced interactions
npx shadcn@latest add select accordion slider
npx shadcn@latest add toast alert-dialog popover
npx shadcn@latest add scroll-area aspect-ratio

# Form and validation
npx shadcn@latest add form textarea badge
npx shadcn@latest add separator avatar
```

### Next.js Integration Patterns

#### Layout Component Structure
```tsx
// app/layout.tsx
import { Inter } from 'next/font/google'
import { cn } from '@/lib/utils'

const inter = Inter({ subsets: ['latin'] })

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en" className={cn("antialiased", inter.className)}>
      <body className="min-h-screen bg-slate-50 text-slate-900">
        <div className="relative flex min-h-screen flex-col">
          <header className="sticky top-0 z-50 w-full border-b border-slate-200 bg-white/95 backdrop-blur supports-[backdrop-filter]:bg-white/60">
            {/* Navigation */}
          </header>
          <main className="flex-1">
            {children}
          </main>
          <footer className="border-t border-slate-200 bg-white">
            {/* Footer content */}
          </footer>
        </div>
      </body>
    </html>
  )
}
```

#### Custom Component Extensions

```tsx
// components/ui/widget-card.tsx
import { Card, CardContent, CardHeader } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { cn } from "@/lib/utils"

interface WidgetCardProps {
  title: string
  views: string
  sentiment: number
  className?: string
}

export function WidgetCard({ title, views, sentiment, className }: WidgetCardProps) {
  return (
    <Card className={cn(
      "bg-white border-slate-200 hover:border-blue-200 hover:shadow-md transition-all duration-200",
      className
    )}>
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <h3 className="font-medium text-slate-900 truncate">{title}</h3>
          <Badge 
            variant="secondary" 
            className="bg-green-100 text-green-800 hover:bg-green-100"
          >
            ⭐ {sentiment.toFixed(1)}
          </Badge>
        </div>
      </CardHeader>
      <CardContent>
        <p className="text-sm text-slate-500">{views} views</p>
      </CardContent>
    </Card>
  )
}
```

### Performance Optimizations

#### Lazy Loading Strategy
```tsx
// Dynamic imports for heavy components
const WidgetPreview = dynamic(() => import('@/components/widget-preview'), {
  loading: () => <WidgetPreviewSkeleton />,
  ssr: false
})

const CodeEditor = dynamic(() => import('@/components/code-editor'), {
  loading: () => <div className="h-64 bg-slate-100 animate-pulse rounded" />
})
```

#### Image Optimization
```tsx
import Image from 'next/image'

// YouTube thumbnails with proper optimization
<div className="relative aspect-video overflow-hidden rounded-lg">
  <Image
    src={thumbnailUrl}
    alt={videoTitle}
    fill
    className="object-cover"
    sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw"
    priority={isAboveFold}
  />
</div>
```

### Responsive Implementation

#### Mobile-First Breakpoints
```tsx
// Responsive grid patterns
<div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
  {/* Feature cards */}
</div>

// Responsive text sizing
<h1 className="text-3xl sm:text-4xl lg:text-5xl font-bold">
  Transform Your YouTube Success
</h1>

// Responsive spacing
<section className="py-12 px-4 sm:py-16 sm:px-6 lg:py-20 lg:px-8">
  {/* Section content */}
</section>
```

#### Touch-Friendly Interactions
```css
/* Minimum 44px touch targets */
.touch-target {
  @apply min-h-[44px] min-w-[44px] flex items-center justify-center;
}

/* Larger buttons on mobile */
@media (max-width: 640px) {
  .mobile-button {
    @apply py-4 px-6 text-lg;
  }
}
```

## 6. Integration with YouTube Widget Rendering

### Widget Embed Component
```tsx
// components/widget-embed.tsx
interface WidgetEmbedProps {
  videoId: string
  size: 'small' | 'medium' | 'large'
  theme: 'light' | 'dark' | 'auto'
  showComments?: boolean
  showSentiment?: boolean
}

export function WidgetEmbed({ 
  videoId, 
  size, 
  theme, 
  showComments = true,
  showSentiment = true 
}: WidgetEmbedProps) {
  const sizeClasses = {
    small: 'w-72 h-54',  // 288x216
    medium: 'w-96 h-72', // 384x288
    large: 'w-[500px] h-[375px]'
  }
  
  return (
    <Card className={cn(
      "overflow-hidden bg-white border-slate-200",
      sizeClasses[size],
      theme === 'dark' && "bg-slate-900 border-slate-700"
    )}>
      {/* Widget content */}
    </Card>
  )
}
```

## 7. Error Handling & Edge Cases

### Graceful Degradation
```tsx
// Error boundary for widget preview
export function WidgetErrorBoundary({ children }: { children: React.ReactNode }) {
  return (
    <ErrorBoundary
      fallback={
        <Alert className="bg-red-50 border-red-200">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>Widget Preview Error</AlertTitle>
          <AlertDescription>
            Unable to display widget preview. Please try refreshing the page.
          </AlertDescription>
        </Alert>
      }
    >
      {children}
    </ErrorBoundary>
  )
}
```

### Loading States
```tsx
// Comprehensive loading patterns
export function WidgetSkeleton() {
  return (
    <Card className="w-96 h-72 p-4">
      <div className="animate-pulse">
        <div className="bg-slate-200 h-32 rounded mb-4"></div>
        <div className="bg-slate-200 h-4 rounded mb-2"></div>
        <div className="bg-slate-200 h-4 rounded w-3/4 mb-4"></div>
        <div className="flex gap-2">
          <div className="bg-slate-200 h-6 w-16 rounded"></div>
          <div className="bg-slate-200 h-6 w-16 rounded"></div>
        </div>
      </div>
    </Card>
  )
}
```

## Summary

This comprehensive shadcn/ui implementation plan provides:

1. **Trust-Focused Component Selection**: Professional components that build credibility
2. **Conversion-Optimized Design**: Clear CTAs and social proof elements
3. **Accessibility Excellence**: WCAG-compliant implementations
4. **Performance Optimization**: Efficient component loading and rendering
5. **Mobile-First Responsive**: Beautiful experience across all devices
6. **Brand Consistency**: Cohesive visual language using trust blue palette

The implementation avoids generic AI design patterns (purple gradients, violet schemes) in favor of industry-appropriate colors that enhance user trust and conversion rates. All components are selected to work harmoniously together while maintaining the professional, credible aesthetic essential for social proof applications.

File paths referenced:
- `/home/chong-u/projects/yt-social-proof/.claude/outputs/design/agents/shadcn-expert/youtube-social-proof-20250904-141128/component-implementation.md`