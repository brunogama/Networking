# YouTube Social Proof Widget - E2E Test Specifications

## Executive Summary

This document provides comprehensive End-to-End test specifications for the YouTube Social Proof Widget application using **Stagehand's AI-powered browser automation** with natural language testing capabilities. Tests are designed to validate all user stories from the PRD, cover critical edge cases, and ensure reliable widget generation and embedding functionality.

## Test Coverage Strategy

### 1. User Story Mapping to Test Cases

#### Developer Stories (PRD Stories 1-3)
- **Repository Setup (Story 1)**: Local deployment and configuration tests
- **Widget Generation (Story 2)**: YouTube URL processing and widget creation
- **Widget Customization (Story 3)**: Appearance and behavior modifications

#### End User Stories (PRD Stories 4-5)
- **Widget Viewing (Story 4)**: Embedded widget display and functionality
- **Comment Discovery (Story 5)**: Comment carousel interaction and display

#### Business Stories (PRD Stories 6-7)
- **Trust Building (Story 6)**: Engagement metrics and social proof display
- **Content Leverage (Story 7)**: Multi-widget deployment and reuse

### 2. Testing Approach Classification

**Pure Stagehand Tests (Preferred - 80% of tests)**:
- User workflow automation using natural language
- Complex UI interactions and widget customization
- Cross-platform compatibility testing
- Error handling and recovery scenarios

**Hybrid Tests (15% of tests)**:
- Stagehand for discovery and interaction
- Playwright for precise API response validation
- Performance metrics and timing assertions

**Pure Playwright Tests (5% of tests)**:
- Exact value validation (API responses, CSS properties)
- Technical accessibility compliance
- Browser API interactions

---

## Core Test Scenarios

### Scenario Group A: Widget Creation Flow

#### A1. First-Time User Happy Path
```typescript
test("First-time user creates widget successfully", async () => {
  const stagehand = new Stagehand({
    env: "LOCAL",
    modelName: "gpt-4o",
    modelClientOptions: {
      apiKey: process.env.OPENAI_API_KEY,
    },
    verbose: 1,
  });

  await stagehand.init();
  const page = stagehand.page;

  await page.goto("http://localhost:3000");
  
  // Landing page interaction
  await page.act("Look at the hero section and understand the value proposition");
  await page.observe("Verify the main heading explains social proof widgets");
  
  // Valid YouTube URL input
  await page.act("Paste a valid YouTube URL into the input field");
  await page.act("Click the Generate Widget button");
  
  // Processing screen
  await page.observe("Wait for the processing screen to appear");
  await page.act("Watch the progress indicators update");
  
  // Preview screen
  await page.observe("Verify widget preview loads with video thumbnail and metrics");
  await page.act("Check that sentiment score and comment carousel are visible");
  
  // Customization
  await page.act("Try changing the widget size to large");
  await page.act("Switch to dark theme");
  await page.act("Update the widget preview");
  
  // Code generation
  await page.act("Generate the embed code");
  await page.act("Copy the iframe code to clipboard");
  
  // Verify success
  const embedCode = await page.extract({
    instruction: "get the generated embed code",
    schema: z.object({
      hasIframe: z.boolean(),
      includesWidgetId: z.boolean(),
      hasCorrectDimensions: z.boolean(),
    }),
  });
  
  expect(embedCode.hasIframe).toBe(true);
  expect(embedCode.includesWidgetId).toBe(true);
  
  await stagehand.close();
});
```

#### A2. Multiple YouTube URL Formats
```typescript
test("Handles various YouTube URL formats correctly", async () => {
  const stagehand = new Stagehand({
    env: "LOCAL",
    modelName: "gpt-4o",
    modelClientOptions: {
      apiKey: process.env.OPENAI_API_KEY,
    },
  });

  await stagehand.init();
  const page = stagehand.page;

  const urlFormats = [
    "https://www.youtube.com/watch?v=dQw4w9WgXcQ",
    "https://youtu.be/dQw4w9WgXcQ",
    "https://www.youtube.com/watch?v=dQw4w9WgXcQ&t=30s",
    "https://m.youtube.com/watch?v=dQw4w9WgXcQ",
  ];

  await page.goto("http://localhost:3000");

  for (const url of urlFormats) {
    await page.act(`Clear the URL input and paste: ${url}`);
    await page.act("Click Generate Widget");
    await page.observe("Verify the URL is accepted and processing begins");
    await page.act("Wait for processing to complete or return to home");
  }

  await stagehand.close();
});
```

#### A3. Widget Customization Workflow
```typescript
test("Widget customization updates preview correctly", async () => {
  const stagehand = new Stagehand({
    env: "LOCAL",
    modelName: "gpt-4o",
    modelClientOptions: {
      apiKey: process.env.OPENAI_API_KEY,
    },
  });

  await stagehand.init();
  const page = stagehand.page;

  await page.goto("http://localhost:3000");
  
  // Generate a widget first
  await page.act("Enter a valid YouTube URL and generate widget");
  await page.observe("Wait for widget preview to load");
  
  // Test size changes
  await page.act("Change widget size from medium to small");
  await page.act("Update preview");
  await page.observe("Verify widget preview becomes smaller");
  
  await page.act("Change widget size to large");
  await page.act("Update preview");
  await page.observe("Verify widget preview becomes larger");
  
  // Test theme changes
  await page.act("Switch from light theme to dark theme");
  await page.act("Update preview");
  await page.observe("Verify widget background becomes dark");
  
  await page.act("Switch to auto theme");
  await page.act("Update preview");
  
  // Test content options
  await page.act("Disable the comment carousel option");
  await page.act("Update preview");
  await page.observe("Verify comments section disappears from preview");
  
  await page.act("Re-enable comment carousel");
  await page.act("Disable sentiment score display");
  await page.act("Update preview");
  await page.observe("Verify sentiment stars disappear but comments remain");
  
  // Test style changes
  await page.act("Change widget style from card to minimal");
  await page.act("Update preview");
  await page.observe("Verify widget styling becomes more minimal");
  
  await stagehand.close();
});
```

### Scenario Group B: Error Handling and Edge Cases

#### B1. Invalid YouTube URL Handling
```typescript
test("Handles invalid YouTube URLs gracefully", async () => {
  const stagehand = new Stagehand({
    env: "LOCAL",
    modelName: "gpt-4o",
    modelClientOptions: {
      apiKey: process.env.OPENAI_API_KEY,
    },
  });

  await stagehand.init();
  const page = stagehand.page;

  const invalidUrls = [
    "https://www.google.com",
    "not-a-url",
    "https://youtube.com/invalid",
    "",
    "https://www.youtube.com/watch?v=invalid123",
  ];

  await page.goto("http://localhost:3000");

  for (const url of invalidUrls) {
    await page.act(`Enter the invalid URL: ${url}`);
    await page.act("Try to generate widget");
    await page.observe("Verify an appropriate error message appears");
    await page.observe("Verify the interface remains functional");
    await page.act("Clear the input field");
  }

  await stagehand.close();
});
```

#### B2. Private Video Error Handling
```typescript
test("Handles private/deleted videos appropriately", async () => {
  const stagehand = new Stagehand({
    env: "LOCAL",
    modelName: "gpt-4o",
    modelClientOptions: {
      apiKey: process.env.OPENAI_API_KEY,
    },
  });

  await stagehand.init();
  const page = stagehand.page;

  await page.goto("http://localhost:3000");
  
  // Test with private video URL (mock scenario)
  await page.act("Enter a YouTube URL for a private video");
  await page.act("Generate widget");
  await page.observe("Wait for processing to complete");
  
  // Verify error handling
  await page.observe("Check if error screen appears explaining video is private");
  await page.act("Look for suggested solutions or retry options");
  await page.act("Try to return to home screen");
  await page.observe("Verify user can start over with a different video");

  await stagehand.close();
});
```

#### B3. Comments Disabled Video Handling
```typescript
test("Handles videos with disabled comments", async () => {
  const stagehand = new Stagehand({
    env: "LOCAL",
    modelName: "gpt-4o",
    modelClientOptions: {
      apiKey: process.env.OPENAI_API_KEY,
    },
  });

  await stagehand.init();
  const page = stagehand.page;

  await page.goto("http://localhost:3000");
  
  // Test with video that has comments disabled
  await page.act("Enter YouTube URL for video with disabled comments");
  await page.act("Generate widget");
  await page.observe("Wait for processing to complete");
  
  // Verify limited data widget creation
  await page.observe("Check if limited data warning appears");
  await page.observe("Verify basic metrics (views, channel) are shown");
  await page.observe("Verify comment carousel is not present");
  await page.observe("Verify sentiment analysis section is not shown");
  
  await page.act("Proceed to generate limited widget");
  await page.observe("Verify embed code is still generated");

  await stagehand.close();
});
```

#### B4. API Rate Limiting Scenarios
```typescript
test("Handles API rate limiting gracefully", async () => {
  const stagehand = new Stagehand({
    env: "LOCAL",
    modelName: "gpt-4o",
    modelClientOptions: {
      apiKey: process.env.OPENAI_API_KEY,
    },
  });

  await stagehand.init();
  const page = stagehand.page;

  await page.goto("http://localhost:3000");
  
  // Simulate rapid widget generation requests
  for (let i = 0; i < 10; i++) {
    await page.act(`Generate widget for test video ${i + 1}`);
    await page.observe("Check for rate limiting warnings");
    
    if (i > 5) {
      // Check if queue system activates
      await page.observe("Look for queue position or wait time messages");
      await page.act("Choose to wait in queue or try again later");
    }
  }

  await stagehand.close();
});
```

### Scenario Group C: Widget Embedding and Display

#### C1. Embed Code Generation and Copy
```typescript
test("Embed code generation and clipboard functionality", async () => {
  const stagehand = new Stagehand({
    env: "LOCAL",
    modelName: "gpt-4o",
    modelClientOptions: {
      apiKey: process.env.OPENAI_API_KEY,
    },
  });

  await stagehand.init();
  const page = stagehand.page;

  await page.goto("http://localhost:3000");
  
  // Create widget
  await page.act("Generate a widget with default settings");
  await page.observe("Wait for preview to load");
  
  // Test different embed formats
  await page.act("Select iframe embed format");
  await page.observe("Verify iframe code is shown");
  await page.act("Copy embed code to clipboard");
  
  await page.act("Switch to JavaScript SDK format");
  await page.observe("Verify JavaScript code is shown");
  
  await page.act("Switch to React component format");
  await page.observe("Verify React JSX code is shown");
  
  await page.act("Switch to WordPress shortcode format");
  await page.observe("Verify WordPress shortcode is shown");
  
  // Test direct URL option
  await page.act("Select direct URL option");
  await page.observe("Verify direct widget URL is provided");
  
  // Test download functionality
  await page.act("Download embed code as HTML file");
  // Note: File download testing would need special handling

  await stagehand.close();
});
```

#### C2. Widget Responsiveness Testing
```typescript
test("Widget displays responsively across screen sizes", async () => {
  const stagehand = new Stagehand({
    env: "LOCAL",
    modelName: "gpt-4o",
    modelClientOptions: {
      apiKey: process.env.OPENAI_API_KEY,
    },
  });

  await stagehand.init();
  const page = stagehand.page;

  await page.goto("http://localhost:3000");
  
  // Generate widget
  await page.act("Create a widget with default settings");
  await page.observe("Wait for widget preview to load");
  
  // Test different viewport sizes
  const viewports = [
    { width: 320, height: 568, name: "mobile" },
    { width: 768, height: 1024, name: "tablet" },
    { width: 1024, height: 768, name: "desktop" },
    { width: 1920, height: 1080, name: "large desktop" },
  ];

  for (const viewport of viewports) {
    await page.setViewportSize(viewport);
    await page.observe(`Verify widget preview looks good on ${viewport.name}`);
    await page.observe("Check that all elements are visible and properly sized");
    await page.observe("Verify text is readable and buttons are clickable");
    
    if (viewport.width <= 768) {
      await page.observe("Verify mobile-optimized layout is used");
    }
  }

  await stagehand.close();
});
```

#### C3. Multiple Widgets on Same Page
```typescript
test("Multiple widgets can coexist on same page", async () => {
  const stagehand = new Stagehand({
    env: "LOCAL",
    modelName: "gpt-4o",
    modelClientOptions: {
      apiKey: process.env.OPENAI_API_KEY,
    },
  });

  await stagehand.init();
  const page = stagehand.page;

  await page.goto("http://localhost:3000");
  
  // Create first widget
  await page.act("Generate widget for first YouTube video");
  await page.observe("Wait for first widget to complete");
  await page.act("Copy embed code for first widget");
  
  // Create second widget
  await page.act("Create another widget");
  await page.act("Generate widget for second YouTube video with different settings");
  await page.observe("Wait for second widget to complete");
  await page.act("Copy embed code for second widget");
  
  // Test that both widgets work independently
  // This would require a test page with both embeds
  // await page.goto("http://localhost:3000/test-multiple-widgets");
  // await page.observe("Verify both widgets display independently");
  // await page.observe("Verify widget interactions don't interfere with each other");

  await stagehand.close();
});
```

### Scenario Group D: Comment Carousel Interaction

#### D1. Comment Carousel Navigation
```typescript
test("Comment carousel navigation and display", async () => {
  const stagehand = new Stagehand({
    env: "LOCAL",
    modelName: "gpt-4o",
    modelClientOptions: {
      apiKey: process.env.OPENAI_API_KEY,
    },
  });

  await stagehand.init();
  const page = stagehand.page;

  await page.goto("http://localhost:3000");
  
  // Generate widget with many comments
  await page.act("Generate widget for a YouTube video with many positive comments");
  await page.observe("Wait for widget preview to load with comment carousel");
  
  // Test manual navigation
  await page.act("Click the next button on the comment carousel");
  await page.observe("Verify the comment changes to the next one");
  
  await page.act("Click the previous button on the comment carousel");
  await page.observe("Verify the comment changes back to the previous one");
  
  // Test automatic rotation
  await page.act("Enable auto-rotate comments every 3 seconds");
  await page.act("Update preview");
  await page.observe("Wait and verify comments automatically change after 3 seconds");
  await page.observe("Wait for another rotation to confirm it's working");
  
  // Test dot navigation
  await page.act("Click on the third dot indicator");
  await page.observe("Verify the comment jumps to the third comment");
  
  // Test hover behavior
  await page.act("Hover over the comment carousel");
  await page.observe("Verify auto-rotation pauses during hover");
  
  await page.act("Move mouse away from carousel");
  await page.observe("Verify auto-rotation resumes");

  await stagehand.close();
});
```

#### D2. Comment Content and Sentiment Display
```typescript
test("Comment sentiment filtering and display quality", async () => {
  const stagehand = new Stagehand({
    env: "LOCAL",
    modelName: "gpt-4o",
    modelClientOptions: {
      apiKey: process.env.OPENAI_API_KEY,
    },
  });

  await stagehand.init();
  const page = stagehand.page;

  await page.goto("http://localhost:3000");
  
  // Generate widget
  await page.act("Generate widget for a YouTube video");
  await page.observe("Wait for sentiment analysis to complete");
  
  // Check sentiment filtering options
  await page.act("Set minimum sentiment rating to 4 stars");
  await page.act("Update preview");
  await page.observe("Verify only highly positive comments are shown");
  
  await page.act("Change sentiment filter to show mixed comments");
  await page.act("Update preview");
  await page.observe("Verify mix of positive and neutral comments appear");
  
  await page.act("Set filter to show all comments");
  await page.act("Update preview");
  await page.observe("Verify all comment types are included");
  
  // Test comment quality
  await page.observe("Check that comments are properly formatted");
  await page.observe("Verify comment author names are displayed");
  await page.observe("Verify comments are readable and not truncated inappropriately");

  await stagehand.close();
});
```

### Scenario Group E: Performance and Reliability

#### E1. Widget Load Time Performance
```typescript
test("Widget loads within performance requirements", async ({ page }) => {
  // Pure Playwright test for precise timing
  const startTime = Date.now();
  
  await page.goto("http://localhost:3000");
  
  const urlInput = page.locator('[data-testid="youtube-url-input"]');
  const generateButton = page.locator('[data-testid="generate-widget-button"]');
  
  await urlInput.fill("https://www.youtube.com/watch?v=dQw4w9WgXcQ");
  await generateButton.click();
  
  // Wait for widget preview to appear
  await page.waitForSelector('[data-testid="widget-preview"]', { timeout: 10000 });
  
  const loadTime = Date.now() - startTime;
  expect(loadTime).toBeLessThan(2000); // PRD requirement: under 2 seconds
});
```

#### E2. Concurrent User Load Testing
```typescript
test("Handles multiple concurrent widget generations", async () => {
  const stagehandInstances = [];
  const testPromises = [];

  // Create multiple Stagehand instances
  for (let i = 0; i < 5; i++) {
    const stagehand = new Stagehand({
      env: "LOCAL",
      modelName: "gpt-4o",
      modelClientOptions: {
        apiKey: process.env.OPENAI_API_KEY,
      },
    });
    
    await stagehand.init();
    stagehandInstances.push(stagehand);
    
    // Create concurrent widget generation promises
    const testPromise = (async () => {
      const page = stagehand.page;
      await page.goto("http://localhost:3000");
      await page.act(`Generate widget ${i + 1} with different YouTube URL`);
      await page.observe("Wait for widget generation to complete");
      return i;
    })();
    
    testPromises.push(testPromise);
  }

  // Execute all tests concurrently
  const results = await Promise.allSettled(testPromises);
  
  // Verify all succeeded or handled gracefully
  results.forEach((result, index) => {
    if (result.status === 'fulfilled') {
      console.log(`Widget ${index + 1} generated successfully`);
    } else {
      console.log(`Widget ${index + 1} failed: ${result.reason}`);
    }
  });

  // Cleanup
  for (const stagehand of stagehandInstances) {
    await stagehand.close();
  }
});
```

#### E3. Widget Caching Validation
```typescript
test("Widget data caching works correctly", async () => {
  const stagehand = new Stagehand({
    env: "LOCAL",
    modelName: "gpt-4o",
    modelClientOptions: {
      apiKey: process.env.OPENAI_API_KEY,
    },
  });

  await stagehand.init();
  const page = stagehand.page;

  const testUrl = "https://www.youtube.com/watch?v=dQw4w9WgXcQ";

  await page.goto("http://localhost:3000");
  
  // First widget generation
  const startTime1 = Date.now();
  await page.act(`Generate widget for ${testUrl}`);
  await page.observe("Wait for first widget generation to complete");
  const firstGenTime = Date.now() - startTime1;
  
  // Return to home
  await page.act("Return to home page");
  
  // Second widget generation with same URL
  const startTime2 = Date.now();
  await page.act(`Generate widget for the same URL: ${testUrl}`);
  await page.observe("Wait for second widget generation to complete");
  const secondGenTime = Date.now() - startTime2;
  
  // Verify caching improved performance
  console.log(`First generation: ${firstGenTime}ms, Second generation: ${secondGenTime}ms`);
  expect(secondGenTime).toBeLessThan(firstGenTime * 0.8); // Should be significantly faster

  await stagehand.close();
});
```

### Scenario Group F: Integration and Deployment

#### F1. Widget Embedding in External Sites
```typescript
test("Generated widget embeds correctly in external sites", async () => {
  const stagehand = new Stagehand({
    env: "LOCAL",
    modelName: "gpt-4o",
    modelClientOptions: {
      apiKey: process.env.OPENAI_API_KEY,
    },
  });

  await stagehand.init();
  const page = stagehand.page;

  // Generate widget and get embed code
  await page.goto("http://localhost:3000");
  await page.act("Generate a widget with default settings");
  await page.observe("Wait for widget to complete");
  
  const embedData = await page.extract({
    instruction: "get the iframe embed code",
    schema: z.object({
      embedCode: z.string(),
      widgetId: z.string(),
    }),
  });
  
  // Test widget on external site (would need test HTML page)
  // await page.goto("http://localhost:3001/test-embed-page");
  // await page.evaluate((code) => {
  //   document.querySelector('#widget-container').innerHTML = code;
  // }, embedData.embedCode);
  // 
  // await page.observe("Verify widget loads and displays correctly");
  // await page.observe("Verify widget is interactive");

  await stagehand.close();
});
```

#### F2. Cross-Browser Compatibility
```typescript
test("Widget works across different browsers", async () => {
  // This would need to be run with different browser configurations
  const browsers = ['chromium', 'firefox', 'webkit'];
  
  for (const browserName of browsers) {
    const stagehand = new Stagehand({
      env: "LOCAL",
      modelName: "gpt-4o",
      modelClientOptions: {
        apiKey: process.env.OPENAI_API_KEY,
      },
      // Browser config would be set here if supported
    });

    await stagehand.init();
    const page = stagehand.page;

    await page.goto("http://localhost:3000");
    await page.act(`Generate widget in ${browserName}`);
    await page.observe("Verify widget generates successfully");
    await page.observe("Verify widget preview displays correctly");
    await page.observe("Verify all interactions work properly");

    await stagehand.close();
  }
});
```

---

## Critical Edge Cases and Boundary Testing

### Interaction Conflict Tests

#### IC1. Widget Preview Click vs Drag Conflicts
```typescript
test("Widget preview handles click and drag interactions separately", async () => {
  const stagehand = new Stagehand({
    env: "LOCAL",
    modelName: "gpt-4o",
    modelClientOptions: {
      apiKey: process.env.OPENAI_API_KEY,
    },
  });

  await stagehand.init();
  const page = stagehand.page;

  await page.goto("http://localhost:3000");
  await page.act("Generate a widget");
  await page.observe("Wait for widget preview to load");
  
  // Test click without drag
  await page.act("Click on the widget preview without dragging");
  await page.observe("Verify click action works without triggering drag");
  
  // Test drag without click
  await page.act("Drag the widget preview to resize it without clicking");
  await page.observe("Verify drag action works without triggering click");
  
  // Test rapid interactions
  await page.act("Quickly click multiple times on widget preview");
  await page.observe("Verify rapid clicks don't interfere with each other");

  await stagehand.close();
});
```

#### IC2. Comment Carousel Touch vs Swipe Conflicts
```typescript
test("Comment carousel handles touch and swipe separately on mobile", async () => {
  const stagehand = new Stagehand({
    env: "LOCAL",
    modelName: "gpt-4o",
    modelClientOptions: {
      apiKey: process.env.OPENAI_API_KEY,
    },
  });

  await stagehand.init();
  const page = stagehand.page;

  // Set mobile viewport
  await page.setViewportSize({ width: 375, height: 667 });
  
  await page.goto("http://localhost:3000");
  await page.act("Generate widget with comment carousel");
  await page.observe("Wait for mobile-optimized widget to load");
  
  // Test tap vs swipe
  await page.act("Tap on comment text without swiping");
  await page.observe("Verify tap doesn't trigger swipe navigation");
  
  await page.act("Swipe left on comment carousel");
  await page.observe("Verify swipe changes comment without triggering tap");
  
  await page.act("Swipe right on comment carousel");
  await page.observe("Verify reverse swipe works");

  await stagehand.close();
});
```

### Boundary and Drop Target Testing

#### BT1. Widget Size Boundary Testing
```typescript
test("Widget size boundaries and custom dimensions", async () => {
  const stagehand = new Stagehand({
    env: "LOCAL",
    modelName: "gpt-4o",
    modelClientOptions: {
      apiKey: process.env.OPENAI_API_KEY,
    },
  });

  await stagehand.init();
  const page = stagehand.page;

  await page.goto("http://localhost:3000");
  await page.act("Generate widget and go to customization");
  
  // Test extreme sizes
  await page.act("Set custom widget width to minimum value");
  await page.act("Set custom widget height to minimum value");
  await page.act("Update preview");
  await page.observe("Verify widget still displays content legibly");
  
  await page.act("Set custom widget width to maximum value");
  await page.act("Set custom widget height to maximum value");
  await page.act("Update preview");
  await page.observe("Verify widget doesn't break layout");
  
  // Test invalid dimensions
  await page.act("Try to set widget width to zero or negative value");
  await page.observe("Verify invalid dimensions are handled gracefully");
  
  await page.act("Try to set extremely large dimensions");
  await page.observe("Verify system prevents unusable widget sizes");

  await stagehand.close();
});
```

#### BT2. Comment Length and Content Boundaries
```typescript
test("Comment display handles various content lengths and types", async () => {
  const stagehand = new Stagehand({
    env: "LOCAL",
    modelName: "gpt-4o",
    modelClientOptions: {
      apiKey: process.env.OPENAI_API_KEY,
    },
  });

  await stagehand.init();
  const page = stagehand.page;

  await page.goto("http://localhost:3000");
  await page.act("Generate widget for video with diverse comment types");
  await page.observe("Wait for comment carousel to load");
  
  // Test handling of different comment lengths
  await page.observe("Check if very short comments display properly");
  await page.observe("Check if very long comments are truncated or wrapped appropriately");
  
  // Test special characters and emojis
  await page.observe("Verify comments with emojis display correctly");
  await page.observe("Verify comments with special characters render properly");
  
  // Test empty or missing comment scenarios
  await page.observe("Verify system handles videos with very few comments");
  await page.observe("Check fallback behavior when no suitable comments exist");

  await stagehand.close();
});
```

---

## Performance Test Specifications

### PT1. API Response Time Testing
```typescript
test("API responses meet performance requirements", async ({ page }) => {
  // Hybrid test - Stagehand for interaction, Playwright for timing
  const stagehand = new Stagehand({
    env: "LOCAL",
    modelName: "gpt-4o",
    modelClientOptions: {
      apiKey: process.env.OPENAI_API_KEY,
    },
  });

  await stagehand.init();
  const stagehandPage = stagehand.page;

  await page.goto("http://localhost:3000");
  
  // Monitor API calls
  const apiCalls = [];
  page.on('response', response => {
    if (response.url().includes('/api/')) {
      apiCalls.push({
        url: response.url(),
        status: response.status(),
        timing: response.timing(),
      });
    }
  });

  // Generate widget using Stagehand
  await stagehandPage.goto("http://localhost:3000");
  await stagehandPage.act("Generate widget with standard YouTube URL");
  await stagehandPage.observe("Wait for widget generation to complete");

  // Validate API performance with Playwright
  const youtubeApiCalls = apiCalls.filter(call => call.url().includes('/api/youtube'));
  const sentimentApiCalls = apiCalls.filter(call => call.url().includes('/api/sentiment'));

  expect(youtubeApiCalls.length).toBeGreaterThan(0);
  youtubeApiCalls.forEach(call => {
    expect(call.timing.responseEnd - call.timing.requestStart).toBeLessThan(5000);
  });

  await stagehand.close();
});
```

### PT2. Widget Load Performance
```typescript
test("Widget loads meet performance requirements", async () => {
  const stagehand = new Stagehand({
    env: "LOCAL",
    modelName: "gpt-4o",
    modelClientOptions: {
      apiKey: process.env.OPENAI_API_KEY,
    },
  });

  await stagehand.init();
  const page = stagehand.page;

  const performanceMetrics = [];

  await page.goto("http://localhost:3000");
  
  for (let i = 0; i < 5; i++) {
    const startTime = Date.now();
    
    await page.act(`Generate widget ${i + 1}`);
    await page.observe("Wait for widget to fully load");
    
    const endTime = Date.now();
    const loadTime = endTime - startTime;
    performanceMetrics.push(loadTime);
    
    await page.act("Return to home");
  }

  // Analyze performance metrics
  const avgLoadTime = performanceMetrics.reduce((a, b) => a + b, 0) / performanceMetrics.length;
  const maxLoadTime = Math.max(...performanceMetrics);

  console.log(`Average load time: ${avgLoadTime}ms`);
  console.log(`Maximum load time: ${maxLoadTime}ms`);

  expect(avgLoadTime).toBeLessThan(2000); // PRD requirement
  expect(maxLoadTime).toBeLessThan(3000); // Allow some variance

  await stagehand.close();
});
```

---

## Data-Driven Test Cases

### DD1. YouTube URL Format Validation
```typescript
test.describe("YouTube URL format validation", () => {
  const urlTestCases = [
    // Valid formats
    { url: "https://www.youtube.com/watch?v=dQw4w9WgXcQ", valid: true, description: "Standard format" },
    { url: "https://youtu.be/dQw4w9WgXcQ", valid: true, description: "Short format" },
    { url: "https://www.youtube.com/watch?v=dQw4w9WgXcQ&t=30s", valid: true, description: "With timestamp" },
    { url: "https://m.youtube.com/watch?v=dQw4w9WgXcQ", valid: true, description: "Mobile format" },
    { url: "https://youtube.com/watch?v=dQw4w9WgXcQ", valid: true, description: "Without www" },
    
    // Invalid formats
    { url: "https://vimeo.com/123456", valid: false, description: "Wrong platform" },
    { url: "not-a-url", valid: false, description: "Invalid URL" },
    { url: "", valid: false, description: "Empty string" },
    { url: "https://youtube.com/invalid", valid: false, description: "Missing video ID" },
    { url: "https://www.youtube.com/watch?v=", valid: false, description: "Empty video ID" },
  ];

  urlTestCases.forEach(({ url, valid, description }) => {
    test(`${description}: ${url}`, async () => {
      const stagehand = new Stagehand({
        env: "LOCAL",
        modelName: "gpt-4o",
        modelClientOptions: {
          apiKey: process.env.OPENAI_API_KEY,
        },
      });

      await stagehand.init();
      const page = stagehand.page;

      await page.goto("http://localhost:3000");
      await page.act(`Enter URL: ${url}`);
      await page.act("Try to generate widget");

      if (valid) {
        await page.observe("Verify URL is accepted and processing begins");
      } else {
        await page.observe("Verify appropriate error message appears");
        await page.observe("Verify user can try again with different URL");
      }

      await stagehand.close();
    });
  });
});
```

### DD2. Video Type Compatibility Testing
```typescript
test.describe("Different video types compatibility", () => {
  const videoTypes = [
    { type: "Long-form video", duration: "10+ minutes", hasComments: true },
    { type: "YouTube Shorts", duration: "< 60 seconds", hasComments: true },
    { type: "Live stream", duration: "Variable", hasComments: true },
    { type: "Premiere video", duration: "Variable", hasComments: false },
    { type: "Educational content", duration: "5-15 minutes", hasComments: true },
    { type: "Music video", duration: "3-5 minutes", hasComments: true },
  ];

  videoTypes.forEach(({ type, duration, hasComments }) => {
    test(`${type} (${duration})`, async () => {
      const stagehand = new Stagehand({
        env: "LOCAL",
        modelName: "gpt-4o",
        modelClientOptions: {
          apiKey: process.env.OPENAI_API_KEY,
        },
      });

      await stagehand.init();
      const page = stagehand.page;

      await page.goto("http://localhost:3000");
      await page.act(`Generate widget for ${type} video`);
      await page.observe("Wait for processing to complete");

      if (hasComments) {
        await page.observe("Verify comment carousel is present");
        await page.observe("Verify sentiment analysis is shown");
      } else {
        await page.observe("Verify limited data widget is created");
        await page.observe("Verify basic metrics are still shown");
      }

      await page.observe("Verify widget displays appropriate content for video type");

      await stagehand.close();
    });
  });
});
```

---

## Accessibility and Compliance Testing

### AC1. Keyboard Navigation Testing
```typescript
test("Widget interface is fully keyboard navigable", async () => {
  const stagehand = new Stagehand({
    env: "LOCAL",
    modelName: "gpt-4o",
    modelClientOptions: {
      apiKey: process.env.OPENAI_API_KEY,
    },
  });

  await stagehand.init();
  const page = stagehand.page;

  await page.goto("http://localhost:3000");
  
  // Test keyboard navigation through interface
  await page.act("Navigate through the interface using only Tab key");
  await page.observe("Verify all interactive elements can be reached");
  
  await page.act("Use Tab to reach the URL input field");
  await page.act("Enter YouTube URL using keyboard");
  
  await page.act("Navigate to Generate button using Tab");
  await page.act("Press Enter to generate widget");
  
  await page.observe("Wait for widget to load");
  
  // Test widget preview keyboard navigation
  await page.act("Navigate through widget customization options using Tab");
  await page.observe("Verify all controls are keyboard accessible");
  
  await page.act("Use Arrow keys to navigate comment carousel");
  await page.observe("Verify comments can be navigated with keyboard");

  await stagehand.close();
});
```

### AC2. Screen Reader Compatibility
```typescript
test("Widget interface works with screen readers", async ({ page }) => {
  // Pure Playwright for accessibility testing
  await page.goto("http://localhost:3000");
  
  // Check ARIA labels and roles
  const urlInput = page.locator('[data-testid="youtube-url-input"]');
  await expect(urlInput).toHaveAttribute('aria-label');
  await expect(urlInput).toHaveAttribute('role');
  
  const generateButton = page.locator('[data-testid="generate-widget-button"]');
  await expect(generateButton).toHaveAccessibleName();
  
  // Test form submission
  await urlInput.fill("https://www.youtube.com/watch?v=dQw4w9WgXcQ");
  await generateButton.click();
  
  // Check loading state accessibility
  const loadingElement = page.locator('[data-testid="loading-indicator"]');
  await expect(loadingElement).toHaveAttribute('aria-live', 'polite');
  
  // Verify widget preview accessibility
  await page.waitForSelector('[data-testid="widget-preview"]');
  const widgetPreview = page.locator('[data-testid="widget-preview"]');
  await expect(widgetPreview).toHaveAttribute('role');
});
```

---

## Test Environment Setup

### Required Dependencies (package.json)
```json
{
  "name": "youtube-social-proof-e2e-tests",
  "version": "1.0.0",
  "type": "module",
  "scripts": {
    "test": "playwright test",
    "test:headed": "playwright test --headed",
    "test:debug": "playwright test --debug",
    "test:stagehand": "playwright test --grep='@stagehand'",
    "test:performance": "playwright test --grep='@performance'"
  },
  "devDependencies": {
    "@playwright/test": "^1.40.0",
    "@browserbasehq/stagehand": "^1.0.0",
    "zod": "^3.22.0",
    "typescript": "^5.0.0"
  },
  "dependencies": {
    "dotenv": "^16.3.0"
  }
}
```

### Playwright Configuration (playwright.config.ts)
```typescript
import { defineConfig, devices } from '@playwright/test';
import dotenv from 'dotenv';

dotenv.config();

export default defineConfig({
  testDir: './tests',
  fullyParallel: true,
  forbidOnly: !!process.env.CI,
  retries: process.env.CI ? 2 : 0,
  workers: process.env.CI ? 1 : undefined,
  reporter: 'html',
  timeout: 30000,
  expect: {
    timeout: 10000
  },
  use: {
    baseURL: 'http://localhost:3000',
    trace: 'on-first-retry',
    screenshot: 'only-on-failure',
  },

  projects: [
    {
      name: 'chromium',
      use: { ...devices['Desktop Chrome'] },
    },
    {
      name: 'firefox',
      use: { ...devices['Desktop Firefox'] },
    },
    {
      name: 'webkit',
      use: { ...devices['Desktop Safari'] },
    },
    {
      name: 'Mobile Chrome',
      use: { ...devices['Pixel 5'] },
    },
    {
      name: 'Mobile Safari',
      use: { ...devices['iPhone 12'] },
    },
  ],

  webServer: {
    command: 'npm run dev',
    url: 'http://localhost:3000',
    reuseExistingServer: !process.env.CI,
  },
});
```

### Environment Configuration (.env.example)
```bash
# OpenAI API Key for Stagehand
OPENAI_API_KEY=your_openai_api_key_here

# YouTube Data API Key (for application)
YOUTUBE_API_KEY=your_youtube_api_key_here

# Test Configuration
TEST_YOUTUBE_URL=https://www.youtube.com/watch?v=dQw4w9WgXcQ
TEST_PRIVATE_VIDEO_URL=https://www.youtube.com/watch?v=private123
TEST_COMMENTS_DISABLED_URL=https://www.youtube.com/watch?v=nocomments123

# Browserbase Configuration (optional)
BROWSERBASE_API_KEY=your_browserbase_api_key_here
BROWSERBASE_PROJECT_ID=your_project_id_here
```

### Test Data Configuration (test-data.ts)
```typescript
export const testData = {
  validYouTubeUrls: [
    "https://www.youtube.com/watch?v=dQw4w9WgXcQ",
    "https://youtu.be/dQw4w9WgXcQ",
    "https://www.youtube.com/watch?v=dQw4w9WgXcQ&t=30s",
    "https://m.youtube.com/watch?v=dQw4w9WgXcQ",
  ],
  invalidUrls: [
    "https://vimeo.com/123456",
    "not-a-url",
    "",
    "https://youtube.com/invalid",
  ],
  testScenarios: {
    highEngagement: {
      url: "https://www.youtube.com/watch?v=high-engagement",
      expectedViews: "> 1M",
      expectedComments: "> 1000",
      expectedSentiment: "> 4.0",
    },
    lowEngagement: {
      url: "https://www.youtube.com/watch?v=low-engagement",
      expectedViews: "< 10K",
      expectedComments: "< 100",
      expectedSentiment: "> 3.0",
    },
  },
};
```

---

## Test Execution Strategy

### Test Suite Organization
```
tests/
├── core-flows/
│   ├── widget-creation.spec.ts
│   ├── customization.spec.ts
│   └── embed-generation.spec.ts
├── error-handling/
│   ├── invalid-urls.spec.ts
│   ├── api-failures.spec.ts
│   └── edge-cases.spec.ts
├── interaction-testing/
│   ├── comment-carousel.spec.ts
│   ├── click-drag-conflicts.spec.ts
│   └── touch-interactions.spec.ts
├── performance/
│   ├── load-times.spec.ts
│   ├── concurrent-users.spec.ts
│   └── caching.spec.ts
├── accessibility/
│   ├── keyboard-navigation.spec.ts
│   ├── screen-readers.spec.ts
│   └── color-contrast.spec.ts
└── integration/
    ├── external-embedding.spec.ts
    ├── cross-browser.spec.ts
    └── responsive-design.spec.ts
```

### Test Tags and Filtering
```typescript
// Core functionality tests
test('widget creation happy path', { tag: ['@core', '@stagehand'] }, async () => {
  // Test implementation
});

// Performance tests
test('widget load performance', { tag: ['@performance', '@playwright'] }, async () => {
  // Test implementation
});

// Edge case tests
test('interaction conflicts', { tag: ['@edge-case', '@stagehand'] }, async () => {
  // Test implementation
});

// Mobile-specific tests
test('mobile responsiveness', { tag: ['@mobile', '@responsive'] }, async () => {
  // Test implementation
});
```

### Execution Commands
```bash
# Run all tests
npm run test

# Run only Stagehand tests
npm run test -- --grep="@stagehand"

# Run performance tests
npm run test -- --grep="@performance"

# Run tests in headed mode for debugging
npm run test:headed

# Run specific test file
npm run test tests/core-flows/widget-creation.spec.ts

# Run tests with specific tag
npm run test -- --grep="@core"
```

---

## Success Metrics and Validation

### Test Coverage Requirements
- **User Story Coverage**: 100% of PRD user stories must have corresponding test cases
- **Error Scenario Coverage**: All identified error states must be tested
- **Cross-Browser Coverage**: Tests must pass on Chrome, Firefox, Safari, and mobile browsers
- **Performance Requirements**: All tests must validate PRD performance requirements (< 2s load time)

### Test Quality Gates
1. **All tests must follow TDD red-green-refactor cycle**
2. **Stagehand tests should use natural language commands > 80% of the time**
3. **Critical user journeys must have both happy path and edge case coverage**
4. **Performance tests must validate specific metrics, not just completion**
5. **Accessibility tests must verify WCAG 2.1 AA compliance**

### Continuous Integration Requirements
- Tests must run in CI/CD pipeline
- Failed tests must provide actionable error messages
- Test results must be reported with clear metrics
- Performance regressions must trigger alerts
- Cross-browser test results must be aggregated and reported

This comprehensive test specification provides complete coverage of the YouTube Social Proof Widget application functionality while emphasizing Stagehand's natural language automation capabilities for realistic user interaction testing. The tests are designed to catch real-world usage issues and ensure the application meets all PRD requirements reliably.